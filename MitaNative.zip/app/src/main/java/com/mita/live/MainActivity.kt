package com.mita.live

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.Camera
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Base64
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var gv: GLSurfaceView
    private val rd = Gl()
    private lateinit var panel: ScrollView
    private lateinit var bubble: TextView
    private lateinit var bar: LinearLayout
    private lateinit var matBox: LinearLayout
    private lateinit var motBox: LinearLayout
    private lateinit var keyEt: EditText
    private lateinit var modEt: EditText
    private lateinit var voiceCb: CheckBox
    private val motions = ArrayList<Pair<String, Clip>>()
    private val hist = ArrayList<Pair<String, String>>()
    private var tts: TextToSpeech? = null
    private lateinit var physInfo: TextView
    @Volatile private var voiceTouch = true
    private var orbitAll = false
    private var mp: MediaPlayer? = null
    private var lastV = 0L
    private var cur = "mita"
    private lateinit var modBox: LinearLayout
    private lateinit var cosBox: LinearLayout
    private lateinit var cosEt: EditText
    private lateinit var personaEt: EditText
    private lateinit var gemCb: CheckBox
    private lateinit var gvEt: EditText
    private lateinit var pitchBar: SeekBar
    private lateinit var rateBar: SeekBar
    private lateinit var camCb: CheckBox
    private lateinit var recBtn: Button
    private var snapTr = false
    private var gFlip = false
    @Volatile private var speakTxt = ""
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var cam: Camera? = null
    private val prefs by lazy { getSharedPreferences("mita", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this); root.setBackgroundColor(Color.rgb(47, 127, 193))
        gv = GLSurfaceView(this); gv.setEGLContextClientVersion(3); gv.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        gv.holder.setFormat(android.graphics.PixelFormat.TRANSLUCENT); gv.setRenderer(rd); root.addView(gv)
        gv.setBackgroundColor(Color.TRANSPARENT)
        val sg = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { rd.zoom = (rd.zoom / d.scaleFactor).coerceIn(.25f, 2.6f); return true }
        })
        var lx = 0f; var ly = 0f; var lc = 0; var mode = 0; var sx = 0f; var sy = 0f; var t0 = 0L; var moved = 0f
        gv.setOnTouchListener { _, e ->
            val n = e.pointerCount
            var fx = 0f; var fy = 0f
            for (i in 0 until n) { fx += e.getX(i); fy += e.getY(i) }
            fx /= n; fy /= n
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.x; sy = e.y; moved = 0f; t0 = e.eventTime; lc = n
                    mode = if (!orbitAll && rd.inside(e.x, e.y)) 1 else 2
                    if (mode == 1) { rd.tpx = e.x; rd.tpy = e.y; rd.tdx = 0f; rd.tdy = 0f; rd.tOn = true }
                }
                MotionEvent.ACTION_POINTER_DOWN -> if (n == 2) {
                    val d = Math.hypot((e.getX(0) - e.getX(1)).toDouble(), (e.getY(0) - e.getY(1)).toDouble()).toFloat()
                    if (rd.inside(fx, fy) && d < Math.min(gv.width, gv.height) * .18f && !orbitAll) {
                        mode = 3; rd.pickReq = Triple(fx, fy, "pinch"); rd.tpx = fx; rd.tpy = fy; rd.tdx = 0f; rd.tdy = 0f; rd.tOn = true
                    } else { mode = 4; rd.tOn = false }
                    lc = -1
                }
                MotionEvent.ACTION_POINTER_UP -> { if (mode == 3) rd.tOn = false; mode = 2; lc = -1 }
                MotionEvent.ACTION_MOVE -> {
                    if (lc == n) {
                        val dx = fx - lx; val dy = fy - ly
                        if (mode == 1) { rd.tdx += dx; rd.tdy += dy; rd.tpx = fx; rd.tpy = fy; moved += Math.abs(dx) + Math.abs(dy) }
                        else if (mode == 3) { rd.tdx += dx; rd.tdy += dy; rd.tpx = fx; rd.tpy = fy }
                        else if (n == 1) { rd.yaw -= dx * .008f; rd.pitch = (rd.pitch + dy * .006f).coerceIn(-.9f, 1.1f) }
                        else if (n == 2) rd.pan = (rd.pan + dy * .02f).coerceIn(-12f, 12f)
                    }
                    lc = n
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (mode == 1 && e.actionMasked == MotionEvent.ACTION_UP && moved < dp(10) && e.eventTime - t0 < 450) rd.pickReq = Triple(sx, sy, "tap")
                    rd.tOn = false; mode = 0
                }
            }
            if (mode == 2 || mode == 4) sg.onTouchEvent(e)
            lx = fx; ly = fy
            true
        }
        bubble = TextView(this).apply { setTextColor(Color.WHITE); setBackgroundColor(0xAA102030.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8)); text = "Halo! Aku siap ngobrol." }
        val et = EditText(this).apply { hint = "Tulis pesan…"; setTextColor(Color.WHITE); setHintTextColor(0x99FFFFFF.toInt()); maxLines = 3 }
        val send = Button(this).apply { text = "Kirim"; setOnClickListener { val t = et.text.toString().trim(); if (t.isNotEmpty()) { et.setText(""); ask(t) } } }
        val mic = Button(this).apply { text = "🎤"; setOnClickListener { listen() } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(et, LinearLayout.LayoutParams(0, -2, 1f)); addView(mic); addView(send) }
        bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC102030.toInt()); addView(bubble); addView(row) }
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val eye = Button(this).apply { text = "👁"; setOnClickListener { val v = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE; bar.visibility = v; if (v == View.GONE) panel.visibility = View.GONE } }
        val gear = Button(this).apply { text = "⚙"; textSize = 20f; setOnClickListener { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE } }
        root.addView(eye, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply { rightMargin = dp(64); topMargin = dp(8) })
        root.addView(gear, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply { rightMargin = dp(8); topMargin = dp(8) })
        buildPanel()
        root.addView(panel, FrameLayout.LayoutParams(dp(320), dp(460), Gravity.TOP or Gravity.END).apply { rightMargin = dp(8); topMargin = dp(64) })
        setContentView(root)
        rd.zoneCb = { name, kind -> onZone(name, kind) }
        tts = TextToSpeech(this) {
            tts?.language = Locale("id", "ID")
            try { val sv = prefs.getString("ttsvoice", null); if (sv != null) tts?.voices?.firstOrNull { it.name == sv }?.let { tts?.voice = it } } catch (e: Throwable) { }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) { rd.playVis(lipFromText(speakTxt)); rd.talking = true }
                override fun onDone(u: String?) { rd.talking = false }
                override fun onError(u: String?) { rd.talking = false }
            })
        }
        val sv0 = prefs.getString("model", "mita") ?: "mita"
        loadModel(if (sv0 == "custom" || (sv0.startsWith("cu:") && !File(filesDir, "models/" + sv0.substring(3)).exists())) "mita" else sv0)
    }
    private fun lab(t: String) = TextView(this).apply { text = t; setTextColor(0xFF9BD0FF.toInt()); textSize = 13f; setPadding(0, dp(10), 0, dp(2)) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 12f; isAllCaps = false; setOnClickListener { f() } }
    private fun hrow(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } }
    private fun buildPanel() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(12)) }
        c.addView(lab("KARAKTER"))
        c.addView(hrow(btn("Mita") { loadModel("mita") }, btn("Ellen") { loadModel("ellen") }))
        c.addView(btn("Unggah model baru (PMX + tekstur / ZIP)") { pick(1, "*/*") })
        c.addView(lab("MODEL UNGGAHANMU (bisa banyak)"))
        modBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(modBox)
        c.addView(lab("SET KOSTUM (simpan pilihan material)"))
        cosEt = EditText(this).apply { hint = "Nama set, mis. Tanpa jaket"; setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); setSingleLine(true) }
        c.addView(cosEt); c.addView(btn("Simpan susunan material sekarang sebagai set") { saveCos() })
        cosBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(cosBox)
        c.addView(lab("MATERIAL"))
        c.addView(hrow(btn("Semua tampil") { setAll(true) }, btn("Sembunyi") { setAll(false) }))
        matBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(matBox)
        c.addView(lab("FISIKA (rambut, baju, rok, pita)"))
        c.addView(CheckBox(this).apply { text = "Fisika natural saat disentuh/digeser"; setTextColor(Color.WHITE); isChecked = true; setOnCheckedChangeListener { _, v -> rd.physOn = v } })
        c.addView(SeekBar(this).apply { max = 300; progress = 100; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { rd.physK = p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        physInfo = TextView(this).apply { setTextColor(0xFFCCCCCC.toInt()); textSize = 12f; text = "Tulang fisika: -" }; c.addView(physInfo)
        c.addView(lab("SUARA SENTUH (tanpa AI)"))
        c.addView(CheckBox(this).apply { text = "Suara saat disentuh / dielus / dicubit"; setTextColor(Color.WHITE); isChecked = true; setOnCheckedChangeListener { _, v -> voiceTouch = v } })
        c.addView(hrow(btn("Paket suara asli (audio/ZIP)") { pick(3, "*/*") }, btn("Hapus paket") { File(filesDir, "voice").deleteRecursively(); toast("Paket suara dihapus") }))
        c.addView(hrow(btn("Tes elus") { playSynth("pat") }, btn("Tes kaget") { playSynth("kya") }, btn("Tes cubit") { playSynth("ii") }))
        c.addView(TextView(this).apply { setTextColor(0xFFCCCCCC.toInt()); textSize = 11f; text = "Nama file audio: head_1, hair_1, body_1, arm_1, lower_1, pinch_1 (mp3/ogg/wav). Kalau tidak ada paket, dipakai suara sintetis." })
        c.addView(lab("SUARA BICARA (AI) + BIBIR SINKRON"))
        gemCb = CheckBox(this).apply { text = "Suara Gemini (lebih natural, pakai kuota)"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("gemvoice", false); setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("gemvoice", v).apply() } }
        c.addView(gemCb)
        gvEt = EditText(this).apply { hint = "Nama suara Gemini (mis. Leda, Aoede, Enceladus)"; setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); setSingleLine(true) }
        c.addView(gvEt)
        c.addView(TextView(this).apply { setTextColor(0xFFCCCCCC.toInt()); textSize = 12f; text = "Nada suara perangkat" })
        pitchBar = SeekBar(this).apply { max = 150; progress = 80; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) prefs.edit().putFloat("pitch_$cur", .5f + p / 100f).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {} }) }
        c.addView(pitchBar)
        c.addView(TextView(this).apply { setTextColor(0xFFCCCCCC.toInt()); textSize = 12f; text = "Kecepatan bicara" })
        rateBar = SeekBar(this).apply { max = 100; progress = 50; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) prefs.edit().putFloat("rate_$cur", .5f + p / 100f).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {} }) }
        c.addView(rateBar)
        c.addView(hrow(btn("Pilih suara perangkat") { pickVoice() }, btn("Tes bicara") { speak("Halo, aku senang sekali bisa ngobrol sama kamu hari ini.") }))
        c.addView(lab("FOTO & REKAM"))
        c.addView(CheckBox(this).apply { text = "Foto dengan latar transparan"; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, v -> snapTr = v } })
        recBtn = btn("⏺ Rekam") { toggleRec() }
        c.addView(hrow(btn("📷 Foto") { snapshot() }, recBtn))
        c.addView(TextView(this).apply { setTextColor(0xFFCCCCCC.toInt()); textSize = 11f; text = "Hasil masuk galeri (folder WaifuLive3D). Video tanpa suara, maks 2 menit." })
        c.addView(lab("MATA MENGIKUTI GERAKANMU"))
        camCb = CheckBox(this).apply { text = "Kamera depan (tidak ada gambar yang disimpan)"; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, v -> if (v) camStart() else camStop() } }
        c.addView(camCb)
        c.addView(CheckBox(this).apply { text = "Balik arah mata"; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, v -> gFlip = v } })
        c.addView(lab("GERAK (VMD / VPD / ZIP posepack)"))
        c.addView(hrow(btn("Tambah") { pick(2, "*/*") }, btn("Stop") { rd.wantReset = true }))
        motBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(motBox)
        c.addView(lab("AI (Gemini, streaming)"))
        keyEt = EditText(this).apply { hint = "Kunci API Gemini"; setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); setText(prefs.getString("key", "")); inputType = 129 }
        modEt = EditText(this).apply { setTextColor(Color.WHITE); setText(prefs.getString("gm", "gemini-flash-lite-latest")) }
        voiceCb = CheckBox(this).apply { text = "Suara (TTS)"; setTextColor(Color.WHITE); isChecked = true }
        personaEt = EditText(this).apply { hint = "Kepribadian karakter ini (opsional)"; setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); minLines = 2 }
        c.addView(keyEt); c.addView(modEt); c.addView(personaEt); c.addView(voiceCb)
        c.addView(btn("Simpan pengaturan AI") { prefs.edit().putString("key", keyEt.text.toString().trim()).putString("gm", modEt.text.toString().trim()).putString("persona_$cur", personaEt.text.toString().trim()).putString("gvoice_$cur", gvEt.text.toString().trim()).apply(); toast("Tersimpan") })
        c.addView(lab("TAMPILAN"))
        c.addView(hrow(btn("Depan") { rd.yaw = 0f }, btn("Kiri") { rd.yaw = 1.57f }, btn("Kanan") { rd.yaw = -1.57f }, btn("Belakang") { rd.yaw = 3.14f }))
        c.addView(CheckBox(this).apply { text = "Garis tepi"; setTextColor(Color.WHITE); isChecked = true; setOnCheckedChangeListener { _, v -> rd.outline = v } })
        c.addView(CheckBox(this).apply { text = "Geser karakter = putar kamera"; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, v -> orbitAll = v } })
        c.addView(btn("Reset kamera") { rd.yaw = 0f; rd.pitch = .05f; rd.zoom = 1f; rd.pan = 0f })
        panel = ScrollView(this).apply { setBackgroundColor(0xEE102030.toInt()); visibility = View.GONE; addView(c) }
    }
    private fun pick(code: Int, mime: String) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), code)
    }
    private fun nameOf(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) return c.getString(i) } }
        return u.lastPathSegment ?: "f"
    }
    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 5) {
            val t = if (res == RESULT_OK && d != null) d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() else null
            if (!t.isNullOrBlank()) ask(t)
            return
        }
        if (res != RESULT_OK || d == null) return
        val us = ArrayList<Uri>(); d.clipData?.let { for (i in 0 until it.itemCount) us.add(it.getItemAt(i).uri) }; d.data?.let { us.add(it) }
        Thread {
            try {
                if (rc == 1) {
                    val id = java.lang.Long.toString(System.currentTimeMillis(), 36)
                    val dir = File(filesDir, "models/$id"); dir.mkdirs()
                    for (u in us) {
                        val n = nameOf(u)
                        if (n.endsWith(".zip", true)) ZipInputStream(contentResolver.openInputStream(u)).use { z ->
                            var e = z.nextEntry
                            while (e != null) { if (!e.isDirectory) File(dir, e.name.substringAfterLast('/').substringAfterLast('\\').lowercase()).outputStream().use { z.copyTo(it) }; e = z.nextEntry }
                        } else contentResolver.openInputStream(u)?.use { i -> File(dir, n.lowercase()).outputStream().use { i.copyTo(it) } }
                    }
                    val pmx = dir.listFiles()?.firstOrNull { it.name.endsWith(".pmx") }
                    if (pmx == null) { dir.deleteRecursively(); throw Exception("Tidak ada file .pmx di pilihan ini") }
                    val def = pmx.name.removeSuffix(".pmx")
                    runOnUiThread {
                        askName("Beri nama karakter ini", def, { dir.deleteRecursively() }) { n ->
                            val nm = names(); nm.put(id, n); prefs.edit().putString("names", nm.toString()).apply()
                            renderModels(); loadModel("cu:$id")
                        }
                    }
                } else if (rc == 3) {
                    val dir = File(filesDir, "voice"); dir.mkdirs(); var cnt = 0
                    val ok = Regex(".*\\.(mp3|ogg|wav|m4a|aac|flac)", RegexOption.IGNORE_CASE)
                    for (u in us) {
                        val n = nameOf(u)
                        if (n.endsWith(".zip", true)) ZipInputStream(contentResolver.openInputStream(u)).use { z ->
                            var e = z.nextEntry
                            while (e != null) { val bn = e.name.substringAfterLast('/').lowercase(); if (!e.isDirectory && ok.matches(bn)) { File(dir, bn).outputStream().use { z.copyTo(it) }; cnt++ }; e = z.nextEntry }
                        } else if (ok.matches(n)) { contentResolver.openInputStream(u)?.use { i -> File(dir, n.lowercase()).outputStream().use { i.copyTo(it) } }; cnt++ }
                    }
                    toast("$cnt file suara dimuat")
                } else {
                    for (u in us) {
                        val n = nameOf(u)
                        if (n.endsWith(".zip", true)) ZipInputStream(contentResolver.openInputStream(u)).use { z ->
                            var e = z.nextEntry
                            while (e != null) { if (!e.isDirectory) addMotion(e.name.substringAfterLast('/'), z.readBytes()); e = z.nextEntry }
                        } else addMotion(n, contentResolver.openInputStream(u)!!.readBytes())
                    }
                    runOnUiThread { motBox.removeAllViews(); motions.forEach { (n, c) -> motBox.addView(btn("▶ $n") { rd.wantClip = c }) } }
                }
            } catch (e: Throwable) { toast("Gagal: " + e.message) }
        }.start()
    }
    private fun addMotion(n: String, d: ByteArray) {
        try { if (n.endsWith(".vmd", true)) motions.add(n to Motion.vmd(d)) else if (n.endsWith(".vpd", true)) motions.add(n to Motion.vpd(d)) } catch (e: Throwable) { toast("$n: ${e.message}") }
    }
    private fun decode(open: () -> InputStream?, max: Int): Bitmap? {
        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
        open()?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = s
        return open()?.use { BitmapFactory.decodeStream(it, null, o2) }
    }
    private fun loadModel(which: String) {
        Thread {
            try {
                val isCu = which.startsWith("cu:")
                val dir = File(filesDir, "models/" + which.removePrefix("cu:"))
                val bytes = if (isCu) (dir.listFiles()?.firstOrNull { it.name.endsWith(".pmx") } ?: throw Exception("Model tidak ditemukan (mungkin sudah dihapus)")).readBytes()
                else assets.open("models/$which/model.pmx").readBytes()
                val m = Pmx.parse(bytes); val rig = Rig(m)
                if (rig.idx["左腕"] == null || rig.idx["頭"] == null) toast("Model tanpa tulang standar MMD: gerak otomatis terbatas")
                val tex: (Int) -> Bitmap? = { i ->
                    if (isCu) { val p = m.tex.getOrNull(i)?.replace('\\', '/')?.substringAfterLast('/')?.lowercase(); val f = if (p == null) null else File(dir, p); if (f != null && f.exists()) decode({ f.inputStream() }, 1024) else null }
                    else decode({ try { assets.open("models/$which/t$i.png") } catch (e: Exception) { null } }, 1024)
                }
                val hid = prefs.getStringSet("hid_$which", emptySet()) ?: emptySet()
                m.mats.forEachIndexed { i, mt -> if (hid.contains(i.toString())) mt.vis = false }
                gv.queueEvent { rd.setModel(m, rig, tex) }
                cur = which; prefs.edit().putString("model", which).apply()
                runOnUiThread {
                    buildMats(m); physInfo.text = "Tulang fisika terdeteksi: " + rig.phys.size
                    renderModels(); renderCos()
                    personaEt.setText(prefs.getString("persona_$which", "")); gvEt.setText(prefs.getString("gvoice_$which", ""))
                    pitchBar.progress = ((prefs.getFloat("pitch_$which", defPitch(which)) - .5f) * 100f).toInt().coerceIn(0, 150)
                    rateBar.progress = ((prefs.getFloat("rate_$which", 1f) - .5f) * 100f).toInt().coerceIn(0, 100)
                    bubble.text = "Halo! Aku " + (if (isCu) names().optString(which.removePrefix("cu:"), "karakter barumu") else if (which == "ellen") "Ellen" else "Mita") + "."
                }
            } catch (e: Throwable) { toast("Gagal memuat: " + e.message) }
        }.start()
    }
    private fun buildMats(m: PmxModel) {
        matBox.removeAllViews()
        m.mats.forEachIndexed { i, mt ->
            val cb = CheckBox(this).apply { text = mt.name; setTextColor(Color.WHITE); isChecked = mt.vis; textSize = 12f }
            cb.setOnCheckedChangeListener { _, v -> mt.vis = v; saveHid(m) }
            matBox.addView(cb)
        }
        curModel = m
    }
    private var curModel: PmxModel? = null
    private fun saveHid(m: PmxModel) { prefs.edit().putStringSet("hid_$cur", m.mats.withIndex().filter { !it.value.vis }.map { it.index.toString() }.toSet()).apply() }
    private fun setAll(v: Boolean) { curModel?.let { m -> m.mats.forEach { it.vis = v }; buildMats(m); saveHid(m) } }

    private fun ask(text: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) { bubble.text = "Isi kunci API Gemini dulu di ⚙ > AI."; return }
        bubble.text = "…"; tts?.stop(); rd.talking = false
        val pp = prefs.getString("persona_$cur", "") ?: ""
        val name = if (pp.isNotEmpty()) pp else if (cur == "ellen") "Ellen Joe, gadis hiu pelayan yang pemalas, datar dan santai" else if (cur == "mita") "Mita, cewek anime ceria, imut, manja-manja jahil" else names().optString(cur.removePrefix("cu:"), "karakter anime") + ", karakter anime yang ramah dan hidup"
        val sys = """Kamu adalah $name, jadi teman ngobrol virtual. Jawab Bahasa Indonesia, maksimal 2 kalimat pendek, tanpa emoji, tanpa narasi aksi.
Format wajib: tulis balasan, lalu ||| , lalu satu baris JSON tanpa markdown: {"e":"senang|sedih|marah|kaget|netral","d":3,"w":false,"p":{"kepala":[x,y,z],"badan":[x,y,z],"lengan_kiri":[x,y,z],"lengan_kanan":[x,y,z],"siku_kiri":[0,tekuk,0],"siku_kanan":[0,tekuk,0]}}. Sudut radian -1..1 (siku tekuk 0..2). x: menunduk(+), y: menoleh, z: miring; pada lengan z positif = mengangkat lengan. d = detik pose bertahan. w=true bila melambai. Isi p hanya untuk bagian tubuh yang bergerak sesuai ucapan (mengangguk, melambai, menunjuk, mengangkat tangan)."""
        hist.add("user" to text)
        Thread {
            val sb = StringBuilder()
            try {
                val cs = JSONArray(); hist.takeLast(6).forEach { (r, t) -> cs.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t)))) }
                val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))).put("contents", cs)
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 300).put("temperature", .95))
                val model = prefs.getString("gm", "gemini-flash-lite-latest") ?: "gemini-flash-lite-latest"
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode != 200) throw Exception("HTTP " + c.responseCode + (if (c.responseCode == 429) " (kuota penuh)" else if (c.responseCode == 400 || c.responseCode == 403) " (cek kunci/model)" else ""))
                c.inputStream.bufferedReader().forEachLine { ln ->
                    if (ln.startsWith("data:")) {
                        val ps = JSONObject(ln.substring(5).trim()).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        if (ps != null) for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
                        runOnUiThread { bubble.text = sb.toString().substringBefore("|||") }
                    }
                }
                val full = sb.toString(); val txt = full.substringBefore("|||").trim(); hist.add("model" to txt); if (full.contains("|||")) applyAi(full.substringAfter("|||"))
                if (txt.isNotEmpty()) runOnUiThread { speak(txt) }
            } catch (e: Throwable) { hist.removeLastOrNull(); runOnUiThread { bubble.text = "Ups: " + e.message } }
        }.start()
    }
    private fun zoneKey(n: String): String = when {
        Regex("髪|hair", RegexOption.IGNORE_CASE).containsMatchIn(n) -> "hair"
        Regex("頭|顔|目|眉|耳|head|face").containsMatchIn(n) -> "head"
        Regex("腕|手|指|ひじ|arm|hand|finger").containsMatchIn(n) -> "arm"
        Regex("足|スカート|skirt|腰|下半身|ひざ|つま先|leg|foot").containsMatchIn(n) -> "lower"
        else -> "body"
    }
    private fun onZone(name: String, kind: String) {
        val now = System.currentTimeMillis()
        if (now - lastV < (if (kind == "drag") 1800 else 600)) return
        lastV = now
        val z = zoneKey(name)
        rd.aiPose = null; rd.aiDur = 2.5f
        rd.emo = if (kind == "pinch" || z == "lower" || z == "body" && kind != "drag") 3 else 0
        rd.aiNew = true
        if (!voiceTouch) return
        if (playPack(if (kind == "pinch") "pinch" else z)) return
        val p = when {
            kind == "pinch" -> "ii"
            z == "head" -> "pat"
            z == "hair" -> if (kind == "drag") "pat" else "hya"
            z == "arm" -> "eh"
            z == "lower" -> "kyaa"
            else -> if (kind == "drag") "nn" else "kya"
        }
        playSynth(p)
    }
    private fun playSynth(p: String) {
        val segs = Vox.preset(p)
        Vox.play(segs, { rd.playVis(visFromSegs(segs)); rd.talking = true }, { rd.talking = false })
    }
    private fun visFromSegs(segs: List<Vox.Seg>): Gl.Vis {
        val ch = CharArray(segs.size); val en = FloatArray(segs.size); var acc = 0f
        segs.forEachIndexed { i, s -> acc += s.dur; ch[i] = s.v; en[i] = acc }
        return Gl.Vis(ch, en)
    }
    private fun lipFromText(t: String): Gl.Vis {
        val ch = ArrayList<Char>(); val en = ArrayList<Float>(); var acc = 0f
        for (c in t.lowercase()) {
            if (c == 'a' || c == 'i' || c == 'u' || c == 'e' || c == 'o') { acc += .15f; ch.add(c); en.add(acc) }
            else if (c == ',' || c == '.' || c == '!' || c == '?' || c == '…') { acc += .28f; ch.add(' '); en.add(acc) }
        }
        if (ch.isEmpty()) { ch.add('a'); en.add(.3f) }
        return Gl.Vis(ch.toCharArray(), en.toFloatArray())
    }
    private fun defPitch(w: String) = if (w == "ellen") .9f else if (w == "mita") 1.35f else 1.15f
    private fun speak(txt: String) {
        if (!voiceCb.isChecked || txt.isEmpty()) return
        if (gemCb.isChecked && (prefs.getString("key", "") ?: "").isNotEmpty()) {
            Thread {
                try { geminiSpeak(txt) } catch (e: Throwable) { toast("Suara Gemini gagal (" + e.message + "), pakai suara perangkat"); runOnUiThread { ttsSpeak(txt) } }
            }.start()
        } else ttsSpeak(txt)
    }
    private fun ttsSpeak(txt: String) {
        speakTxt = txt
        tts?.setPitch(prefs.getFloat("pitch_$cur", defPitch(cur))); tts?.setSpeechRate(prefs.getFloat("rate_$cur", 1f))
        tts?.speak(txt, TextToSpeech.QUEUE_FLUSH, null, "u")
    }
    private fun pickVoice() {
        val vs = try { tts?.voices?.filter { val l = it.locale.language; l == "in" || l == "id" || l == "ja" || l == "en" }?.sortedBy { it.name } ?: emptyList<android.speech.tts.Voice>() } catch (e: Throwable) { emptyList<android.speech.tts.Voice>() }
        if (vs.isEmpty()) { toast("Tidak ada daftar suara di perangkat ini"); return }
        val items = vs.map { it.name + " (" + it.locale + ")" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pilih suara").setItems(items) { _, i -> tts?.voice = vs[i]; prefs.edit().putString("ttsvoice", vs[i].name).apply() }.show()
    }
    private fun geminiSpeak(txt: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) throw Exception("kunci kosong")
        val gv0 = prefs.getString("gvoice_$cur", "") ?: ""
        val voice = if (gv0.isNotEmpty()) gv0 else if (cur == "ellen") "Enceladus" else "Leda"
        val style = if (cur == "ellen") "Say in a sleepy, low-energy, deadpan, slightly husky lazy girl voice, slowly: " else "Say in a cute, bright, high-pitched, bubbly anime girl voice, playful: "
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", style + txt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        var json: JSONObject? = null; var err = ""
        for (mdl in listOf("gemini-2.5-flash-preview-tts", "gemini-2.5-flash-tts")) {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$mdl:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode == 200) { json = JSONObject(c.inputStream.bufferedReader().readText()); break }
            err = "HTTP " + c.responseCode
        }
        if (json == null) throw Exception(err)
        val b64 = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        val pcm = Base64.decode(b64, Base64.DEFAULT)
        val n = pcm.size / 2; val sh = ShortArray(n)
        java.nio.ByteBuffer.wrap(pcm).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh)
        val step = 1200; val en = FloatArray(n / step + 2)
        for (k in en.indices) {
            var s = 0.0; var cnt = 0
            var i = k * step
            while (i < minOf(n, (k + 1) * step)) { val v = sh[i] / 32768.0; s += v * v; cnt++; i++ }
            en[k] = if (cnt > 0) Math.min(1.0, Math.sqrt(s / cnt) * 5.0).toFloat() else 0f
        }
        val t = AudioTrack(AudioManager.STREAM_MUSIC, 24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC)
        t.write(sh, 0, n); rd.playEnv(en); rd.talking = true; t.play()
        Thread.sleep(n * 1000L / 24000 + 120)
        rd.talking = false; rd.env = null; t.release()
    }
    private fun listen() {
        try {
            tts?.stop(); rd.talking = false
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID").putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicara…"), 5)
        } catch (e: Throwable) { toast("Pengenal suara Google tidak tersedia di HP ini") }
    }
    // ---- daftar model unggahan ----
    private fun names(): JSONObject = try { JSONObject(prefs.getString("names", "{}") ?: "{}") } catch (e: Throwable) { JSONObject() }
    private fun askName(title: String, def: String, cancel: () -> Unit = {}, ok: (String) -> Unit) {
        val et = EditText(this); et.setText(def); et.setSingleLine(true)
        AlertDialog.Builder(this).setTitle(title).setView(et).setCancelable(false)
            .setPositiveButton("Simpan") { _, _ -> ok(et.text.toString().trim().ifEmpty { if (def.isEmpty()) "Karakter" else def }) }
            .setNegativeButton("Batal") { _, _ -> cancel() }.show()
    }
    private fun renderModels() {
        modBox.removeAllViews()
        val nm = names()
        val ids = (File(filesDir, "models").listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList<String>()).sorted()
        if (ids.isEmpty()) { modBox.addView(TextView(this).apply { text = "Belum ada model unggahan."; setTextColor(0xFFCCCCCC.toInt()) }); return }
        for (id in ids) {
            val title = nm.optString(id, id)
            modBox.addView(hrow(
                btn((if (cur == "cu:$id") "▶ " else "") + title) { loadModel("cu:$id") },
                btn("✎") { askName("Ubah nama", title) { n -> nm.put(id, n); prefs.edit().putString("names", nm.toString()).apply(); renderModels() } },
                btn("🗑") {
                    File(filesDir, "models/$id").deleteRecursively()
                    prefs.edit().remove("hid_cu:$id").remove("cos_cu:$id").apply()
                    if (cur == "cu:$id") loadModel("mita")
                    renderModels()
                }))
        }
    }
    // ---- set kostum ----
    private fun cosList(): JSONArray = try { JSONArray(prefs.getString("cos_$cur", "[]") ?: "[]") } catch (e: Throwable) { JSONArray() }
    private fun renderCos() {
        cosBox.removeAllViews()
        val a = cosList()
        if (a.length() == 0) { cosBox.addView(TextView(this).apply { text = "Belum ada set kostum."; setTextColor(0xFFCCCCCC.toInt()) }); return }
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            cosBox.addView(hrow(btn("👗 " + o.optString("n")) { applyCos(o) }, btn("🗑") {
                val b = JSONArray(); for (j in 0 until a.length()) if (j != i) b.put(a.getJSONObject(j))
                prefs.edit().putString("cos_$cur", b.toString()).apply(); renderCos() }))
        }
    }
    private fun applyCos(o: JSONObject) {
        val m = curModel ?: return
        val h = o.optJSONArray("h"); val hs = HashSet<Int>()
        if (h != null) for (i in 0 until h.length()) hs.add(h.getInt(i))
        m.mats.forEachIndexed { i, mt -> mt.vis = !hs.contains(i) }
        buildMats(m); saveHid(m)
    }
    private fun saveCos() {
        val m = curModel ?: return
        val a = cosList(); val h = JSONArray()
        m.mats.forEachIndexed { i, mt -> if (!mt.vis) h.put(i) }
        val n = cosEt.text.toString().trim().ifEmpty { "Set " + (a.length() + 1) }
        a.put(JSONObject().put("n", n).put("h", h)); prefs.edit().putString("cos_$cur", a.toString()).apply()
        cosEt.setText(""); renderCos()
    }
    // ---- foto & rekam ----
    private fun drawBg(c: android.graphics.Canvas, w: Int, h: Int) {
        val p = android.graphics.Paint()
        p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF55C1CB.toInt(), 0xFF2F7FC1.toInt(), android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }
    private fun saveMedia(src: File, mime: String, name: String, video: Boolean): String {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name); v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, (if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES) + "/WaifuLive3D")
                val uri = contentResolver.insert(if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
                "Tersimpan di galeri (folder WaifuLive3D): $name"
            } else {
                val ok = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                if (ok) {
                    val d = File(Environment.getExternalStoragePublicDirectory(if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES), "WaifuLive3D"); d.mkdirs()
                    val f = File(d, name); src.copyTo(f, true)
                    MediaScannerConnection.scanFile(this, arrayOf(f.path), null, null)
                    "Tersimpan: " + f.path
                } else {
                    runOnUiThread { requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 9) }
                    val d = getExternalFilesDir(null) ?: filesDir
                    val f = File(d, name); src.copyTo(f, true)
                    "Disimpan di " + f.path + ". Izinkan penyimpanan lalu ulangi agar masuk galeri."
                }
            }
        } catch (e: Throwable) { "Gagal menyimpan: " + e.message }
    }
    private fun snapshot() {
        rd.snapCb = { bm ->
            val mx = android.graphics.Matrix(); mx.preScale(1f, -1f)
            val fl = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, mx, false)
            val tr = snapTr
            Thread {
                try {
                    val out = if (tr) fl else {
                        val b2 = Bitmap.createBitmap(fl.width, fl.height, Bitmap.Config.ARGB_8888)
                        val cv = android.graphics.Canvas(b2); drawBg(cv, fl.width, fl.height); cv.drawBitmap(fl, 0f, 0f, null); b2
                    }
                    val f = File(cacheDir, "snap.png")
                    f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    toast(saveMedia(f, "image/png", "waifu-" + System.currentTimeMillis() + ".png", false))
                } catch (e: Throwable) { toast("Gagal foto: " + e.message) }
            }.start()
        }
        rd.snapReq = true
    }
    private fun toggleRec() {
        if (recorder != null) { stopRec(); return }
        try {
            val w0 = gv.width; val h0 = gv.height
            val sc = Math.min(1f, 640f / Math.max(w0, h0).toFloat())
            val rw = ((w0 * sc).toInt() / 2) * 2; val rh = ((h0 * sc).toInt() / 2) * 2
            val f = File(cacheDir, "rec.mp4"); if (f.exists()) f.delete()
            val r = MediaRecorder()
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(rw, rh); r.setVideoFrameRate(15); r.setVideoEncodingBitRate(1500000); r.setOutputFile(f.path); r.prepare()
            val s = r.surface; r.start(); recorder = r; recFile = f
            val mx = android.graphics.Matrix()
            rd.frameCb = { bm ->
                try {
                    val c = s.lockCanvas(null)
                    if (c != null) {
                        drawBg(c, rw, rh)
                        mx.setScale(rw.toFloat() / bm.width, -rh.toFloat() / bm.height); mx.postTranslate(0f, rh.toFloat())
                        c.drawBitmap(bm, mx, null); s.unlockCanvasAndPost(c)
                    }
                } catch (e: Throwable) { }
                Unit
            }
            rd.recOn = true; recBtn.text = "⏹ Stop rekam"
            gv.postDelayed({ if (recorder === r) stopRec() }, 120000)
        } catch (e: Throwable) {
            rd.recOn = false; try { recorder?.release() } catch (x: Throwable) { }; recorder = null
            toast("Rekam gagal: " + e.message)
        }
    }
    private fun stopRec() {
        rd.recOn = false; rd.frameCb = null
        val r = recorder; recorder = null
        try { r?.stop() } catch (e: Throwable) { }
        try { r?.release() } catch (e: Throwable) { }
        recBtn.text = "⏺ Rekam"
        val f = recFile
        if (f != null && f.exists() && f.length() > 0) Thread { toast(saveMedia(f, "video/mp4", "waifu-" + System.currentTimeMillis() + ".mp4", true)) }.start()
    }
    // ---- mata mengikuti gerakan lewat kamera depan (selisih frame, sangat ringan) ----
    @Suppress("DEPRECATION")
    private fun camStart() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 7); camCb.isChecked = false; toast("Izinkan kamera, lalu centang lagi"); return
        }
        try {
            val info = Camera.CameraInfo(); var id = -1
            for (i in 0 until Camera.getNumberOfCameras()) { Camera.getCameraInfo(i, info); if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) { id = i; break } }
            if (id < 0) throw Exception("tidak ada kamera depan")
            Camera.getCameraInfo(id, info); val ori = info.orientation
            val c = Camera.open(id); val p = c.parameters
            var best = p.supportedPreviewSizes[0]
            for (s in p.supportedPreviewSizes) if (s.width * s.height < best.width * best.height) best = s
            p.setPreviewSize(best.width, best.height); c.parameters = p
            c.setPreviewTexture(SurfaceTexture(11))
            val W = best.width; val H = best.height; val cw = W / 4 + 1; val chh = H / 4 + 1
            var prev: IntArray? = null; var lastM = 0L
            c.setPreviewCallback { data, _ ->
                val cur = IntArray(cw * chh)
                var sx = 0.0; var sy = 0.0; var n = 0
                val pv = prev
                for (y in 0 until H step 4) for (x in 0 until W step 4) {
                    val k = (y / 4) * cw + (x / 4); val v = data[y * W + x].toInt() and 255; cur[k] = v
                    if (pv != null && Math.abs(v - pv[k]) > 28) { sx += x; sy += y; n++ }
                }
                prev = cur
                val now = System.currentTimeMillis()
                if (n > 8 && n < cw * chh * 0.7) {
                    val bx = (sx / n).toFloat(); val by = (sy / n).toFloat()
                    val ux: Float; val uy: Float; val uw: Float; val uh: Float
                    if (ori == 270) { ux = by; uy = W - 1 - bx; uw = H.toFloat(); uh = W.toFloat() }
                    else if (ori == 90) { ux = H - 1 - by; uy = bx; uw = H.toFloat(); uh = W.toFloat() }
                    else { ux = bx; uy = by; uw = W.toFloat(); uh = H.toFloat() }
                    val gxv = (1f - 2f * ux / uw).coerceIn(-1f, 1f); val gyv = ((2f * uy / uh - 1f) * .7f).coerceIn(-.7f, .7f)
                    rd.gx = if (gFlip) -gxv else gxv; rd.gy = gyv; rd.gOn = true; lastM = now
                } else if (now - lastM > 3000) rd.gOn = false
            }
            c.startPreview(); cam = c
        } catch (e: Throwable) { camStop(); camCb.isChecked = false; toast("Kamera gagal: " + e.message) }
    }
    @Suppress("DEPRECATION")
    private fun camStop() {
        try { cam?.setPreviewCallback(null); cam?.stopPreview(); cam?.release() } catch (e: Throwable) { }
        cam = null; rd.gOn = false
    }

    private fun playPack(key: String): Boolean {
        val fs = File(filesDir, "voice").listFiles()?.filter { it.isFile } ?: return false
        if (fs.isEmpty()) return false
        var c = fs.filter { it.name.startsWith(key) }
        if (c.isEmpty()) c = fs.filter { it.name.startsWith("any") || it.name.startsWith("poke") }
        if (c.isEmpty()) return false
        val f = c.random()
        runOnUiThread {
            try {
                mp?.release()
                mp = MediaPlayer().apply {
                    setDataSource(f.path)
                    setOnCompletionListener { rd.talking = false }
                    setOnPreparedListener { rd.talking = true; it.start() }
                    prepareAsync()
                }
            } catch (e: Throwable) { rd.talking = false }
        }
        return true
    }
    private fun applyAi(js: String) {
        try {
            val o = JSONObject(js.trim().removePrefix("```json").removeSuffix("```").trim())
            val names = mapOf("kepala" to "頭", "badan" to "上半身", "lengan_kiri" to "左腕", "lengan_kanan" to "右腕", "siku_kiri" to "左ひじ", "siku_kanan" to "右ひじ")
            val mp = HashMap<String, FloatArray>()
            val p = o.optJSONObject("p")
            if (p != null) for ((k, v) in names) { val a = p.optJSONArray(k) ?: continue; mp[v] = FloatArray(3) { i -> a.optDouble(i, 0.0).toFloat().coerceIn(-2.2f, 2.2f) } }
            rd.aiDur = o.optDouble("d", 3.0).toFloat().coerceIn(1f, 8f)
            rd.emo = listOf("senang", "sedih", "marah", "kaget").indexOf(o.optString("e"))
            rd.aiWave = o.optBoolean("w", false)
            rd.aiPose = mp; rd.aiNew = true
        } catch (e: Throwable) { }
    }
    override fun onPause() { super.onPause(); if (cam != null) { camStop(); camCb.isChecked = false }; if (recorder != null) stopRec(); gv.onPause() }
    override fun onResume() { super.onResume(); gv.onResume() }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
