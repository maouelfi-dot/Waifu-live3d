package com.mita.live

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream

/** Tingkat kualitas: skala resolusi, FPS saat aktif/diam, ukuran tekstur maksimum, loop IK maksimum. */
private class QTier(val name: String, val scale: Float, val fpsAct: Int, val fpsIdle: Int, val tex: Int, val ik: Int)
private val TIERS = mapOf(
    "normal" to QTier("normal", 1f, 60, 30, 1024, 32),
    "hemat" to QTier("hemat", .8f, 30, 24, 768, 20),
    "ultra" to QTier("ultra", .65f, 30, 20, 512, 12)
)

private val MOTION = """
Kalau pengguna menyuruhmu bergerak/berpose/berekspresi, WAJIB isi "rencana" lalu "gerak" = daftar keyframe berurutan waktu (detik sejak mulai, total maks 10 detik, mulai t>=0.8). Gerakannya kamu pikirkan SENDIRI sesuai pemahamanmu, bukan salinan contoh. Kalau kamu memutuskan menolak (karena tidak suka/tidak mau), gerak-mu adalah bahasa tubuh penolakan.
Koordinat tangan: titik 0 = tengah bahu, satuan = panjang satu lengan. x = jarak dari garis tengah badan ke samping LUAR (negatif = menyilang), y = atas(+)/bawah(-), z = depan(+, ke arah kamera). "kiri"/"kanan" = tangan kiri/kanan MILIKMU. Posisi boleh berupa [x,y,z] atau nama titik: wajah, pipi, mulut, mata, hidung, dagu, dahi, telinga, rambut, kepala, atas_kepala, dada, perut, pinggang, paha, punggung, samping, depan, belakang, bawah, atas, kamera, tengah, bahu. Posisi = pusat telapak tangan.
Keyframe: {"t":detik,"kiri":TANGAN,"kanan":TANGAN,"kepala":{"toleh":-1..1(kiri-kanan),"angguk":-1..1(+menunduk),"miring":-1..1},"badan":{"bungkuk":0..1,"condong":-1..1,"putar":-4..4(1=90 derajat),"lompat":0..1},"wajah":{"senyum":0..1,"mata":"biasa|tutup|wink_kiri|wink_kanan|lebar|sipit","mulut":"biasa|a|o|lidah","alis":-1..1,"pipi":0..1(gembung)},"lihat":"kamera|kiri|kanan|atas|bawah|tangan_kiri|tangan_kanan"}
TANGAN: {"pos":nama|[x,y,z],"geser":[dx,dy,dz],"arah":arah jari (atas|bawah|depan|belakang|luar|dalam|serong_atas|serong_atas_dalam|depan_atas|[x,y,z]),"telapak":(kamera|badan|atas|bawah|luar|dalam),"jari":bentuk|[jempol_lipat,jempol_buka,telunjuk,tengah,manis,kelingking,renggang] (0=lurus, 1=tekuk penuh),"siku":turun|keluar|naik|depan}
Bentuk jari: rileks, buka, rapat, kepal, tunjuk, peace, jempol, ok, love_jari, setengah_hati, kucing, cakar, rock, ily, pegang. Kamu boleh menyusun angka jari sendiri untuk bentuk lain.
Hanya tulis bagian yang bergerak; sisanya bertahan dari keyframe sebelumnya. Untuk gerakan berulang (melambai, mengetuk) pakai beberapa keyframe kecil. Tambahkan "tahan":detik di akhir bila perlu.
Contoh (jari love): {"rencana":"angkat tangan kanan ke depan wajah, telapak ke kamera, jempol dan telunjuk disilangkan jadi hati kecil","gerak":[{"t":0.9,"kanan":{"pos":[0.22,0.3,0.62],"arah":"atas","telapak":"kamera","jari":"love_jari","siku":"turun"},"wajah":{"senyum":1},"kepala":{"miring":0.3},"lihat":"kamera"},{"t":2.4,"kanan":{"geser":[0,0.04,0]},"wajah":{"mata":"wink_kiri"}}]}
Contoh (melambai): {"rencana":"angkat tangan kanan di samping kepala lalu goyang kiri-kanan","gerak":[{"t":0.9,"kanan":{"pos":[0.55,0.5,0.3],"arah":"atas","telapak":"kamera","jari":"buka","siku":"keluar"},"wajah":{"senyum":1}},{"t":1.25,"kanan":{"arah":"serong_atas_luar"}},{"t":1.6,"kanan":{"arah":"serong_atas_dalam"}},{"t":1.95,"kanan":{"arah":"serong_atas_luar"}}]}
"""

class MainActivity : Activity() {
    private lateinit var gv: GLSurfaceView
    private val rd = Gl()
    private lateinit var root: FrameLayout
    private lateinit var panel: ScrollView
    private lateinit var bubble: TextView
    private lateinit var bar: LinearLayout
    private lateinit var matBox: LinearLayout
    private lateinit var motBox: LinearLayout
    private lateinit var keyEt: EditText
    private lateinit var modEt: EditText
    private lateinit var voiceCb: CheckBox
    private val motions = ArrayList<Pair<String, Clip>>()
    private val hist = ArrayList<Pair<String, String>>()
    private var tts: TextToSpeech? = null
    private var cur = "mita"
    private var tier = TIERS["hemat"]!!
    private var running = false
    private var lastRender = 0L
    private var fixedW = 0; private var fixedH = 0
    private val prefs by lazy { getSharedPreferences("mita", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun autoTier(): QTier {
        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val gb = mi.totalMem / 1073741824.0
        val low = (getSystemService(ACTIVITY_SERVICE) as ActivityManager).isLowRamDevice
        return TIERS[if (low || gb <= 2.6) "ultra" else if (gb <= 4.6) "hemat" else "normal"]!!
    }
    private fun pickTier(): QTier { val q = prefs.getString("qual", "auto") ?: "auto"; return if (q == "auto") autoTier() else TIERS[q] ?: autoTier() }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (!running) return
            rd.status?.let { toast(it); rd.status = null }
            val fps = if (rd.busy()) tier.fpsAct else tier.fpsIdle
            if (t - lastRender >= 1_000_000_000L / fps - 4_000_000L) { lastRender = t; gv.requestRender() }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tier = pickTier()
        rd.outline = prefs.getBoolean("outline", true); rd.anime = prefs.getBoolean("anime", true)
        rd.physOn = prefs.getBoolean("phys", true); rd.physScale = prefs.getInt("physs", 100) / 100f
        root = FrameLayout(this); root.setBackgroundColor(Color.rgb(47, 127, 193))
        gv = GLSurfaceView(this); gv.setEGLContextClientVersion(3); gv.setEGLConfigChooser(8, 8, 8, 0, 16, 0)
        gv.setRenderer(rd); gv.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY; root.addView(gv)
        root.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ -> applyScale(r - l, bt - t) }
        val sg = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { rd.zoom = (rd.zoom / d.scaleFactor).coerceIn(.25f, 2.6f); return true }
        })
        var lx = 0f; var ly = 0f; var lc = 0
        gv.setOnTouchListener { _, e ->
            rd.lastTouch = System.currentTimeMillis()
            sg.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_MOVE && !sg.isInProgress && lc == e.pointerCount) {
                if (e.pointerCount == 1) { rd.yaw -= (e.x - lx) * .008f; rd.pitch = (rd.pitch + (e.y - ly) * .006f).coerceIn(-.9f, 1.1f) }
                else if (e.pointerCount == 2) rd.pan = (rd.pan + (e.y - ly) * .02f).coerceIn(-12f, 12f)
            }
            lx = e.x; ly = e.y; lc = e.pointerCount; true
        }
        bubble = TextView(this).apply { setTextColor(Color.WHITE); setBackgroundColor(0xAA102030.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8)); text = "Halo! Aku siap ngobrol. Coba suruh aku bergerak, misalnya “lambaikan tangan”." }
        val et = EditText(this).apply { hint = "Tulis pesan…"; setTextColor(Color.WHITE); setHintTextColor(0x99FFFFFF.toInt()); maxLines = 3 }
        val send = Button(this).apply { text = "Kirim"; setOnClickListener { val t = et.text.toString().trim(); if (t.isNotEmpty()) { et.setText(""); ask(t) } } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(et, LinearLayout.LayoutParams(0, -2, 1f)); addView(send) }
        bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC102030.toInt()); addView(bubble); addView(row) }
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val eye = Button(this).apply { text = "👁"; setOnClickListener { val v = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE; bar.visibility = v; if (v == View.GONE) panel.visibility = View.GONE } }
        val gear = Button(this).apply { text = "⚙"; textSize = 20f; setOnClickListener { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE } }
        root.addView(eye, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply { rightMargin = dp(64); topMargin = dp(8) })
        root.addView(gear, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply { rightMargin = dp(8); topMargin = dp(8) })
        buildPanel()
        root.addView(panel, FrameLayout.LayoutParams(dp(320), dp(460), Gravity.TOP or Gravity.END).apply { rightMargin = dp(8); topMargin = dp(64) })
        setContentView(root)
        tts = TextToSpeech(this) {
            tts?.language = Locale("id", "ID")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) { rd.talking = true }
                override fun onDone(u: String?) { rd.talking = false }
                override fun onError(u: String?) { rd.talking = false }
            })
        }
        loadModel(if (prefs.getString("model", "mita") == "custom" && File(filesDir, "custom").exists()) "custom" else prefs.getString("model", "mita") ?: "mita")
    }

    /** Resolusi render diturunkan pada HP lemah: hemat GPU, RAM, dan baterai. */
    private fun applyScale(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val sw = (w * tier.scale).toInt().coerceAtLeast(16); val sh = (h * tier.scale).toInt().coerceAtLeast(16)
        if (sw == fixedW && sh == fixedH) return
        fixedW = sw; fixedH = sh
        gv.holder.setFixedSize(sw, sh)
    }

    private fun lab(t: String) = TextView(this).apply { text = t; setTextColor(0xFF9BD0FF.toInt()); textSize = 13f; setPadding(0, dp(10), 0, dp(2)) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 12f; isAllCaps = false; setOnClickListener { f() } }
    private fun hrow(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } }
    private fun chk(t: String, on: Boolean, f: (Boolean) -> Unit) = CheckBox(this).apply { text = t; setTextColor(Color.WHITE); isChecked = on; textSize = 13f; setOnCheckedChangeListener { _, v -> f(v) } }

    private fun buildPanel() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(12)) }
        c.addView(lab("KARAKTER"))
        c.addView(hrow(btn("Mita") { loadModel("mita") }, btn("Ellen") { loadModel("ellen") }, btn("Model sendiri") { loadModel("custom") }))
        c.addView(btn("Unggah model (PMX/PMD + tekstur / ZIP)") { pick(1, "*/*") })
        c.addView(lab("MATERIAL"))
        c.addView(hrow(btn("Semua tampil") { setAll(true) }, btn("Sembunyi") { setAll(false) }))
        matBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(matBox)
        c.addView(lab("GERAK (VMD / VPD / ZIP posepack)"))
        c.addView(hrow(btn("Tambah") { pick(2, "*/*") }, btn("Stop") { rd.wantReset = true }))
        motBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; c.addView(motBox)
        c.addView(lab("AI (Gemini) — balasan, suara, dan gerak"))
        keyEt = EditText(this).apply { hint = "Kunci API Gemini"; setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); setText(prefs.getString("key", "")); inputType = 129 }
        modEt = EditText(this).apply { setTextColor(Color.WHITE); setText(prefs.getString("gm", "gemini-flash-lite-latest")) }
        voiceCb = CheckBox(this).apply { text = "Suara (TTS)"; setTextColor(Color.WHITE); isChecked = true }
        c.addView(keyEt); c.addView(modEt); c.addView(voiceCb)
        c.addView(btn("Simpan pengaturan AI") { prefs.edit().putString("key", keyEt.text.toString().trim()).putString("gm", modEt.text.toString().trim()).apply(); toast("Tersimpan") })
        c.addView(lab("KUALITAS & PERFORMA"))
        val names = listOf("auto", "normal", "hemat", "ultra")
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Otomatis (sesuai RAM)", "Normal", "Hemat", "Ultra hemat"))
            setSelection(names.indexOf(prefs.getString("qual", "auto") ?: "auto").coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    val q = names[pos]; if (q == (prefs.getString("qual", "auto") ?: "auto")) return
                    prefs.edit().putString("qual", q).apply(); tier = pickTier(); fixedW = 0; applyScale(root.width, root.height)
                    rd.rig?.ikMaxLoop = tier.ik; toast("Kualitas: ${tier.name}")
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        c.addView(sp)
        c.addView(chk("Garis tepi anime", rd.outline) { rd.outline = it; prefs.edit().putBoolean("outline", it).apply() })
        c.addView(chk("Shader anime (gaya v7)", rd.anime) { rd.anime = it; prefs.edit().putBoolean("anime", it).apply() })
        c.addView(chk("Fisika rambut & rok", rd.physOn) { rd.physOn = it; prefs.edit().putBoolean("phys", it).apply() })
        c.addView(TextView(this).apply { text = "Kekuatan fisika"; setTextColor(Color.WHITE); textSize = 12f })
        c.addView(SeekBar(this).apply {
            max = 150; progress = prefs.getInt("physs", 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { rd.physScale = p / 100f }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { prefs.edit().putInt("physs", progress).apply() }
            })
        })
        c.addView(lab("TAMPILAN"))
        c.addView(hrow(btn("Depan") { rd.yaw = 0f }, btn("Kiri") { rd.yaw = 1.57f }, btn("Kanan") { rd.yaw = -1.57f }, btn("Belakang") { rd.yaw = 3.14f }))
        c.addView(btn("Reset kamera") { rd.yaw = 0f; rd.pitch = .05f; rd.zoom = 1f; rd.pan = 0f })
        panel = ScrollView(this).apply { setBackgroundColor(0xEE102030.toInt()); visibility = View.GONE; addView(c) }
    }

    private fun pick(code: Int, mime: String) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), code)
    }
    private fun nameOf(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) return c.getString(i) } }
        return u.lastPathSegment ?: "f"
    }
    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (res != RESULT_OK || d == null) return
        val us = ArrayList<Uri>(); d.clipData?.let { for (i in 0 until it.itemCount) us.add(it.getItemAt(i).uri) }; d.data?.let { us.add(it) }
        Thread {
            try {
                if (rc == 1) {
                    val dir = File(filesDir, "custom"); dir.deleteRecursively(); dir.mkdirs()
                    for (u in us) {
                        val n = nameOf(u)
                        if (n.endsWith(".zip", true)) ZipInputStream(contentResolver.openInputStream(u)).use { z ->
                            var e = z.nextEntry
                            while (e != null) { if (!e.isDirectory) File(dir, e.name.substringAfterLast('/').substringAfterLast('\\').lowercase()).outputStream().use { z.copyTo(it) }; e = z.nextEntry }
                        } else contentResolver.openInputStream(u)?.use { i -> File(dir, n.lowercase()).outputStream().use { i.copyTo(it) } }
                    }
                    loadModel("custom")
                } else {
                    for (u in us) {
                        val n = nameOf(u)
                        if (n.endsWith(".zip", true)) ZipInputStream(contentResolver.openInputStream(u)).use { z ->
                            var e = z.nextEntry
                            while (e != null) { if (!e.isDirectory) addMotion(e.name.substringAfterLast('/'), z.readBytes()); e = z.nextEntry }
                        } else addMotion(n, contentResolver.openInputStream(u)!!.readBytes())
                    }
                    runOnUiThread { motBox.removeAllViews(); motions.forEach { (n, c) -> motBox.addView(btn("▶ $n") { rd.wantClip = c }) } }
                }
            } catch (e: Throwable) { toast("Gagal: " + e.message) }
        }.start()
    }
    private fun addMotion(n: String, d: ByteArray) {
        try { if (n.endsWith(".vmd", true)) motions.add(n to Motion.vmd(d)) else if (n.endsWith(".vpd", true)) motions.add(n to Motion.vpd(d)) } catch (e: Throwable) { toast("$n: ${e.message}") }
    }
    private fun decode(open: () -> InputStream?, max: Int): Bitmap? {
        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
        open()?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = s
        return open()?.use { BitmapFactory.decodeStream(it, null, o2) }
    }
    private fun loadModel(which: String) {
        Thread {
            try {
                val dir = File(filesDir, "custom")
                val bytes = if (which == "custom") (dir.listFiles()?.firstOrNull { it.name.endsWith(".pmx") || it.name.endsWith(".pmd") } ?: throw Exception("Belum ada model sendiri (unggah PMX/PMD)")).readBytes()
                else assets.open("models/$which/model.pmx").readBytes()
                val m = Pmx.parse(bytes); val rig = Rig(m); rig.ikMaxLoop = tier.ik
                if (rig.idx["左腕"] == null || rig.idx["頭"] == null) toast("Model tanpa tulang standar MMD: gerak otomatis terbatas")
                val max = tier.tex
                val tex: (Int) -> Bitmap? = { i ->
                    if (which == "custom") { val p = m.tex.getOrNull(i)?.replace('\\', '/')?.substringAfterLast('/')?.lowercase(); val f = if (p == null) null else File(dir, p); if (f != null && f.exists()) decode({ f.inputStream() }, max) else null }
                    else decode({ try { assets.open("models/$which/t$i.png") } catch (e: Exception) { null } }, max)
                }
                val hid = prefs.getStringSet("hid_$which", emptySet()) ?: emptySet()
                m.mats.forEachIndexed { i, mt -> if (hid.contains(i.toString())) mt.vis = false }
                rd.sleepy = which == "ellen"
                gv.queueEvent { rd.setModel(m, rig, tex) }
                cur = which; prefs.edit().putString("model", which).apply()
                runOnUiThread { buildMats(m) }
                if (!rig.hasPhysics) toast("Model ini tidak punya data fisika (rambut/rok diam)")
            } catch (e: Throwable) { toast("Gagal memuat: " + e.message) }
        }.start()
    }
    private fun buildMats(m: PmxModel) {
        matBox.removeAllViews()
        m.mats.forEachIndexed { _, mt ->
            val cb = CheckBox(this).apply { text = mt.name; setTextColor(Color.WHITE); isChecked = mt.vis; textSize = 12f }
            cb.setOnCheckedChangeListener { _, v -> mt.vis = v; saveHid(m) }
            matBox.addView(cb)
        }
        curModel = m
    }
    private var curModel: PmxModel? = null
    private fun saveHid(m: PmxModel) { prefs.edit().putStringSet("hid_$cur", m.mats.withIndex().filter { !it.value.vis }.map { it.index.toString() }.toSet()).apply() }
    private fun setAll(v: Boolean) { curModel?.let { m -> m.mats.forEach { it.vis = v }; buildMats(m); saveHid(m) } }

    // ------------------------------------------------------------------ AI: balasan + emosi + gerak
    private fun toAny(o: Any?): Any? = when (o) {
        is JSONObject -> { val m = HashMap<String, Any?>(); val it = o.keys(); while (it.hasNext()) { val k = it.next(); m[k] = toAny(o.opt(k)) }; m }
        is JSONArray -> List(o.length()) { toAny(o.opt(it)) }
        JSONObject.NULL -> null
        else -> o
    }
    private fun gcall(model: String, key: String, body: JSONObject): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code != 200) throw Exception("HTTP $code" + (if (code == 429) " (kuota penuh)" else if (code == 400 || code == 403) " (cek kunci/model)" else if (code == 404) " (model tidak ada)" else ""))
        return c.inputStream.bufferedReader().readText()
    }
    private fun ask(text: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) { bubble.text = "Isi kunci API Gemini dulu di ⚙ > AI."; return }
        bubble.text = "…"; tts?.stop(); rd.talking = false
        val name = if (cur == "ellen") "Ellen Joe, gadis hiu pelayan yang pemalas, datar dan santai" else if (cur == "mita") "Mita, cewek anime ceria, imut, manja-manja jahil" else "karakter anime ramah"
        val sys = "Kamu adalah $name, jadi teman ngobrol virtual yang punya perasaan sendiri. Balas HANYA satu objek JSON valid (tanpa markdown): " +
            "{\"id\":\"balasan Bahasa Indonesia maks 2 kalimat, tanpa emoji dan tanpa narasi aksi\",\"rasa\":\"satu dari senang|riang|sedih|marah|malu|kaget|bosan|ngantuk|tenang\",\"rencana\":\"(hanya bila bergerak)\",\"gerak\":[...keyframe, hanya bila diminta bergerak]}." + MOTION
        hist.add("user" to text)
        Thread {
            try {
                val cs = JSONArray(); hist.takeLast(6).forEach { (r, t) -> cs.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t)))) }
                val models = listOf(prefs.getString("gm", "") ?: "", "gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash").filter { it.isNotBlank() }.distinct()
                var raw: String? = null; var err: Exception? = null
                loop@ for (mo in models) for (think in listOf(true, false)) {
                    val gc = JSONObject().put("maxOutputTokens", 1400).put("temperature", .95).put("responseMimeType", "application/json")
                    if (think) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                    val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))).put("contents", cs).put("generationConfig", gc)
                    try { raw = gcall(mo, key, body); break@loop }
                    catch (e: Exception) { err = e; val m = e.message ?: ""; if (m.startsWith("HTTP 400") && think) continue; if (m.startsWith("HTTP 404")) break; throw e }
                }
                val resp = raw ?: throw (err ?: Exception("tidak ada jawaban"))
                val parts = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder(); if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                var js = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                val a = js.indexOf('{'); val z = js.lastIndexOf('}'); if (a >= 0 && z > a) js = js.substring(a, z + 1)
                val o = JSONObject(js)
                val say = o.optString("id", "").ifBlank { o.optString("balasan", "") }.ifBlank { "…" }
                rd.emoName = o.optString("rasa", "tenang").lowercase()
                @Suppress("UNCHECKED_CAST") val plan = toAny(o) as? Map<*, *>
                if (plan != null && (plan["gerak"] is List<*>)) rd.pendingPlan = plan
                hist.add("model" to say)
                runOnUiThread { bubble.text = say }
                if (voiceCb.isChecked && say.isNotBlank()) runOnUiThread { tts?.speak(say, TextToSpeech.QUEUE_FLUSH, null, "u") }
            } catch (e: Throwable) { hist.removeLastOrNull(); runOnUiThread { bubble.text = "Ups: " + e.message } }
        }.start()
    }

    private fun startLoop() { if (running) return; running = true; lastRender = 0L; Choreographer.getInstance().postFrameCallback(frameCb) }
    override fun onPause() { running = false; Choreographer.getInstance().removeFrameCallback(frameCb); super.onPause(); gv.onPause() }
    override fun onResume() {
        super.onResume(); gv.onResume(); startLoop()
        rd.status?.let { toast(it); rd.status = null }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
