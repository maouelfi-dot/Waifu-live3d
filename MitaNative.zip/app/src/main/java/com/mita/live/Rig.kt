package com.mita.live

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

class Track(val f: IntArray, val q: FloatArray, val p: FloatArray, val ip: FloatArray)
class Clip(val tr: Map<String, Track>, val frames: Int)

object Motion {
    private val sj = charset("Shift_JIS")
    private class K(val f: Int, val q: FloatArray, val p: FloatArray, val ip: FloatArray)
    private fun pack(m: Map<String, MutableList<K>>): Clip {
        var mx = 0
        val out = HashMap<String, Track>()
        for ((n, l) in m) {
            l.sortBy { it.f }
            val q = FloatArray(l.size * 4); val p = FloatArray(l.size * 3); val ipa = FloatArray(l.size * 16)
            l.forEachIndexed { i, k -> System.arraycopy(k.q, 0, q, i * 4, 4); System.arraycopy(k.p, 0, p, i * 3, 3); System.arraycopy(k.ip, 0, ipa, i * 16, 16); mx = max(mx, k.f) }
            out[n] = Track(IntArray(l.size) { l[it].f }, q, p, ipa)
        }
        return Clip(out, mx)
    }
    fun vmd(d: ByteArray): Clip {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        if (d.size < 54 || !String(d, 0, 20).startsWith("Vocaloid Motion Data")) throw IllegalArgumentException("Bukan file VMD")
        b.position(50)
        val n = b.int
        val m = HashMap<String, MutableList<K>>()
        val nm = ByteArray(15)
        for (i in 0 until n) {
            b.get(nm); var l = 0; while (l < 15 && nm[l].toInt() != 0) l++
            val name = String(nm, 0, l, sj)
            val f = b.int
            val px = b.float; val py = b.float; val pz = -b.float
            val qx = -b.float; val qy = -b.float; val qz = b.float; val qw = b.float
            val ib = ByteArray(64); b.get(ib)
            val ip = FloatArray(16) { j -> (ib[(j / 4) + (j % 4) * 4].toInt() and 255) / 127f }
            m.getOrPut(name) { ArrayList() }.add(K(f, floatArrayOf(qx, qy, qz, qw), floatArrayOf(px, py, pz), ip))
        }
        return pack(m)
    }
    fun vpd(d: ByteArray): Clip {
        val s = String(d, sj)
        val re = Regex("Bone\\d+\\{([^\\r\\n]+)\\s+([-\\d.eE]+),([-\\d.eE]+),([-\\d.eE]+);[^\\n]*\\s+([-\\d.eE]+),([-\\d.eE]+),([-\\d.eE]+),([-\\d.eE]+);")
        val m = HashMap<String, MutableList<K>>()
        for (r in re.findAll(s)) {
            val v = r.groupValues.drop(2).map { it.toFloat() }
            m[r.groupValues[1].trim()] = mutableListOf(K(0, floatArrayOf(-v[3], -v[4], v[5], v[6]), floatArrayOf(v[0], v[1], -v[2]), FloatArray(16) { if (it % 4 < 2) 20f / 127f else 107f / 127f }))
        }
        if (m.isEmpty()) throw IllegalArgumentException("Bukan file VPD")
        return pack(m)
    }
}

class Rig(val m: PmxModel) {
    val nb = m.bones.size
    val lq = FloatArray(nb * 4); val lt = FloatArray(nb * 3); val tq = FloatArray(nb * 4)
    private val driven = BooleanArray(nb)
    private val wq = FloatArray(nb * 4); val wt = FloatArray(nb * 3)
    private val par = IntArray(nb)
    val idx = HashMap<String, Int>(); val mIdx = HashMap<String, Int>()
    private val order: IntArray
    val out = FloatArray(m.nv * 8)
    val mw = FloatArray(m.morphs.size)
    private val bp = FloatArray(m.nv * 3)
    private val tmp = FloatArray(3)
    var top = 0f; var bottom = 0f

    val phys = ArrayList<Int>(); var physOn = true; var physK = 1f; private var warm = 0
    var minX = 0f; var maxX = 0f; var minZ = 0f; var maxZ = 0f
    private val isPhys = BooleanArray(nb); private val pq = FloatArray(nb * 4)
    private val pk = FloatArray(nb); private val pc = FloatArray(nb); private val pg = FloatArray(nb); private val pl = FloatArray(nb)
    private val pph = FloatArray(nb * 3); private val pom = FloatArray(nb * 3)
    private val d0 = FloatArray(nb * 3); private val prev = FloatArray(nb * 3); private val prev2 = FloatArray(nb * 3); private val ext = FloatArray(nb * 3)
    private var wasMorph = false
    init {
        for (i in 0 until nb) { lq[i * 4 + 3] = 1f; tq[i * 4 + 3] = 1f; idx[m.bones[i].name] = i; par[i] = if (m.bones[i].parent in 0 until nb) m.bones[i].parent else -1 }
        m.morphs.forEachIndexed { i, mo -> mIdx[mo.name] = i }
        val depth = IntArray(nb)
        for (i in 0 until nb) { var d = 0; var p = par[i]; while (p >= 0 && d < 512) { d++; p = par[p] }; depth[i] = d }
        order = (0 until nb).sortedBy { depth[it] }.toIntArray()
        for (i in 0 until m.nv) { out[i * 8 + 6] = m.uv[i * 2]; out[i * 8 + 7] = m.uv[i * 2 + 1] }
        top = -1e9f; bottom = 1e9f
        for (i in 0 until m.nv) { top = max(top, m.pos[i * 3 + 1]); bottom = min(bottom, m.pos[i * 3 + 1]) }
        minX = 1e9f; maxX = -1e9f; minZ = 1e9f; maxZ = -1e9f
        for (i in 0 until m.nv) { minX = min(minX, m.pos[i * 3]); maxX = max(maxX, m.pos[i * 3]); minZ = min(minZ, m.pos[i * 3 + 2]); maxZ = max(maxZ, m.pos[i * 3 + 2]) }
        for (i in 0 until nb) pq[i * 4 + 3] = 1f
        detectPhys()
    }
    fun bonePos(n: String): FloatArray? { val i = idx[n] ?: return null; val b = m.bones[i]; return floatArrayOf(b.x, b.y, b.z) }
    private fun rot(q: FloatArray, o: Int, x: Float, y: Float, z: Float, r: FloatArray) {
        val qx = q[o]; val qy = q[o + 1]; val qz = q[o + 2]; val qw = q[o + 3]
        val tx = 2 * (qy * z - qz * y); val ty = 2 * (qz * x - qx * z); val tz = 2 * (qx * y - qy * x)
        r[0] = x + qw * tx + (qy * tz - qz * ty); r[1] = y + qw * ty + (qz * tx - qx * tz); r[2] = z + qw * tz + (qx * ty - qy * tx)
    }
    fun drive(n: String, x: Float, y: Float, z: Float) {
        val i = idx[n] ?: return
        val c1 = cos(x / 2); val c2 = cos(y / 2); val c3 = cos(z / 2); val s1 = sin(x / 2); val s2 = sin(y / 2); val s3 = sin(z / 2)
        tq[i * 4] = s1 * c2 * c3 + c1 * s2 * s3; tq[i * 4 + 1] = c1 * s2 * c3 - s1 * c2 * s3
        tq[i * 4 + 2] = c1 * c2 * s3 + s1 * s2 * c3; tq[i * 4 + 3] = c1 * c2 * c3 - s1 * s2 * s3
        driven[i] = true
    }
    fun smooth(dt: Float) {
        val k = 1f - exp(-dt * 18f)
        for (i in 0 until nb) if (driven[i]) {
            val o = i * 4
            val sg = if (lq[o] * tq[o] + lq[o + 1] * tq[o + 1] + lq[o + 2] * tq[o + 2] + lq[o + 3] * tq[o + 3] < 0) -1f else 1f
            for (j in 0..3) lq[o + j] += (tq[o + j] * sg - lq[o + j]) * k
            val l = sqrt(lq[o] * lq[o] + lq[o + 1] * lq[o + 1] + lq[o + 2] * lq[o + 2] + lq[o + 3] * lq[o + 3])
            for (j in 0..3) lq[o + j] /= l
        }
    }
    fun resetPose() { java.util.Arrays.fill(lt, 0f); for (i in 0 until nb) { for (j in 0..3) lq[i * 4 + j] = if (j == 3) 1f else 0f } }
    private fun bez(ip: FloatArray, o: Int, u: Float): Float {
        val x1 = ip[o]; val y1 = ip[o + 1]; val x2 = ip[o + 2]; val y2 = ip[o + 3]
        var lo = 0f; var hi = 1f; var t = u
        for (k in 0 until 10) { t = (lo + hi) / 2; val x = 3 * (1 - t) * (1 - t) * t * x1 + 3 * (1 - t) * t * t * x2 + t * t * t; if (x < u) lo = t else hi = t }
        return 3 * (1 - t) * (1 - t) * t * y1 + 3 * (1 - t) * t * t * y2 + t * t * t
    }
    fun applyClip(c: Clip, f: Float) {
        for ((n, tr) in c.tr) {
            val i = idx[n] ?: continue
            val fr = tr.f; var a = 0
            while (a < fr.size - 1 && fr[a + 1] <= f) a++
            val b2 = min(a + 1, fr.size - 1)
            val u = if (b2 == a || f <= fr[a]) 0f else min(1f, (f - fr[a]) / (fr[b2] - fr[a]).toFloat())
            val ur = bez(tr.ip, b2 * 16 + 12, u)
            val sg = if (tr.q[a * 4] * tr.q[b2 * 4] + tr.q[a * 4 + 1] * tr.q[b2 * 4 + 1] + tr.q[a * 4 + 2] * tr.q[b2 * 4 + 2] + tr.q[a * 4 + 3] * tr.q[b2 * 4 + 3] < 0) -1f else 1f
            var l = 0f
            for (j in 0..3) { val v = tr.q[a * 4 + j] + (tr.q[b2 * 4 + j] * sg - tr.q[a * 4 + j]) * ur; lq[i * 4 + j] = v; l += v * v }
            l = sqrt(l); for (j in 0..3) lq[i * 4 + j] /= l
            for (j in 0..2) { val uj = bez(tr.ip, b2 * 16 + j * 4, u); lt[i * 3 + j] = tr.p[a * 3 + j] + (tr.p[b2 * 3 + j] - tr.p[a * 3 + j]) * uj }
        }
    }
    private fun fk(i: Int) {
        run {
            val b = m.bones[i]; val p = par[i]
            val rx = b.x - (if (p >= 0) m.bones[p].x else 0f) + lt[i * 3]
            val ry = b.y - (if (p >= 0) m.bones[p].y else 0f) + lt[i * 3 + 1]
            val rz = b.z - (if (p >= 0) m.bones[p].z else 0f) + lt[i * 3 + 2]
            if (p < 0) {
                for (j in 0..3) wq[i * 4 + j] = lq[i * 4 + j]
                wt[i * 3] = rx; wt[i * 3 + 1] = ry; wt[i * 3 + 2] = rz
            } else {
                rot(wq, p * 4, rx, ry, rz, tmp)
                wt[i * 3] = wt[p * 3] + tmp[0]; wt[i * 3 + 1] = wt[p * 3 + 1] + tmp[1]; wt[i * 3 + 2] = wt[p * 3 + 2] + tmp[2]
                val a = p * 4; val c = i * 4
                val ax = wq[a]; val ay = wq[a + 1]; val az = wq[a + 2]; val aw = wq[a + 3]
                val bx0 = lq[c]; val by0 = lq[c + 1]; val bz0 = lq[c + 2]; val bw0 = lq[c + 3]
                var bx = bx0; var by = by0; var bz = bz0; var bw = bw0
                if (isPhys[i]) {
                    val qx = pq[c]; val qy = pq[c + 1]; val qz = pq[c + 2]; val qw = pq[c + 3]
                    bx = bw0 * qx + bx0 * qw + by0 * qz - bz0 * qy; by = bw0 * qy - bx0 * qz + by0 * qw + bz0 * qx
                    bz = bw0 * qz + bx0 * qy - by0 * qx + bz0 * qw; bw = bw0 * qw - bx0 * qx - by0 * qy - bz0 * qz
                }
                wq[c] = aw * bx + ax * bw + ay * bz - az * by; wq[c + 1] = aw * by - ax * bz + ay * bw + az * bx
                wq[c + 2] = aw * bz + ax * by - ay * bx + az * bw; wq[c + 3] = aw * bw - ax * bx - ay * by - az * bz
            }
        }
    }
    var useIk = false
    private val ikOrder: List<MIk> by lazy { m.iks.sortedBy { depthOf(it.ik) } }
    private fun depthOf(i: Int): Int { var d = 0; var p = par[i]; while (p >= 0 && d < 512) { d++; p = par[p] }; return d }
    private val qc = FloatArray(4); private val va = FloatArray(3); private val vb = FloatArray(3)
    private fun solve(ik: MIk) {
        if (ik.target !in 0 until nb || ik.ik !in 0 until nb || ik.links.isEmpty()) return
        var topL = ik.links[0]
        for (l in ik.links) if (l in 0 until nb && depthOf(l) < depthOf(topL)) topL = l
        val path = ArrayList<Int>(); var x = ik.target; var g = 0
        while (x >= 0 && g < 64) { path.add(x); if (x == topL) break; x = par[x]; g++ }
        path.reverse()
        for (iter in 0 until min(ik.loop, 8)) {
            for (li in ik.links) {
                if (li !in 0 until nb) continue
                val o = li * 4
                qc[0] = -wq[o]; qc[1] = -wq[o + 1]; qc[2] = -wq[o + 2]; qc[3] = wq[o + 3]
                rot(qc, 0, wt[ik.target * 3] - wt[li * 3], wt[ik.target * 3 + 1] - wt[li * 3 + 1], wt[ik.target * 3 + 2] - wt[li * 3 + 2], va)
                rot(qc, 0, wt[ik.ik * 3] - wt[li * 3], wt[ik.ik * 3 + 1] - wt[li * 3 + 1], wt[ik.ik * 3 + 2] - wt[li * 3 + 2], vb)
                val la = sqrt(va[0] * va[0] + va[1] * va[1] + va[2] * va[2]); val lb = sqrt(vb[0] * vb[0] + vb[1] * vb[1] + vb[2] * vb[2])
                if (la < 1e-6f || lb < 1e-6f) continue
                for (j in 0..2) { va[j] /= la; vb[j] /= lb }
                val dot = (va[0] * vb[0] + va[1] * vb[1] + va[2] * vb[2]).coerceIn(-1f, 1f)
                var ang = acos(dot); if (ang < 1e-4f) continue
                ang = min(ang, ik.limit)
                var ax = va[1] * vb[2] - va[2] * vb[1]; var ay = va[2] * vb[0] - va[0] * vb[2]; var az = va[0] * vb[1] - va[1] * vb[0]
                val al = sqrt(ax * ax + ay * ay + az * az); if (al < 1e-6f) continue
                val sn = sin(ang / 2) / al; ax *= sn; ay *= sn; az *= sn; val aw = cos(ang / 2)
                val bx = lq[o]; val by = lq[o + 1]; val bz = lq[o + 2]; val bw = lq[o + 3]
                var nx = bw * ax + bx * aw + by * az - bz * ay
                var ny = bw * ay - bx * az + by * aw + bz * ax
                var nz = bw * az + bx * ay - by * ax + bz * aw
                var nw = bw * aw - bx * ax - by * ay - bz * az
                if (m.bones[li].name.contains("ひざ")) {
                    if (nw < 0) { nx = -nx; nw = -nw }
                    var xa = 2f * atan2(nx, nw); if (xa < .003f) xa = .003f; if (xa > 3f) xa = 3f
                    nx = sin(xa / 2); ny = 0f; nz = 0f; nw = cos(xa / 2)
                }
                val nl = sqrt(nx * nx + ny * ny + nz * nz + nw * nw)
                lq[o] = nx / nl; lq[o + 1] = ny / nl; lq[o + 2] = nz / nl; lq[o + 3] = nw / nl
                for (pi in path) fk(pi)
            }
        }
    }
    private fun detectPhys() {
        val hair = Regex("髪|ヘア|hair|ahoge|アホ毛|ポニ|ツイン|twin|bang", RegexOption.IGNORE_CASE)
        val skirt = Regex("スカート|skirt|裾")
        val cloth = Regex("袖|sleeve|マント|cape|ケープ|ネクタイ|tie|リボン|ribbon|ひも|紐|フリル|frill|布|cloth|コート|coat|羽織|帯|obi|襟|マフラー|scarf|ドレス|dress|飾り|垂れ|ゆれ|揺", RegexOption.IGNORE_CASE)
        val tail = Regex("尻尾|しっぽ|シッポ|tail|耳|ear", RegexOption.IGNORE_CASE)
        for (i in 0 until nb) {
            val n = m.bones[i].name
            if (n.contains("ＩＫ") || n.contains("IK") || n.contains("親") || n.contains("ダミー")) continue
            val cl = when { tail.containsMatchIn(n) -> 3; hair.containsMatchIn(n) -> 0; skirt.containsMatchIn(n) -> 1; cloth.containsMatchIn(n) -> 2; else -> -1 }
            if (cl < 0) continue
            isPhys[i] = true; phys.add(i)
            when (cl) { 0 -> { pk[i] = 55f; pc[i] = 5f; pg[i] = 1.7f; pl[i] = .75f }; 1 -> { pk[i] = 80f; pc[i] = 7f; pg[i] = 1.1f; pl[i] = .5f }
                2 -> { pk[i] = 70f; pc[i] = 6f; pg[i] = 1.3f; pl[i] = .6f }; else -> { pk[i] = 60f; pc[i] = 4.5f; pg[i] = 1.8f; pl[i] = .8f } }
            var ch = -1
            for (j in 0 until nb) if (par[j] == i) { if (ch < 0) ch = j; if (isNameHit(j)) { ch = j; break } }
            val b = m.bones[i]
            var dx: Float; var dy: Float; var dz: Float
            if (ch >= 0) { dx = m.bones[ch].x - b.x; dy = m.bones[ch].y - b.y; dz = m.bones[ch].z - b.z }
            else if (par[i] >= 0) { dx = b.x - m.bones[par[i]].x; dy = b.y - m.bones[par[i]].y; dz = b.z - m.bones[par[i]].z }
            else { dx = 0f; dy = -1f; dz = 0f }
            var l = sqrt(dx * dx + dy * dy + dz * dz)
            if (l < 1e-5f) { dx = 0f; dy = -1f; dz = 0f; l = 1f }
            d0[i * 3] = dx / l; d0[i * 3 + 1] = dy / l; d0[i * 3 + 2] = dz / l
        }
    }
    private fun isNameHit(j: Int): Boolean = isPhys[j]
    fun impulse(i: Int, x: Float, y: Float, z: Float) { ext[i * 3] += x; ext[i * 3 + 1] += y; ext[i * 3 + 2] += z }
    fun physics(dt: Float) {
        if (phys.isEmpty() || dt <= 0f) return
        if (!physOn) { for (i in phys) { pq[i * 4] = 0f; pq[i * 4 + 1] = 0f; pq[i * 4 + 2] = 0f; pq[i * 4 + 3] = 1f }; return }
        if (warm < 3) return
        val sc = physK / max(top - bottom, 1f)
        val steps = if (dt > .022f) 2 else 1; val h = dt / steps
        for (i in phys) {
            val o = i * 3; val q4 = i * 4
            var fx = -((wt[o] - 2 * prev[o] + prev2[o]) / (dt * dt) + ext[o]) * sc
            var fy = -((wt[o + 1] - 2 * prev[o + 1] + prev2[o + 1]) / (dt * dt) + ext[o + 1]) * sc
            var fz = -((wt[o + 2] - 2 * prev[o + 2] + prev2[o + 2]) / (dt * dt) + ext[o + 2]) * sc
            for (k in 0..2) { prev2[o + k] = prev[o + k]; prev[o + k] = wt[o + k]; ext[o + k] = 0f }
            val fm = sqrt(fx * fx + fy * fy + fz * fz)
            if (fm > 70f) { val s = 70f / fm; fx *= s; fy *= s; fz *= s }
            qc[0] = -wq[q4]; qc[1] = -wq[q4 + 1]; qc[2] = -wq[q4 + 2]; qc[3] = wq[q4 + 3]
            rot(qc, 0, fx, fy, fz, va)
            val tx = d0[o + 1] * va[2] - d0[o + 2] * va[1]
            val ty = d0[o + 2] * va[0] - d0[o] * va[2]
            val tz = d0[o] * va[1] - d0[o + 1] * va[0]
            val gk = pg[i]; val kk = pk[i]; val cc = pc[i]
            for (s in 0 until steps) {
                pom[o] += (gk * tx - kk * pph[o] - cc * pom[o]) * h
                pom[o + 1] += (gk * ty - kk * pph[o + 1] - cc * pom[o + 1]) * h
                pom[o + 2] += (gk * tz - kk * pph[o + 2] - cc * pom[o + 2]) * h
                pph[o] += pom[o] * h; pph[o + 1] += pom[o + 1] * h; pph[o + 2] += pom[o + 2] * h
            }
            var l = sqrt(pph[o] * pph[o] + pph[o + 1] * pph[o + 1] + pph[o + 2] * pph[o + 2])
            if (l > pl[i]) { val s = pl[i] / l; pph[o] *= s; pph[o + 1] *= s; pph[o + 2] *= s; pom[o] *= .5f; pom[o + 1] *= .5f; pom[o + 2] *= .5f; l = pl[i] }
            if (l < 1e-5f) { pq[q4] = 0f; pq[q4 + 1] = 0f; pq[q4 + 2] = 0f; pq[q4 + 3] = 1f }
            else { val sn = sin(l / 2) / l; pq[q4] = pph[o] * sn; pq[q4 + 1] = pph[o + 1] * sn; pq[q4 + 2] = pph[o + 2] * sn; pq[q4 + 3] = cos(l / 2) }
        }
    }
    fun boneData(o: FloatArray) {
        for (i in 0 until nb) {
            val b = m.bones[i]; rot(wq, i * 4, b.x, b.y, b.z, tmp); val k = i * 8
            o[k] = wq[i * 4]; o[k + 1] = wq[i * 4 + 1]; o[k + 2] = wq[i * 4 + 2]; o[k + 3] = wq[i * 4 + 3]
            o[k + 4] = wt[i * 3] - tmp[0]; o[k + 5] = wt[i * 3 + 1] - tmp[1]; o[k + 6] = wt[i * 3 + 2] - tmp[2]; o[k + 7] = 0f
        }
    }
    fun morphed(): FloatArray? {
        var any = false
        for (k in mw.indices) if (mw[k] > .002f) {
            if (!any) { System.arraycopy(m.pos, 0, bp, 0, bp.size); any = true }
            val mo = m.morphs[k]
            for (j in mo.vi.indices) { val v = mo.vi[j]; if (v < m.nv) { bp[v * 3] += mw[k] * mo.off[j * 3]; bp[v * 3 + 1] += mw[k] * mo.off[j * 3 + 1]; bp[v * 3 + 2] += mw[k] * mo.off[j * 3 + 2] } }
        }
        if (any) { wasMorph = true; return bp }
        if (wasMorph) { wasMorph = false; return m.pos }
        return null
    }
    fun update() {
        for (i in order) fk(i)
        if (useIk) { for (ik in ikOrder) { for (i in order) fk(i); solve(ik) }; for (i in order) fk(i) }
        warm++
    }
}
