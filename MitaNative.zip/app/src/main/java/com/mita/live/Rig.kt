package com.mita.live

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

class Track(val f: IntArray, val q: FloatArray, val p: FloatArray, val bez: ByteArray?)
class MTrack(val f: IntArray, val w: FloatArray)
class Clip(val tr: Map<String, Track>, val frames: Int, val mo: Map<String, MTrack> = emptyMap())

// ---------------------------------------------------------------- util kuaternion (tanpa alokasi)
internal fun qmul(a: FloatArray, ao: Int, b: FloatArray, bo: Int, o: FloatArray, oo: Int) {
    val ax = a[ao]; val ay = a[ao + 1]; val az = a[ao + 2]; val aw = a[ao + 3]
    val bx = b[bo]; val by = b[bo + 1]; val bz = b[bo + 2]; val bw = b[bo + 3]
    o[oo] = aw * bx + ax * bw + ay * bz - az * by
    o[oo + 1] = aw * by - ax * bz + ay * bw + az * bx
    o[oo + 2] = aw * bz + ax * by - ay * bx + az * bw
    o[oo + 3] = aw * bw - ax * bx - ay * by - az * bz
}
internal fun qrot(q: FloatArray, o: Int, x: Float, y: Float, z: Float, r: FloatArray) {
    val qx = q[o]; val qy = q[o + 1]; val qz = q[o + 2]; val qw = q[o + 3]
    val tx = 2 * (qy * z - qz * y); val ty = 2 * (qz * x - qx * z); val tz = 2 * (qx * y - qy * x)
    r[0] = x + qw * tx + (qy * tz - qz * ty); r[1] = y + qw * ty + (qz * tx - qx * tz); r[2] = z + qw * tz + (qx * ty - qy * tx)
}
internal fun qrotInv(q: FloatArray, o: Int, x: Float, y: Float, z: Float, r: FloatArray) {
    val qx = -q[o]; val qy = -q[o + 1]; val qz = -q[o + 2]; val qw = q[o + 3]
    val tx = 2 * (qy * z - qz * y); val ty = 2 * (qz * x - qx * z); val tz = 2 * (qx * y - qy * x)
    r[0] = x + qw * tx + (qy * tz - qz * ty); r[1] = y + qw * ty + (qz * tx - qx * tz); r[2] = z + qw * tz + (qx * ty - qy * tx)
}
internal fun qnorm(q: FloatArray, o: Int) {
    val l = sqrt(q[o] * q[o] + q[o + 1] * q[o + 1] + q[o + 2] * q[o + 2] + q[o + 3] * q[o + 3])
    if (l < 1e-9f) { q[o] = 0f; q[o + 1] = 0f; q[o + 2] = 0f; q[o + 3] = 1f; return }
    val i = 1f / l; q[o] *= i; q[o + 1] *= i; q[o + 2] *= i; q[o + 3] *= i
}
/** rotasi terkecil dari vektor satuan a ke b */
internal fun qfromTo(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, q: FloatArray, o: Int) {
    val d = ax * bx + ay * by + az * bz
    if (d < -.999999f) {
        // berlawanan: pilih sumbu tegak lurus
        var px = -az; var py = 0f; var pz = ax
        if (px * px + pz * pz < 1e-6f) { px = 0f; py = az; pz = -ay }
        val l = sqrt(px * px + py * py + pz * pz)
        q[o] = px / l; q[o + 1] = py / l; q[o + 2] = pz / l; q[o + 3] = 0f; return
    }
    q[o] = ay * bz - az * by; q[o + 1] = az * bx - ax * bz; q[o + 2] = ax * by - ay * bx; q[o + 3] = 1f + d
    qnorm(q, o)
}
/** slerp(identitas, q, r); r boleh negatif (kebalikan) */
internal fun qpow(q: FloatArray, o: Int, r: Float, out: FloatArray, oo: Int) {
    var x = q[o]; var y = q[o + 1]; var z = q[o + 2]; var w = q[o + 3]; var rr = r
    if (rr < 0f) { x = -x; y = -y; z = -z; rr = -rr }
    if (w < 0f) { x = -x; y = -y; z = -z; w = -w }
    val th = acos(min(1f, w)); val sn = sin(th)
    if (sn < 1e-5f) { out[oo] = x * rr; out[oo + 1] = y * rr; out[oo + 2] = z * rr; out[oo + 3] = 1f; qnorm(out, oo); return }
    val a = sin((1f - rr) * th) / sn; val b = sin(rr * th) / sn
    out[oo] = x * b; out[oo + 1] = y * b; out[oo + 2] = z * b; out[oo + 3] = a + w * b
}
internal fun qeuler(x: Float, y: Float, z: Float, o: FloatArray, oo: Int) {
    val c1 = cos(x / 2); val c2 = cos(y / 2); val c3 = cos(z / 2); val s1 = sin(x / 2); val s2 = sin(y / 2); val s3 = sin(z / 2)
    o[oo] = s1 * c2 * c3 + c1 * s2 * s3; o[oo + 1] = c1 * s2 * c3 - s1 * c2 * s3
    o[oo + 2] = c1 * c2 * s3 + s1 * s2 * c3; o[oo + 3] = c1 * c2 * c3 - s1 * s2 * s3
}
internal fun toEuler(q: FloatArray, o: Int, r: FloatArray) {
    val x = q[o]; val y = q[o + 1]; val z = q[o + 2]; val w = q[o + 3]
    val xx = x * x; val yy = y * y; val zz = z * z
    val m13 = 2 * (x * z + y * w)
    r[1] = asin(m13.coerceIn(-1f, 1f))
    if (abs(m13) < .9999999f) { r[0] = atan2(-2 * (y * z - x * w), 1 - 2 * (xx + yy)); r[2] = atan2(-2 * (x * y - z * w), 1 - 2 * (yy + zz)) }
    else { r[0] = atan2(2 * (y * z + x * w), 1 - 2 * (xx + zz)); r[2] = 0f }
}

// ---------------------------------------------------------------- gerak
object Motion {
    private val sj = charset("Shift_JIS")

    fun vmd(d: ByteArray): Clip {
        if (d.size < 54 || !String(d, 0, 20, Charsets.ISO_8859_1).startsWith("Vocaloid Motion Data")) throw IllegalArgumentException("Bukan file VMD")
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        b.position(50)
        val n = b.int
        if (n < 0 || n > 3_000_000 || b.position().toLong() + n.toLong() * 111L > d.size) throw IllegalArgumentException("VMD rusak")
        val raw = HashMap<String, Int>(); val names = ArrayList<String>()
        val fr = IntArray(n); val dat = FloatArray(n * 7); val ip = ByteArray(n * 16); val tid = IntArray(n)
        val nm = ByteArray(15)
        for (i in 0 until n) {
            b.get(nm); var l = 0; while (l < 15 && nm[l].toInt() != 0) l++
            val rk = String(nm, 0, l, Charsets.ISO_8859_1)
            var id = raw[rk]
            if (id == null) { id = names.size; raw[rk] = id; names.add(String(nm, 0, l, sj)) }
            tid[i] = id; fr[i] = b.int
            val o = i * 7
            dat[o] = b.float; dat[o + 1] = b.float; dat[o + 2] = -b.float
            dat[o + 3] = -b.float; dat[o + 4] = -b.float; dat[o + 5] = b.float; dat[o + 6] = b.float
            b.get(ip, i * 16, 16); b.position(b.position() + 48)
        }
        val cnt = IntArray(names.size); for (i in 0 until n) cnt[tid[i]]++
        val keys = Array(names.size) { LongArray(cnt[it]) }; val fill = IntArray(names.size)
        for (i in 0 until n) { val t = tid[i]; keys[t][fill[t]++] = (fr[i].toLong() shl 32) or i.toLong() }
        var mx = 0; val out = HashMap<String, Track>()
        for (t in names.indices) {
            val ks = keys[t]; java.util.Arrays.sort(ks); val m = ks.size
            val f = IntArray(m); val q = FloatArray(m * 4); val p = FloatArray(m * 3); val bz = ByteArray(m * 16)
            for (j in 0 until m) {
                val i = (ks[j] and 0xffffffffL).toInt(); f[j] = fr[i]; if (fr[i] > mx) mx = fr[i]
                System.arraycopy(dat, i * 7, p, j * 3, 3); System.arraycopy(dat, i * 7 + 3, q, j * 4, 4)
                System.arraycopy(ip, i * 16, bz, j * 16, 16)
            }
            out[names[t]] = Track(f, q, p, bz)
        }
        // keyframe morf (ekspresi/bibir)
        val mo = HashMap<String, MTrack>()
        try {
            if (b.remaining() >= 4) {
                val mn = b.int
                if (mn in 1..2_000_000 && b.remaining().toLong() >= mn.toLong() * 23L) {
                    val rm = HashMap<String, Int>(); val mnames = ArrayList<String>()
                    val mt = IntArray(mn); val mf = IntArray(mn); val mwt = FloatArray(mn)
                    for (i in 0 until mn) {
                        b.get(nm); var l = 0; while (l < 15 && nm[l].toInt() != 0) l++
                        val rk = String(nm, 0, l, Charsets.ISO_8859_1)
                        var id = rm[rk]
                        if (id == null) { id = mnames.size; rm[rk] = id; mnames.add(String(nm, 0, l, sj)) }
                        mt[i] = id; mf[i] = b.int; mwt[i] = b.float
                    }
                    val mc = IntArray(mnames.size); for (i in 0 until mn) mc[mt[i]]++
                    val mk = Array(mnames.size) { LongArray(mc[it]) }; val mfill = IntArray(mnames.size)
                    for (i in 0 until mn) { val t = mt[i]; mk[t][mfill[t]++] = (mf[i].toLong() shl 32) or i.toLong() }
                    for (t in mnames.indices) {
                        val ks = mk[t]; java.util.Arrays.sort(ks)
                        val f = IntArray(ks.size); val w = FloatArray(ks.size)
                        for (j in ks.indices) { val i = (ks[j] and 0xffffffffL).toInt(); f[j] = mf[i]; w[j] = mwt[i]; if (mf[i] > mx) mx = mf[i] }
                        mo[mnames[t]] = MTrack(f, w)
                    }
                }
            }
        } catch (e: Exception) { }
        return Clip(out, mx, mo)
    }

    fun vpd(d: ByteArray): Clip {
        val s = String(d, sj)
        val re = Regex("Bone\\d+\\{([^\\r\\n]+)\\s+([-\\d.eE]+),([-\\d.eE]+),([-\\d.eE]+);[^\\n]*\\s+([-\\d.eE]+),([-\\d.eE]+),([-\\d.eE]+),([-\\d.eE]+);")
        val m = HashMap<String, Track>()
        for (r in re.findAll(s)) {
            val v = r.groupValues.drop(2).map { it.toFloat() }
            m[r.groupValues[1].trim()] = Track(intArrayOf(0), floatArrayOf(-v[3], -v[4], v[5], v[6]), floatArrayOf(v[0], v[1], -v[2]), null)
        }
        if (m.isEmpty()) throw IllegalArgumentException("Bukan file VPD")
        return Clip(m, 0)
    }
}

// ---------------------------------------------------------------- rig
class Rig(val m: PmxModel) {
    val nb = m.bones.size
    val lq = FloatArray(nb * 4); val lt = FloatArray(nb * 3); val tq = FloatArray(nb * 4)
    /** override rotasi (dipakai IK lengan & jari dari gerak AI): hasil = nlerp(lq, oq, ow) */
    val oq = FloatArray(nb * 4); val ow = FloatArray(nb)
    private val iq = FloatArray(nb * 4); private val fq = FloatArray(nb * 4)
    val gq = FloatArray(nb * 4); val gt = FloatArray(nb * 3)
    private val driven = BooleanArray(nb)
    val par = IntArray(nb)
    private val rox = FloatArray(nb); private val roy = FloatArray(nb); private val roz = FloatArray(nb)
    val idx = HashMap<String, Int>(); val mIdx = HashMap<String, Int>()
    var order = IntArray(0); private set
    val skin = FloatArray(nb * 12)
    val mw = FloatArray(m.morphs.size)
    var top = 0f; var bottom = 0f
    private val tmp = FloatArray(4); private val s = FloatArray(4); private val s2 = FloatArray(4); private val eu = FloatArray(3)
    private val v1 = FloatArray(3); private val v2 = FloatArray(3)

    // ---- IK
    private class Ik(
        val bone: Int, val target: Int, val loop: Int, val limit: Float, val links: IntArray, val kind: IntArray,
        val mn: FloatArray, val mx: FloatArray, val paths: Array<IntArray>
    )
    private var iks = emptyArray<Ik>()
    private var useIk = false; private var ikDirty = false
    var ikMaxLoop = 24

    // ---- fisika spring
    var physScale = 1f
    private var nd = 0
    private var dBone = IntArray(0); private var dOf = IntArray(0)
    private var dL = FloatArray(0); private var dD0 = FloatArray(0)
    private var dCur = FloatArray(0); private var dPrv = FloatArray(0)
    private var dStiff = FloatArray(0); private var dGrav = FloatArray(0); private var dDragK = FloatArray(0)
    private var dR = FloatArray(0); private var dMax = FloatArray(0)
    private var dInit = BooleanArray(0)
    private var dCols = emptyArray<IntArray>()
    private var bOrder = IntArray(0)
    private var nc = 0
    private var cBone = IntArray(0); private var cR = FloatArray(0); private var cHL = FloatArray(0)
    private var cOff = FloatArray(0); private var cAx = FloatArray(0)
    private var cW = FloatArray(0); private var cA = FloatArray(0)
    private var lastDt = .033f

    // ---- morf
    private val vmorphs: IntArray; private val groups: IntArray
    private val mLo: IntArray; private val mHi: IntArray
    val mpos: FloatArray = m.pos.copyOf()
    var mDirty = false; var mUpLo = 0; var mUpHi = -1
    private val ew = FloatArray(m.morphs.size); private val lastEw = FloatArray(m.morphs.size)
    private var prevLo = Int.MAX_VALUE; private var prevHi = -1

    // ---- klip
    private var bc: Clip? = null
    private var bIdx = IntArray(0); private var bTr = emptyArray<Track>(); private var bCur = IntArray(0)
    private var bMi = IntArray(0); private var bMt = emptyArray<MTrack>()
    private val clipMorph = HashSet<Int>()

    init {
        for (i in 0 until nb) {
            val b = m.bones[i]
            lq[i * 4 + 3] = 1f; tq[i * 4 + 3] = 1f; iq[i * 4 + 3] = 1f; oq[i * 4 + 3] = 1f; fq[i * 4 + 3] = 1f; gq[i * 4 + 3] = 1f
            if (!idx.containsKey(b.name)) idx[b.name] = i
            par[i] = if (b.parent in 0 until nb && b.parent != i) b.parent else -1
            val p = par[i]
            rox[i] = b.x - (if (p >= 0) m.bones[p].x else 0f)
            roy[i] = b.y - (if (p >= 0) m.bones[p].y else 0f)
            roz[i] = b.z - (if (p >= 0) m.bones[p].z else 0f)
        }
        m.morphs.forEachIndexed { i, mo -> if (!mIdx.containsKey(mo.name)) mIdx[mo.name] = i }
        buildOrder()
        top = -1e9f; bottom = 1e9f
        for (i in 0 until m.nv) { top = max(top, m.pos[i * 3 + 1]); bottom = min(bottom, m.pos[i * 3 + 1]) }
        val vm = ArrayList<Int>(); val gm = ArrayList<Int>()
        mLo = IntArray(m.morphs.size); mHi = IntArray(m.morphs.size)
        m.morphs.forEachIndexed { i, mo ->
            if (mo.type == 1) {
                vm.add(i); var lo = Int.MAX_VALUE; var hi = -1
                for (v in mo.vi) if (v in 0 until m.nv) { if (v < lo) lo = v; if (v > hi) hi = v }
                mLo[i] = lo; mHi[i] = hi
            } else if (mo.type == 0) gm.add(i)
        }
        vmorphs = vm.toIntArray(); groups = gm.toIntArray()
        buildIk()
        buildPhys()
    }

    private fun buildOrder() {
        val adj = Array(nb) { ArrayList<Int>(2) }; val indeg = IntArray(nb)
        for (i in 0 until nb) {
            val p = par[i]; if (p >= 0) { adj[p].add(i); indeg[i]++ }
            val a = m.bones[i].appP; if (a in 0 until nb && a != i && a != p) { adj[a].add(i); indeg[i]++ }
        }
        val pq = java.util.PriorityQueue<Long>()
        for (i in 0 until nb) if (indeg[i] == 0) pq.add((m.bones[i].layer.toLong() shl 32) or i.toLong())
        val out = IntArray(nb); var n = 0; val done = BooleanArray(nb)
        while (pq.isNotEmpty()) {
            val i = (pq.poll() and 0xffffffffL).toInt(); out[n++] = i; done[i] = true
            for (c in adj[i]) if (--indeg[c] == 0) pq.add((m.bones[c].layer.toLong() shl 32) or c.toLong())
        }
        for (i in 0 until nb) if (!done[i]) out[n++] = i   // siklus: sisanya menurut indeks
        order = out
    }

    private fun buildIk() {
        val list = ArrayList<Ik>()
        for (b in 0 until nb) {
            val ik = m.bones[b].ik ?: continue
            if (ik.target !in 0 until nb || ik.links.isEmpty()) continue
            val links = ik.links.filter { it.bone in 0 until nb }
            if (links.isEmpty()) continue
            val kind = IntArray(links.size); val mn = FloatArray(links.size * 3); val mx = FloatArray(links.size * 3)
            val paths = Array(links.size) { j ->
                val l = links[j].bone
                val lst = ArrayList<Int>(); var p = ik.target; var g = 0
                while (p >= 0 && p != l && g++ < 256) { lst.add(p); p = par[p] }
                if (p == l) { lst.add(l); lst.reverse(); lst.toIntArray() } else intArrayOf(l)
            }
            for (j in links.indices) {
                val lk = links[j]
                for (a in 0..2) { mn[j * 3 + a] = lk.mn[a]; mx[j * 3 + a] = lk.mx[a] }
                kind[j] = if (!lk.lim) 0 else if (abs(lk.mn[1]) < 1e-6f && abs(lk.mx[1]) < 1e-6f && abs(lk.mn[2]) < 1e-6f && abs(lk.mx[2]) < 1e-6f) 1 else 2
            }
            list.add(Ik(b, ik.target, ik.loop.coerceIn(1, 64), ik.limit, IntArray(links.size) { links[it].bone }, kind, mn, mx, paths))
        }
        list.sortBy { (m.bones[it.bone].layer.toLong() shl 32) or it.bone.toLong() }
        iks = list.toTypedArray()
    }

    // ---------------------------------------------------------------- fisika: pembangunan
    private fun buildPhys() {
        if (m.rbs.isEmpty() || nb == 0) return
        val weighted = BooleanArray(nb)
        for (i in 0 until m.nv) for (k in 0..3) { val b = m.bi[i * 4 + k]; if (b in 0 until nb && m.bw[i * 4 + k] > 0f) weighted[b] = true }
        val rel = BooleanArray(nb)
        for (i in 0 until nb) if (weighted[i]) { var p = i; var g = 0; while (p >= 0 && !rel[p] && g++ < 2048) { rel[p] = true; p = par[p] } }
        val rbOf = arrayOfNulls<MRb>(nb)
        for (r in m.rbs) if (r.bone in 0 until nb && r.mode != 0 && rbOf[r.bone] == null) rbOf[r.bone] = r
        val isDyn = BooleanArray(nb)
        for (i in 0 until nb) {
            val r = rbOf[i] ?: continue
            if (m.bones[i].name.contains("錘")) continue
            if ((r.mode == 2 || (r.mode == 1 && weighted[i])) && rel[i]) isDyn[i] = true
        }
        val child = IntArray(nb) { -1 }
        for (i in nb - 1 downTo 0) { val p = par[i]; if (p >= 0) { if (child[p] < 0 || isDyn[i] || !isDyn[child[p]]) child[p] = i } }
        for (i in 0 until nb) { val p = par[i]; if (p >= 0 && isDyn[i]) child[p] = child[p] } // (no-op, mantap)
        // pilih anak: dahulukan anak dinamis, lalu indeks terkecil
        for (i in 0 until nb) child[i] = -1
        for (i in 0 until nb) { val p = par[i]; if (p < 0) continue; val c = child[p]; if (c < 0 || (isDyn[i] && !isDyn[c])) child[p] = i }
        val dl = ArrayList<Int>()
        for (i in order) if (isDyn[i]) dl.add(i)
        nd = dl.size
        if (nd == 0) return
        dBone = dl.toIntArray(); dOf = IntArray(nb) { -1 }; dBone.forEachIndexed { d, b -> dOf[b] = d }
        dL = FloatArray(nd); dD0 = FloatArray(nd * 3); dCur = FloatArray(nd * 3); dPrv = FloatArray(nd * 3)
        dStiff = FloatArray(nd); dGrav = FloatArray(nd); dDragK = FloatArray(nd); dR = FloatArray(nd); dMax = FloatArray(nd)
        dInit = BooleanArray(nd)
        val tailRest = FloatArray(nd * 3)
        for (d in 0 until nd) {
            val i = dBone[d]; val b = m.bones[i]
            var tx: Float; var ty: Float; var tz: Float
            val c = child[i]
            if (c >= 0) { tx = m.bones[c].x; ty = m.bones[c].y; tz = m.bones[c].z }
            else {
                val r = rbOf[i]
                if (r != null && (abs(r.pos[0] - b.x) + abs(r.pos[1] - b.y) + abs(r.pos[2] - b.z)) > .05f) {
                    tx = b.x + 2 * (r.pos[0] - b.x); ty = b.y + 2 * (r.pos[1] - b.y); tz = b.z + 2 * (r.pos[2] - b.z)
                } else {
                    val p = par[i]
                    val dx = if (p >= 0) b.x - m.bones[p].x else 0f; val dy = if (p >= 0) b.y - m.bones[p].y else -1f; val dz = if (p >= 0) b.z - m.bones[p].z else 0f
                    val l = max(sqrt(dx * dx + dy * dy + dz * dz), 1e-4f)
                    tx = b.x + dx / l * 1.5f; ty = b.y + dy / l * 1.5f; tz = b.z + dz / l * 1.5f
                }
            }
            var dx = tx - b.x; var dy = ty - b.y; var dz = tz - b.z
            var l = sqrt(dx * dx + dy * dy + dz * dz)
            if (l < .05f) { dx = 0f; dy = -1f; dz = 0f; l = .8f } else { dx /= l; dy /= l; dz /= l }
            if (l < .3f) l = .3f
            dL[d] = l; dD0[d * 3] = dx; dD0[d * 3 + 1] = dy; dD0[d * 3 + 2] = dz
            tailRest[d * 3] = b.x + dx * l; tailRest[d * 3 + 1] = b.y + dy * l; tailRest[d * 3 + 2] = b.z + dz * l
            val nm = b.name.lowercase()
            val cloth = nm.contains("skirt") || nm.contains("スカート") || nm.contains("裙") || nm.contains("sweater") || nm.contains("cloth") || nm.contains("coat") || nm.contains("cape") || nm.contains("マント")
            val breast = nm.contains("胸") || nm.contains("bust") || nm.contains("breast")
            val st: Float; val gr: Float; val dg: Float; val rr: Float; val mxA: Float
            if (cloth) { st = .50f; gr = .25f; dg = .40f; rr = .40f; mxA = 1.05f }
            else if (breast) { st = .70f; gr = .10f; dg = .50f; rr = .15f; mxA = .6f }
            else { st = .55f; gr = .14f; dg = .35f; rr = .25f; mxA = 1.2f }
            dStiff[d] = st; dGrav[d] = gr; dDragK[d] = ln(1f - dg) * 60f; dR[d] = rr; dMax[d] = cos(mxA)
        }
        // kolider: rigid body statis bentuk bola/kapsul
        val cl = m.rbs.filter { it.mode == 0 && it.bone in 0 until nb && (it.shape == 0 || it.shape == 2) }
        nc = cl.size
        cBone = IntArray(nc); cR = FloatArray(nc); cHL = FloatArray(nc); cOff = FloatArray(nc * 3); cAx = FloatArray(nc * 3)
        cW = FloatArray(nc * 3); cA = FloatArray(nc * 3)
        cl.forEachIndexed { c, r ->
            val b = m.bones[r.bone]
            cBone[c] = r.bone; cR[c] = r.size[0]; cHL[c] = if (r.shape == 2) r.size[1] / 2f else 0f
            cOff[c * 3] = r.pos[0] - b.x; cOff[c * 3 + 1] = r.pos[1] - b.y; cOff[c * 3 + 2] = r.pos[2] - b.z
            val sx = sin(r.rot[0]); val cx = cos(r.rot[0]); val sy = sin(r.rot[1]); val cy = cos(r.rot[1]); val sz = sin(r.rot[2]); val cz = cos(r.rot[2])
            var ax = sx * sy * cz - cx * sz; var ay = sx * sy * sz + cx * cz; var az = -(sx * cy)
            val l = max(sqrt(ax * ax + ay * ay + az * az), 1e-6f); ax /= l; ay /= l; az /= l
            cAx[c * 3] = ax; cAx[c * 3 + 1] = ay; cAx[c * 3 + 2] = az
        }
        dCols = Array(nd) { d ->
            val cand = ArrayList<Pair<Float, Int>>()
            val tx = tailRest[d * 3]; val ty = tailRest[d * 3 + 1]; val tz = tailRest[d * 3 + 2]
            for (c in 0 until nc) {
                val b = m.bones[cBone[c]]
                val cx = b.x + cOff[c * 3]; val cy = b.y + cOff[c * 3 + 1]; val cz = b.z + cOff[c * 3 + 2]
                var qx = cx; var qy = cy; var qz = cz
                if (cHL[c] > 0f) {
                    val t = ((tx - cx) * cAx[c * 3] + (ty - cy) * cAx[c * 3 + 1] + (tz - cz) * cAx[c * 3 + 2]).coerceIn(-cHL[c], cHL[c])
                    qx = cx + cAx[c * 3] * t; qy = cy + cAx[c * 3 + 1] * t; qz = cz + cAx[c * 3 + 2] * t
                }
                val dist = sqrt((tx - qx) * (tx - qx) + (ty - qy) * (ty - qy) + (tz - qz) * (tz - qz)) - cR[c]
                // hanya kolider yang di keadaan diam berada di luar & dekat ujung helai
                if (dist >= .02f && dist < dL[d] * 2.5f + 1f) cand.add(dist to c)
            }
            cand.sortBy { it.first }
            IntArray(min(cand.size, 6)) { cand[it].second }
        }
        val aff = BooleanArray(nb); val bl = ArrayList<Int>()
        for (i in order) {
            val p = par[i]; val a = m.bones[i].appP
            aff[i] = dOf[i] >= 0 || (p >= 0 && aff[p]) || (a in 0 until nb && aff[a])
            if (aff[i]) bl.add(i)
        }
        bOrder = bl.toIntArray()
    }

    val hasPhysics: Boolean get() = nd > 0
    fun physReset() { java.util.Arrays.fill(dInit, false) }

    // ---------------------------------------------------------------- gerak procedural (tubuh idle)
    fun bonePos(n: String): FloatArray? { val i = idx[n] ?: return null; val b = m.bones[i]; return floatArrayOf(b.x, b.y, b.z) }
    fun drive(n: String, x: Float, y: Float, z: Float) {
        val i = idx[n] ?: return
        qeuler(x, y, z, tq, i * 4); driven[i] = true
    }
    fun smooth(dt: Float) {
        val k = 1f - exp(-dt * 18f)
        for (i in 0 until nb) if (driven[i]) {
            val o = i * 4
            val sg = if (lq[o] * tq[o] + lq[o + 1] * tq[o + 1] + lq[o + 2] * tq[o + 2] + lq[o + 3] * tq[o + 3] < 0) -1f else 1f
            for (j in 0..3) lq[o + j] += (tq[o + j] * sg - lq[o + j]) * k
            qnorm(lq, o)
        }
    }
    fun setOverride(i: Int, x: Float, y: Float, z: Float) { qeuler(x, y, z, oq, i * 4); ow[i] = 1f }
    fun clearOverrides() { java.util.Arrays.fill(ow, 0f) }
    fun resetPose() {
        java.util.Arrays.fill(lt, 0f)
        for (i in 0 until nb) for (j in 0..3) { lq[i * 4 + j] = if (j == 3) 1f else 0f; iq[i * 4 + j] = if (j == 3) 1f else 0f }
        physReset()
        for (k in clipMorph) if (k in mw.indices) mw[k] = 0f
        clipMorph.clear()
    }

    // ---------------------------------------------------------------- klip VMD (Bezier)
    private fun bind(c: Clip) {
        bc = c
        val ids = ArrayList<Int>(); val trs = ArrayList<Track>()
        for ((n, tr) in c.tr) { val i = idx[n] ?: continue; if (tr.f.isEmpty()) continue; ids.add(i); trs.add(tr) }
        bIdx = ids.toIntArray(); bTr = trs.toTypedArray(); bCur = IntArray(bIdx.size)
        val mi = ArrayList<Int>(); val mt = ArrayList<MTrack>()
        for ((n, t) in c.mo) { val i = mIdx[n] ?: continue; if (t.f.isEmpty()) continue; mi.add(i); mt.add(t) }
        bMi = mi.toIntArray(); bMt = mt.toTypedArray()
        clipMorph.clear(); for (i in bMi) clipMorph.add(i)
    }
    fun clipHasMorph(i: Int) = clipMorph.contains(i)
    private fun bz(u: Float, x1: Int, y1: Int, x2: Int, y2: Int): Float {
        if (x1 == y1 && x2 == y2) return u
        val ax = x1 / 127f; val ay = y1 / 127f; val bx = x2 / 127f; val by = y2 / 127f
        var t = u
        for (k in 0 until 6) {
            val it = 1f - t
            val x = 3 * it * it * t * ax + 3 * it * t * t * bx + t * t * t
            val dx = 3 * it * it * ax + 6 * it * t * (bx - ax) + 3 * t * t * (1f - bx)
            if (abs(dx) < 1e-5f) break
            t -= (x - u) / dx
            if (t < 0f) t = 0f else if (t > 1f) t = 1f
        }
        val it = 1f - t
        return 3 * it * it * t * ay + 3 * it * t * t * by + t * t * t
    }
    fun applyClip(c: Clip, f: Float) {
        if (c !== bc) bind(c)
        for (j in bIdx.indices) {
            val i = bIdx[j]; val tr = bTr[j]; val fr = tr.f
            var a = bCur[j]; if (a >= fr.size) a = fr.size - 1
            if (fr[a] > f) a = 0
            while (a < fr.size - 1 && fr[a + 1] <= f) a++
            bCur[j] = a
            val b = min(a + 1, fr.size - 1)
            var u = if (b == a || f <= fr[a]) 0f else min(1f, (f - fr[a]) / (fr[b] - fr[a]).toFloat())
            val bez = tr.bez
            var ur = u; var ux = u; var uy = u; var uz = u
            if (bez != null && b != a) {
                val o = b * 16
                ux = bz(u, bez[o].toInt(), bez[o + 4].toInt(), bez[o + 8].toInt(), bez[o + 12].toInt())
                uy = bz(u, bez[o + 1].toInt(), bez[o + 5].toInt(), bez[o + 9].toInt(), bez[o + 13].toInt())
                uz = bz(u, bez[o + 2].toInt(), bez[o + 6].toInt(), bez[o + 10].toInt(), bez[o + 14].toInt())
                ur = bz(u, bez[o + 3].toInt(), bez[o + 7].toInt(), bez[o + 11].toInt(), bez[o + 15].toInt())
            }
            val q = tr.q; val p = tr.p
            val sg = if (q[a * 4] * q[b * 4] + q[a * 4 + 1] * q[b * 4 + 1] + q[a * 4 + 2] * q[b * 4 + 2] + q[a * 4 + 3] * q[b * 4 + 3] < 0) -1f else 1f
            for (k in 0..3) lq[i * 4 + k] = q[a * 4 + k] + (q[b * 4 + k] * sg - q[a * 4 + k]) * ur
            qnorm(lq, i * 4)
            lt[i * 3] = p[a * 3] + (p[b * 3] - p[a * 3]) * ux
            lt[i * 3 + 1] = p[a * 3 + 1] + (p[b * 3 + 1] - p[a * 3 + 1]) * uy
            lt[i * 3 + 2] = p[a * 3 + 2] + (p[b * 3 + 2] - p[a * 3 + 2]) * uz
        }
        for (j in bMi.indices) {
            val t = bMt[j]; val fr = t.f
            var a = 0; while (a < fr.size - 1 && fr[a + 1] <= f) a++
            val b = min(a + 1, fr.size - 1)
            val u = if (b == a || f <= fr[a]) 0f else min(1f, (f - fr[a]) / (fr[b] - fr[a]).toFloat())
            mw[bMi[j]] = t.w[a] + (t.w[b] - t.w[a]) * u
        }
    }

    // ---------------------------------------------------------------- FK + append + IK + fisika
    private fun computeFq(i: Int) {
        val o = i * 4
        var ax = lq[o]; var ay = lq[o + 1]; var az = lq[o + 2]; var aw = lq[o + 3]
        val w = ow[i]
        if (w > 0f) {
            val bx = oq[o]; val by = oq[o + 1]; val bz = oq[o + 2]; val bw = oq[o + 3]
            val sg = if (ax * bx + ay * by + az * bz + aw * bw < 0f) -1f else 1f
            ax += (bx * sg - ax) * w; ay += (by * sg - ay) * w; az += (bz * sg - az) * w; aw += (bw * sg - aw) * w
        }
        s[0] = ax; s[1] = ay; s[2] = az; s[3] = aw; qnorm(s, 0)
        if (useIk) qmul(iq, o, s, 0, s, 0)
        val b = m.bones[i]
        val axis = b.axis
        if (axis != null) {
            val dv = s[0] * axis[0] + s[1] * axis[1] + s[2] * axis[2]
            val ang = 2f * atan2(dv, s[3]); val sn = sin(ang / 2f)
            s[0] = axis[0] * sn; s[1] = axis[1] * sn; s[2] = axis[2] * sn; s[3] = cos(ang / 2f)
        }
        val ap = b.appP
        if (ap in 0 until nb && b.appR != 0f) {
            qpow(fq, ap * 4, b.appR, s2, 0)
            qmul(s, 0, s2, 0, s, 0)
        }
        fq[o] = s[0]; fq[o + 1] = s[1]; fq[o + 2] = s[2]; fq[o + 3] = s[3]
    }
    private fun computeG(i: Int) {
        val p = par[i]; val o = i * 4
        if (p < 0) {
            gq[o] = fq[o]; gq[o + 1] = fq[o + 1]; gq[o + 2] = fq[o + 2]; gq[o + 3] = fq[o + 3]
            gt[i * 3] = rox[i] + lt[i * 3]; gt[i * 3 + 1] = roy[i] + lt[i * 3 + 1]; gt[i * 3 + 2] = roz[i] + lt[i * 3 + 2]
        } else {
            qrot(gq, p * 4, rox[i] + lt[i * 3], roy[i] + lt[i * 3 + 1], roz[i] + lt[i * 3 + 2], v1)
            gt[i * 3] = gt[p * 3] + v1[0]; gt[i * 3 + 1] = gt[p * 3 + 1] + v1[1]; gt[i * 3 + 2] = gt[p * 3 + 2] + v1[2]
            qmul(gq, p * 4, fq, o, gq, o)
        }
    }
    fun recompute(i: Int) { computeFq(i); computeG(i) }
    fun fkPass() { for (i in order) { computeFq(i); computeG(i) } }

    private fun solveIk(k: Ik) {
        val tb = k.target; val gb = k.bone
        val loops = min(k.loop, ikMaxLoop)
        for (itn in 0 until loops) {
            var changed = false
            for (j in k.links.indices) {
                val L = k.links[j]
                val dx = gt[tb * 3] - gt[gb * 3]; val dy = gt[tb * 3 + 1] - gt[gb * 3 + 1]; val dz = gt[tb * 3 + 2] - gt[gb * 3 + 2]
                if (dx * dx + dy * dy + dz * dz < 1e-5f) return
                qrotInv(gq, L * 4, gt[tb * 3] - gt[L * 3], gt[tb * 3 + 1] - gt[L * 3 + 1], gt[tb * 3 + 2] - gt[L * 3 + 2], v1)
                qrotInv(gq, L * 4, gt[gb * 3] - gt[L * 3], gt[gb * 3 + 1] - gt[L * 3 + 1], gt[gb * 3 + 2] - gt[L * 3 + 2], v2)
                val l1 = sqrt(v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2]); val l2 = sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2])
                if (l1 < 1e-6f || l2 < 1e-6f) continue
                val ex = v1[0] / l1; val ey = v1[1] / l1; val ez = v1[2] / l1
                val gx = v2[0] / l2; val gy = v2[1] / l2; val gz = v2[2] / l2
                var ang = acos((ex * gx + ey * gy + ez * gz).coerceIn(-1f, 1f))
                if (ang < 1e-5f) continue
                if (k.limit > 0f && ang > k.limit) ang = k.limit
                var ax = ey * gz - ez * gy; var ay = ez * gx - ex * gz; var az = ex * gy - ey * gx
                val al = sqrt(ax * ax + ay * ay + az * az)
                if (al < 1e-8f) continue
                ax /= al; ay /= al; az /= al
                val o = L * 4
                qmul(iq, o, lq, o, s, 0)   // total = ik * anim
                when (k.kind[j]) {
                    1 -> {
                        var th = 2f * atan2(s[0], s[3])
                        if (th > PI.toFloat()) th -= 2f * PI.toFloat() else if (th < -PI.toFloat()) th += 2f * PI.toFloat()
                        th += if (abs(ax) < 1e-4f || ax > 0f) ang else -ang
                        th = th.coerceIn(k.mn[j * 3], k.mx[j * 3])
                        s[0] = sin(th / 2f); s[1] = 0f; s[2] = 0f; s[3] = cos(th / 2f)
                    }
                    else -> {
                        val sn = sin(ang / 2f); tmp[0] = ax * sn; tmp[1] = ay * sn; tmp[2] = az * sn; tmp[3] = cos(ang / 2f)
                        qmul(s, 0, tmp, 0, s, 0); qnorm(s, 0)
                        if (k.kind[j] == 2) {
                            toEuler(s, 0, eu)
                            eu[0] = eu[0].coerceIn(k.mn[j * 3], k.mx[j * 3]); eu[1] = eu[1].coerceIn(k.mn[j * 3 + 1], k.mx[j * 3 + 1]); eu[2] = eu[2].coerceIn(k.mn[j * 3 + 2], k.mx[j * 3 + 2])
                            qeuler(eu[0], eu[1], eu[2], s, 0)
                        }
                    }
                }
                tmp[0] = -lq[o]; tmp[1] = -lq[o + 1]; tmp[2] = -lq[o + 2]; tmp[3] = lq[o + 3]
                qmul(s, 0, tmp, 0, iq, o); qnorm(iq, o)
                for (p in k.paths[j]) { computeFq(p); computeG(p) }
                changed = true
            }
            if (!changed) break
        }
    }

    private fun prepCol() {
        for (c in 0 until nc) {
            val b = cBone[c]
            qrot(gq, b * 4, cOff[c * 3], cOff[c * 3 + 1], cOff[c * 3 + 2], v1)
            cW[c * 3] = gt[b * 3] + v1[0]; cW[c * 3 + 1] = gt[b * 3 + 1] + v1[1]; cW[c * 3 + 2] = gt[b * 3 + 2] + v1[2]
            qrot(gq, b * 4, cAx[c * 3], cAx[c * 3 + 1], cAx[c * 3 + 2], v1)
            cA[c * 3] = v1[0]; cA[c * 3 + 1] = v1[1]; cA[c * 3 + 2] = v1[2]
        }
    }

    private fun physStep(i: Int, d: Int, dt: Float) {
        val p = par[i]
        val px = gt[i * 3]; val py = gt[i * 3 + 1]; val pz = gt[i * 3 + 2]
        qrot(gq, i * 4, dD0[d * 3], dD0[d * 3 + 1], dD0[d * 3 + 2], v1)
        val rdx = v1[0]; val rdy = v1[1]; val rdz = v1[2]
        val L = dL[d]; val o = d * 3
        if (!dInit[d]) {
            dCur[o] = px + rdx * L; dCur[o + 1] = py + rdy * L; dCur[o + 2] = pz + rdz * L
            dPrv[o] = dCur[o]; dPrv[o + 1] = dCur[o + 1]; dPrv[o + 2] = dCur[o + 2]; dInit[d] = true
        }
        var cx = dCur[o]; var cy = dCur[o + 1]; var cz = dCur[o + 2]
        val ex = cx - px; val ey = cy - py; val ez = cz - pz
        if (ex * ex + ey * ey + ez * ez > L * L * 9f || ex != ex) {   // terlempar jauh / NaN: mulai ulang
            cx = px + rdx * L; cy = py + rdy * L; cz = pz + rdz * L
            dPrv[o] = cx; dPrv[o + 1] = cy; dPrv[o + 2] = cz
        }
        val dtc = min(dt, .05f); val ds = physScale
        val vf = exp(dDragK[d] * dtc) * min(ds, 1.4f)
        val ks = dStiff[d] * L * dtc * 10f
        val kg = dGrav[d] * L * dtc * 10f * ds
        var nx = cx + (cx - dPrv[o]) * vf + rdx * ks
        var ny = cy + (cy - dPrv[o + 1]) * vf + rdy * ks - kg
        var nz = cz + (cz - dPrv[o + 2]) * vf + rdz * ks
        // tumbukan dengan bola/kapsul tubuh
        val cols = dCols[d]
        for (c in cols) {
            var qx = cW[c * 3]; var qy = cW[c * 3 + 1]; var qz = cW[c * 3 + 2]
            val hl = cHL[c]
            if (hl > 0f) {
                val t = ((nx - qx) * cA[c * 3] + (ny - qy) * cA[c * 3 + 1] + (nz - qz) * cA[c * 3 + 2]).coerceIn(-hl, hl)
                qx += cA[c * 3] * t; qy += cA[c * 3 + 1] * t; qz += cA[c * 3 + 2] * t
            }
            val r = cR[c] + dR[d]
            var vx = nx - qx; var vy = ny - qy; var vz = nz - qz
            val dd = vx * vx + vy * vy + vz * vz
            if (dd < r * r) {
                val dl = sqrt(dd)
                if (dl < 1e-5f) { vx = 0f; vy = 1f; vz = 0f } else { vx /= dl; vy /= dl; vz /= dl }
                nx = qx + vx * r; ny = qy + vy * r; nz = qz + vz * r
            }
        }
        // batas panjang
        var dx = nx - px; var dy = ny - py; var dz = nz - pz
        var l = sqrt(dx * dx + dy * dy + dz * dz)
        if (l < 1e-6f) { dx = rdx; dy = rdy; dz = rdz; l = 1f }
        dx /= l; dy /= l; dz /= l
        // batas sudut maksimum terhadap arah diam
        val cs = dx * rdx + dy * rdy + dz * rdz
        val cm = dMax[d]
        if (cs < cm) {
            var qx = dx - rdx * cs; var qy = dy - rdy * cs; var qz = dz - rdz * cs
            val ql = sqrt(qx * qx + qy * qy + qz * qz)
            if (ql > 1e-6f) {
                qx /= ql; qy /= ql; qz /= ql
                val sm = sqrt(max(0f, 1f - cm * cm))
                dx = rdx * cm + qx * sm; dy = rdy * cm + qy * sm; dz = rdz * cm + qz * sm
            } else { dx = rdx; dy = rdy; dz = rdz }
        }
        nx = px + dx * L; ny = py + dy * L; nz = pz + dz * L
        dPrv[o] = cx; dPrv[o + 1] = cy; dPrv[o + 2] = cz
        dCur[o] = nx; dCur[o + 1] = ny; dCur[o + 2] = nz
        // putar tulang dari arah animasi ke arah simulasi
        qfromTo(rdx, rdy, rdz, dx, dy, dz, s, 0)
        qmul(s, 0, gq, i * 4, gq, i * 4); qnorm(gq, i * 4)
        val g = i * 4
        if (p < 0) { fq[g] = gq[g]; fq[g + 1] = gq[g + 1]; fq[g + 2] = gq[g + 2]; fq[g + 3] = gq[g + 3] }
        else {
            tmp[0] = -gq[p * 4]; tmp[1] = -gq[p * 4 + 1]; tmp[2] = -gq[p * 4 + 2]; tmp[3] = gq[p * 4 + 3]
            qmul(tmp, 0, gq, g, fq, g)
        }
    }

    /** ik: selesaikan IK (kaki dsb.) — hanya untuk klip VMD. phys: hidupkan fisika. */
    fun update(dt: Float, ik: Boolean, phys: Boolean) {
        useIk = ik && iks.isNotEmpty()
        if (useIk) {
            for (k in iks) for (L in k.links) { val o = L * 4; iq[o] = 0f; iq[o + 1] = 0f; iq[o + 2] = 0f; iq[o + 3] = 1f }
            ikDirty = true
        } else if (ikDirty) {
            for (i in 0 until nb) { iq[i * 4] = 0f; iq[i * 4 + 1] = 0f; iq[i * 4 + 2] = 0f; iq[i * 4 + 3] = 1f }
            ikDirty = false
        }
        fkPass()
        if (useIk) for (k in iks) { solveIk(k); fkPass() }
        if (phys && nd > 0) {
            prepCol()
            val d = if (lastDt > 0f) dt else .033f
            for (i in bOrder) { computeFq(i); computeG(i); val q = dOf[i]; if (q >= 0) physStep(i, q, d) }
        } else if (nd > 0) physReset()
        lastDt = dt
        applyMorphs()
        buildSkin()
    }

    private fun applyMorphs() {
        val nm = mw.size
        if (nm == 0) return
        System.arraycopy(mw, 0, ew, 0, nm)
        for (g in groups) {
            val w = mw[g]; if (w <= .002f) continue
            val mo = m.morphs[g]
            for (e in mo.gi.indices) { val c = mo.gi[e]; if (c in 0 until nm && c != g) ew[c] += w * mo.gr[e] }
        }
        var changed = false
        for (k in vmorphs) if (abs(ew[k] - lastEw[k]) > .0015f) { changed = true; break }
        if (!changed) return
        var lo = Int.MAX_VALUE; var hi = -1
        for (k in vmorphs) if (ew[k] > .002f && mHi[k] >= 0) { if (mLo[k] < lo) lo = mLo[k]; if (mHi[k] > hi) hi = mHi[k] }
        val ulo = min(lo, prevLo); val uhi = max(hi, prevHi)
        for (k in vmorphs) lastEw[k] = ew[k]
        if (uhi < 0) return
        System.arraycopy(m.pos, ulo * 3, mpos, ulo * 3, (uhi - ulo + 1) * 3)
        for (k in vmorphs) {
            val w = ew[k]; if (w <= .002f) continue
            val mo = m.morphs[k]
            for (j in mo.vi.indices) { val v = mo.vi[j]; if (v in 0 until m.nv) { mpos[v * 3] += w * mo.off[j * 3]; mpos[v * 3 + 1] += w * mo.off[j * 3 + 1]; mpos[v * 3 + 2] += w * mo.off[j * 3 + 2] } }
        }
        prevLo = lo; prevHi = hi
        if (mDirty) { mUpLo = min(mUpLo, ulo); mUpHi = max(mUpHi, uhi) } else { mUpLo = ulo; mUpHi = uhi }
        mDirty = true
    }

    private fun buildSkin() {
        for (i in 0 until nb) {
            val o = i * 4; val x = gq[o]; val y = gq[o + 1]; val z = gq[o + 2]; val w = gq[o + 3]
            val xx = x * x; val yy = y * y; val zz = z * z
            val r00 = 1 - 2 * (yy + zz); val r01 = 2 * (x * y - z * w); val r02 = 2 * (x * z + y * w)
            val r10 = 2 * (x * y + z * w); val r11 = 1 - 2 * (xx + zz); val r12 = 2 * (y * z - x * w)
            val r20 = 2 * (x * z - y * w); val r21 = 2 * (y * z + x * w); val r22 = 1 - 2 * (xx + yy)
            val b = m.bones[i]
            val k = i * 12
            skin[k] = r00; skin[k + 1] = r01; skin[k + 2] = r02; skin[k + 3] = gt[i * 3] - (r00 * b.x + r01 * b.y + r02 * b.z)
            skin[k + 4] = r10; skin[k + 5] = r11; skin[k + 6] = r12; skin[k + 7] = gt[i * 3 + 1] - (r10 * b.x + r11 * b.y + r12 * b.z)
            skin[k + 8] = r20; skin[k + 9] = r21; skin[k + 10] = r22; skin[k + 11] = gt[i * 3 + 2] - (r20 * b.x + r21 * b.y + r22 * b.z)
        }
    }
}
