package com.mita.live

import android.graphics.Bitmap
import android.opengl.GLES30 as G
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.random.Random

/** Nama morf per slot ekspresi: daftar kandidat (Jepang dulu, lalu Inggris) agar cocok dengan banyak model. */
class FaceMap(private val r: Rig) {
    private fun f(vararg n: String): Int { for (x in n) r.mIdx[x]?.let { return it }; return -1 }
    val blink = f("まばたき", "Blink"); val bl = f("ウィンク", "LeftEyeBlink", "Wink"); val br = f("ウィンク右", "RightEyeBlink", "WinkR")
    val a = f("あ", "A"); val o = f("お", "O"); val sm = f("にこり", "SmileSmall"); val up = f("上", "EyeBrowsUp"); val dn = f("下", "EyeBrowsDown")
    val puff = f("PuffCheeks"); val wide = f("びっくり", "EyesWonder"); val sq = f("じと目", "EyesSquints"); val tongue = f("TongueSmile", "てへぺろ")
    val e = intArrayOf(f("喜び", "Smile"), f("笑い", "SmileBig"), f("びっくり", "EyesWonder"), f("困る", "AkwardSmile"), f("怒り", "AnnoySmall"))
}

class Gl : GLSurfaceView.Renderer {
    @Volatile var yaw = 0f; @Volatile var pitch = .05f; @Volatile var zoom = 1f; @Volatile var pan = 0f
    @Volatile var talking = false
    @Volatile var wantClip: Clip? = null
    @Volatile var wantReset = false
    @Volatile var speed = 1f
    @Volatile var outline = true
    @Volatile var anime = true
    @Volatile var physOn = true
    @Volatile var physScale = 1f
    @Volatile var edgeW = .0042f
    @Volatile var sleepy = false
    @Volatile var emoName = "tenang"
    @Volatile var pendingPlan: Map<*, *>? = null
    @Volatile var lastTouch = 0L
    @Volatile var status: String? = null
    @Volatile var clipPlaying = false
    @Volatile var planActive = false
    var rig: Rig? = null
    var hands: Hands? = null
    private var model: PmxModel? = null
    private var prog = 0; private var progE = 0; private var progB = 0
    private var vao = 0; private var vboP = 0; private var vboS = 0; private var ibo = 0; private var tboneTex = 0
    private var texs = IntArray(0)
    private var posBuf: FloatBuffer? = null; private var skinBuf: FloatBuffer? = null
    private var idxType = G.GL_UNSIGNED_SHORT
    private var w = 1; private var h = 1
    private var last = 0L; private var time = 0f
    private var clip: Clip? = null; private var clipT = 0f
    private var down = .9f; private var blinkAt = 2f; private var blinkP = -1f
    private var face: FaceMap? = null
    private var centerI = -1
    private val P = FloatArray(16); private val V = FloatArray(16); private val VP = FloatArray(16); private val V3 = FloatArray(9)
    private var pending: Triple<PmxModel, Rig, (Int) -> Bitmap?>? = null
    private var texProv: ((Int) -> Bitmap?)? = null
    private var cls = IntArray(0)
    private var sx = 0f; private var sy = 0f; private var sacc = 0f
    private var blush = 0f; private val ef = FloatArray(5)
    private var mouth = 0f; private var smile = .4f
    private var hasUpload = false
    // lokasi uniform
    private var uVP = 0; private var uV3 = 0; private var uCam = 0; private var uCol = 0; private var uHas = 0; private var uCls = 0
    private var uBlush = 0; private var uFaux = 0; private var uTex = 0; private var uBones = 0
    private var eVP = 0; private var eBones = 0; private var eEdge = 0; private var eAsp = 0; private var eCol = 0
    private var bAsp = 0

    fun setModel(m: PmxModel, r: Rig, tex: (Int) -> Bitmap?) { pending = Triple(m, r, tex) }
    fun busy(): Boolean = clipPlaying || planActive || talking || (System.currentTimeMillis() - lastTouch < 1500)

    private val VS = """
precision highp float; precision highp int; precision highp sampler2D;
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec2 aT;
layout(location=3) in uvec4 aBI; layout(location=4) in vec4 aBW;
uniform mat4 uVP; uniform sampler2D uBones;
#ifdef EDGE
uniform float uEdge; uniform float uAspect;
#endif
out vec3 vN; out vec2 vT; out vec3 vW;
void main(){
  vec4 p=vec4(aP,1.0); vec3 pos=vec3(0.0); vec3 nor=vec3(0.0); float ws=0.0;
  for(int k=0;k<4;k++){
    float w=aBW[k]; if(w<=0.0) continue; int b=int(aBI[k]);
    vec4 r0=texelFetch(uBones,ivec2(0,b),0); vec4 r1=texelFetch(uBones,ivec2(1,b),0); vec4 r2=texelFetch(uBones,ivec2(2,b),0);
    pos+=w*vec3(dot(r0,p),dot(r1,p),dot(r2,p)); nor+=w*vec3(dot(r0.xyz,aN),dot(r1.xyz,aN),dot(r2.xyz,aN)); ws+=w;
  }
  if(ws<=0.0){pos=aP;nor=aN;}
  vW=pos; vN=nor; vT=aT;
  vec4 pc=uVP*vec4(pos,1.0);
#ifdef EDGE
  vec3 nc=(uVP*vec4(normalize(nor),0.0)).xyz; vec2 d=nc.xy; float l=length(d);
  if(l>1e-4) d/=l; else d=vec2(0.0);
  pc.xy+=d*vec2(1.0/uAspect,1.0)*uEdge*pc.w;
#endif
  gl_Position=pc;
}"""
    // shader anime: port dari Mita Live v7 (kelas: 1 kulit, 2 rambut, 3 wajah, 4 datar, 0 umum)
    private val FS_ANIME = """
precision mediump float;
uniform sampler2D uTex; uniform vec4 uCol; uniform float uHas; uniform int uCls; uniform float uBlush; uniform float uFaux;
uniform vec3 uCam; uniform mat3 uV3;
in vec3 vN; in vec2 vT; in highp vec3 vW; out vec4 o;
void main(){
  vec4 t=mix(vec4(1.0),texture(uTex,vT),uHas); vec4 c=t*uCol; vec3 alb=c.rgb;
  if(c.a<0.03) discard;
  vec3 N=normalize(vN); if(!gl_FrontFacing) N=-N;
  vec3 L=normalize(vec3(-1.0,1.0,1.5)); vec3 V=normalize(uCam-vW);
  vec3 Nv=uV3*N;
  float h=dot(N,L)*0.5+0.5; float nv=clamp(dot(N,V),0.0,1.0); float lit=smoothstep(0.34,0.54,h);
  vec3 col=alb;
  if(uCls!=4){
    if(uCls==1){
      vec3 sh=alb*vec3(1.0,0.80,0.85)+vec3(0.05,0.0,0.015); float tm=smoothstep(0.2,0.42,h)*(1.0-smoothstep(0.42,0.66,h));
      col=mix(sh,alb*1.05,smoothstep(0.28,0.6,h))+alb*vec3(0.2,0.05,0.04)*tm; col=pow(max(col,vec3(0.0)),vec3(0.9));
      col+=vec3(0.12)*pow(max(dot(reflect(-L,N),V),0.0),22.0)+vec3(1.0,0.62,0.68)*pow(1.0-nv,2.6)*0.12*(0.4+h);
    } else if(uCls==3){
      col=mix(alb*vec3(1.0,0.87,0.89),alb*1.05,smoothstep(0.2,0.46,h)); col=pow(max(col,vec3(0.0)),vec3(0.92));
      col+=vec3(1.0,0.64,0.7)*pow(1.0-nv,2.8)*0.08;
      float ck=smoothstep(0.12,0.5,abs(Nv.x))*smoothstep(0.35,0.85,Nv.z)*smoothstep(-0.1,0.4,Nv.y+0.25);
      col+=vec3(0.16,-0.02,0.01)*uBlush*ck; col=mix(col,col*vec3(1.04,0.97,0.98),uBlush);
    } else if(uCls==2){
      vec3 sh=alb*vec3(0.66,0.68,0.92); col=mix(sh,alb*1.06,lit);
      float ring=(1.0-smoothstep(0.0,0.15,abs(Nv.y-0.42)-0.07))*smoothstep(0.0,0.5,Nv.z)*smoothstep(0.3,0.7,h);
      col+=(alb*0.55+vec3(0.3))*ring*0.55;
    } else {
      vec3 sh=alb*alb*vec3(0.95,0.92,1.05)*1.15; col=mix(sh,alb*1.05,lit);
      col+=vec3(0.1)*pow(max(dot(reflect(-L,N),V),0.0),30.0)*0.6;
    }
    col+=vec3(0.55,0.78,1.0)*pow(1.0-nv,3.0)*0.2*(0.4+0.6*h);
    if(uFaux>0.5) col*=mix(0.5,1.0,smoothstep(0.0,0.24,nv));
  }
  o=vec4(col,c.a);
}"""
    private val FS_PLAIN = """
precision mediump float;
uniform sampler2D uTex; uniform vec4 uCol; uniform float uHas; uniform int uCls; uniform float uBlush; uniform float uFaux;
uniform vec3 uCam; uniform mat3 uV3;
in vec3 vN; in vec2 vT; in highp vec3 vW; out vec4 o;
void main(){
  vec4 t=mix(vec4(1.0),texture(uTex,vT),uHas); vec4 c=t*uCol; if(c.a<0.03) discard;
  vec3 N=normalize(vN); if(!gl_FrontFacing) N=-N;
  float h=dot(N,normalize(vec3(-0.3,0.6,0.75)))*0.5+0.5; float l=smoothstep(0.34,0.54,h);
  o=vec4(c.rgb*mix(0.72,1.05,l)+0.0*uBlush*uFaux*uCam.x*uV3[0][0]*vW.x*uHas*float(uCls),c.a);
}"""
    private val FS_EDGE = """
precision mediump float;
uniform vec4 uEC; out vec4 o;
void main(){ o=uEC; }"""
    private val VS_BG = """
out vec2 vU;
void main(){ vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2)); vU=p; gl_Position=vec4(p*2.0-1.0,0.9999,1.0); }"""
    private val FS_BG = """
precision mediump float;
in vec2 vU; out vec4 o; uniform float uAspect;
void main(){
  vec2 d=(vU-vec2(0.5,0.7))*vec2(uAspect*0.8,1.25); float t=clamp(length(d)/0.95,0.0,1.0);
  vec3 c1=vec3(0.333,0.757,0.796); vec3 c2=vec3(0.184,0.498,0.757); vec3 c3=vec3(0.122,0.31,0.604);
  vec3 c=mix(c1,c2,smoothstep(0.0,0.62,t)); c=mix(c,c3,smoothstep(0.62,1.0,t));
  c+=(fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-0.5)/255.0;
  o=vec4(c,1.0);
}"""

    private fun sh(t: Int, s: String): Int {
        val i = G.glCreateShader(t); G.glShaderSource(i, s); G.glCompileShader(i)
        val ok = IntArray(1); G.glGetShaderiv(i, G.GL_COMPILE_STATUS, ok, 0)
        return if (ok[0] == 0) { G.glDeleteShader(i); 0 } else i
    }
    private fun link(vs: String, fs: String): Int {
        val a = sh(G.GL_VERTEX_SHADER, vs); val b = sh(G.GL_FRAGMENT_SHADER, fs)
        if (a == 0 || b == 0) return 0
        val p = G.glCreateProgram(); G.glAttachShader(p, a); G.glAttachShader(p, b); G.glLinkProgram(p)
        G.glDeleteShader(a); G.glDeleteShader(b)
        val ok = IntArray(1); G.glGetProgramiv(p, G.GL_LINK_STATUS, ok, 0)
        return if (ok[0] == 0) { G.glDeleteProgram(p); 0 } else p
    }

    override fun onSurfaceCreated(u: GL10?, c: EGLConfig?) {
        G.glClearColor(.18f, .5f, .75f, 1f)
        val hd = "#version 300 es\n"
        prog = link(hd + VS, hd + FS_ANIME)
        if (prog == 0) { status = "Shader anime tidak cocok di GPU ini, pakai tampilan standar."; prog = link(hd + VS, hd + FS_PLAIN) }
        progE = link(hd + "#define EDGE\n" + VS, hd + FS_EDGE)
        progB = link(hd + VS_BG, hd + FS_BG)
        if (prog == 0) { status = "Shader gagal dikompilasi di GPU ini."; return }
        uVP = G.glGetUniformLocation(prog, "uVP"); uV3 = G.glGetUniformLocation(prog, "uV3"); uCam = G.glGetUniformLocation(prog, "uCam")
        uCol = G.glGetUniformLocation(prog, "uCol"); uHas = G.glGetUniformLocation(prog, "uHas"); uCls = G.glGetUniformLocation(prog, "uCls")
        uBlush = G.glGetUniformLocation(prog, "uBlush"); uFaux = G.glGetUniformLocation(prog, "uFaux"); uTex = G.glGetUniformLocation(prog, "uTex"); uBones = G.glGetUniformLocation(prog, "uBones")
        if (progE != 0) { eVP = G.glGetUniformLocation(progE, "uVP"); eBones = G.glGetUniformLocation(progE, "uBones"); eEdge = G.glGetUniformLocation(progE, "uEdge"); eAsp = G.glGetUniformLocation(progE, "uAspect"); eCol = G.glGetUniformLocation(progE, "uEC") }
        if (progB != 0) bAsp = G.glGetUniformLocation(progB, "uAspect")
        hasUpload = false
        model?.let { m -> rig?.let { r -> upload(m, r) } }
    }
    override fun onSurfaceChanged(u: GL10?, W: Int, H: Int) { w = max(W, 1); h = max(H, 1); G.glViewport(0, 0, W, H) }

    private fun clsOf(n: String): Int = when {
        Regex("^(Body)$|肌").containsMatchIn(n) -> 1
        Regex("^(Face|FaceLayer)$|颜").containsMatchIn(n) -> 3
        Regex("Hair|髮|发").containsMatchIn(n) -> 2
        Regex("眉|白目|口|齿|目$|睫|二重").containsMatchIn(n) -> 4
        else -> 0
    }

    private fun freeGl() {
        if (!hasUpload) return
        try {
            G.glDeleteBuffers(3, intArrayOf(vboP, vboS, ibo), 0); G.glDeleteVertexArrays(1, intArrayOf(vao), 0)
            if (texs.isNotEmpty()) G.glDeleteTextures(texs.size, texs, 0)
            G.glDeleteTextures(1, intArrayOf(tboneTex), 0)
        } catch (e: Throwable) { }
        hasUpload = false
    }

    private fun upload(m: PmxModel, r: Rig) {
        freeGl()
        val a = IntArray(3); G.glGenBuffers(3, a, 0); vboP = a[0]; vboS = a[1]; ibo = a[2]
        val v = IntArray(1); G.glGenVertexArrays(1, v, 0); vao = v[0]
        G.glBindVertexArray(vao)
        // posisi (dinamis hanya saat morf berubah)
        posBuf = ByteBuffer.allocateDirect(m.nv * 12).order(ByteOrder.nativeOrder()).asFloatBuffer()
        posBuf!!.put(r.mpos); posBuf!!.position(0)
        G.glBindBuffer(G.GL_ARRAY_BUFFER, vboP); G.glBufferData(G.GL_ARRAY_BUFFER, m.nv * 12, posBuf, G.GL_DYNAMIC_DRAW)
        G.glEnableVertexAttribArray(0); G.glVertexAttribPointer(0, 3, G.GL_FLOAT, false, 12, 0)
        // statis: normal(12) uv(8) tulang(4 x ushort = 8) bobot(16) = 44 byte
        val sb = ByteBuffer.allocateDirect(m.nv * 44).order(ByteOrder.nativeOrder())
        val nb = r.nb
        for (i in 0 until m.nv) {
            sb.putFloat(m.nor[i * 3]); sb.putFloat(m.nor[i * 3 + 1]); sb.putFloat(m.nor[i * 3 + 2]); sb.putFloat(m.uv[i * 2]); sb.putFloat(m.uv[i * 2 + 1])
            for (k in 0..3) { val b = m.bi[i * 4 + k]; sb.putShort(if (b in 0 until nb) b.toShort() else 0) }
            for (k in 0..3) { val b = m.bi[i * 4 + k]; sb.putFloat(if (b in 0 until nb) m.bw[i * 4 + k] else 0f) }
        }
        sb.position(0)
        G.glBindBuffer(G.GL_ARRAY_BUFFER, vboS); G.glBufferData(G.GL_ARRAY_BUFFER, m.nv * 44, sb, G.GL_STATIC_DRAW)
        G.glEnableVertexAttribArray(1); G.glVertexAttribPointer(1, 3, G.GL_FLOAT, false, 44, 0)
        G.glEnableVertexAttribArray(2); G.glVertexAttribPointer(2, 2, G.GL_FLOAT, false, 44, 12)
        G.glEnableVertexAttribArray(3); G.glVertexAttribIPointer(3, 4, G.GL_UNSIGNED_SHORT, 44, 20)
        G.glEnableVertexAttribArray(4); G.glVertexAttribPointer(4, 4, G.GL_FLOAT, false, 44, 28)
        // indeks
        if (m.nv <= 65535) {
            idxType = G.GL_UNSIGNED_SHORT
            val ib = ByteBuffer.allocateDirect(m.idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            for (x in m.idx) ib.put(x.toShort()); ib.position(0)
            G.glBindBuffer(G.GL_ELEMENT_ARRAY_BUFFER, ibo); G.glBufferData(G.GL_ELEMENT_ARRAY_BUFFER, m.idx.size * 2, ib, G.GL_STATIC_DRAW)
        } else {
            idxType = G.GL_UNSIGNED_INT
            val ib = ByteBuffer.allocateDirect(m.idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer(); ib.put(m.idx); ib.position(0)
            G.glBindBuffer(G.GL_ELEMENT_ARRAY_BUFFER, ibo); G.glBufferData(G.GL_ELEMENT_ARRAY_BUFFER, m.idx.size * 4, ib, G.GL_STATIC_DRAW)
        }
        G.glBindVertexArray(0)
        // tekstur matriks tulang (RGBA32F, 3 x nb)
        val t = IntArray(1); G.glGenTextures(1, t, 0); tboneTex = t[0]
        G.glBindTexture(G.GL_TEXTURE_2D, tboneTex)
        skinBuf = ByteBuffer.allocateDirect(nb * 12 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        G.glTexImage2D(G.GL_TEXTURE_2D, 0, G.GL_RGBA32F, 3, nb, 0, G.GL_RGBA, G.GL_FLOAT, null)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MIN_FILTER, G.GL_NEAREST); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MAG_FILTER, G.GL_NEAREST)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_S, G.GL_CLAMP_TO_EDGE); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_T, G.GL_CLAMP_TO_EDGE)
        // tekstur warna
        texs = IntArray(m.tex.size)
        if (texs.isNotEmpty()) G.glGenTextures(texs.size, texs, 0)
        for (i in texs.indices) {
            val bm = try { texProv?.invoke(i) } catch (e: Throwable) { null } ?: continue
            G.glBindTexture(G.GL_TEXTURE_2D, texs[i]); GLUtils.texImage2D(G.GL_TEXTURE_2D, 0, bm, 0); bm.recycle()
            G.glGenerateMipmap(G.GL_TEXTURE_2D)
            G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MIN_FILTER, G.GL_LINEAR_MIPMAP_LINEAR); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MAG_FILTER, G.GL_LINEAR)
            G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_S, G.GL_REPEAT); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_T, G.GL_REPEAT)
        }
        cls = IntArray(m.mats.size) { clsOf(m.mats[it].name) }
        face = FaceMap(r); centerI = r.idx["センター"] ?: -1
        val sh = r.bonePos("左腕"); val el = r.bonePos("左ひじ")
        down = if (sh != null && el != null) (1.25f - atan2(sh[1] - el[1], el[0] - sh[0])).coerceIn(0f, 1.4f) else .9f
        clip = null; clipT = 0f; last = 0L; hasUpload = true
    }

    private fun setM(i: Int, v: Float) { val r = rig ?: return; if (i >= 0 && i < r.mw.size && !r.clipHasMorph(i)) r.mw[i] = v }
    private fun ez(a: Float, b: Float, k: Float) = a + (b - a) * k

    private fun frame(dt: Float) {
        val r = rig ?: return; val hd = hands; val fm = face ?: return
        val wc = wantClip; val t = time
        if (wantReset) { wantReset = false; clip = null; wantClip = null; r.resetPose(); r.clearOverrides() }
        if (wc != null && wc !== clip) { clip = wc; clipT = 0f; r.resetPose(); r.clearOverrides(); hd?.plan = null }
        pendingPlan?.let { p -> pendingPlan = null; if (clip == null) hd?.play(p, t) }
        val c = clip
        clipPlaying = c != null
        val X = hd?.ex ?: FloatArray(Hands.EXN)
        if (c != null) {
            clipT += dt * 30f * speed
            if (c.frames > 0 && clipT > c.frames + 15) { clipT = 0f; r.physReset() }
            r.applyClip(c, min(clipT, c.frames.toFloat()))
        } else {
            val bow = X[3] * .6f
            r.drive("上半身", .03f + .012f * sin(1.6f * t) + bow, sin(.37f * t) * .05f, sin(.5f * t) * .02f + X[4] * .2f)
            r.drive("上半身2", sin(1.6f * t + .6f) * .018f + bow * .3f, 0f, 0f)
            r.drive("首", X[1] * .15f, sin(.37f * t) * .15f + X[0] * .2f, X[2] * .1f)
            r.drive("頭", sin(.23f * t) * .04f + X[1] * .4f, sin(.37f * t) * .2f + X[0] * .45f, sin(.6f * t) * .03f + X[2] * .35f)
            r.drive("左腕", 0f, 0f, -down + sin(.9f * t) * .012f); r.drive("右腕", 0f, 0f, down - sin(.9f * t + 1.7f) * .012f)
            r.drive("左ひじ", 0f, -.45f, 0f); r.drive("右ひじ", 0f, .45f, 0f)
            if (t > sacc) { sx = (Random.nextFloat() - .5f) * .5f; sy = (Random.nextFloat() - .5f) * .3f; sacc = t + .7f + Random.nextFloat() * 1.8f }
            val gx = if (X[18] > .5f) X[16].coerceIn(-1f, 1f) else sx; val gy = if (X[18] > .5f) X[17] else sy
            r.drive("両目", gy * .12f, gx * .2f, 0f)
            if (centerI >= 0) r.lt[centerI * 3 + 1] = X[6] * 1.6f
            r.drive("センター", 0f, X[5] * (PI.toFloat() / 2f), 0f)
            r.smooth(dt)
            if (hd != null && hd.ok) { if (hd.needsIk()) r.fkPass(); hd.update(t, dt) }
            planActive = hd?.plan != null
        }
        // wajah
        if (blinkP < 0f && t > blinkAt) blinkP = 0f
        var bl = 0f
        if (blinkP >= 0f) { blinkP += dt / .17f; bl = sin(min(blinkP, 1f) * PI.toFloat()); if (blinkP >= 1f) { blinkP = -1f; blinkAt = t + 2f + (t * 7f % 3f) } }
        setM(fm.blink, max(bl, max(X[8], 0f)))
        setM(fm.bl, max(X[9], 0f)); setM(fm.br, max(X[10], 0f))
        val speak = talking
        mouth = ez(mouth, if (speak) (.2f + .4f * abs(sin(t * 13f))) * (.6f + .4f * sin(t * 5.3f).pow(2)) else 0f, .4f)
        setM(fm.a, max(mouth, X[11])); setM(fm.o, max(if (speak) max(0f, sin(t * 4.1f)) * .3f else 0f, X[12]))
        smile = ez(smile, if (speak) .2f else .45f, .1f)
        setM(fm.sm, max(smile, X[7] * .9f))
        val (ei, ew, bt) = when (emoName) {
            "riang" -> Triple(1, .7f, .3f); "senang" -> Triple(0, .5f, .2f); "sedih" -> Triple(3, .6f, 0f); "marah" -> Triple(4, .7f, 0f)
            "malu" -> Triple(3, .45f, 1f); "kaget" -> Triple(2, .8f, 0f); else -> Triple(0, .15f, 0f)
        }
        for (i in 0..4) { ef[i] = ez(ef[i], if (i == ei) ew * .8f else 0f, .15f); setM(fm.e[i], ef[i]) }
        blush = ez(blush, bt, .05f)
        setM(fm.up, max(if (speak) .3f * max(0f, sin(t * 2.1f)) else 0f, max(X[13], 0f))); setM(fm.dn, max(-X[13], 0f))
        setM(fm.puff, X[14]); setM(fm.wide, X[15]); setM(fm.sq, max(X[20], if (sleepy) .3f else 0f)); setM(fm.tongue, X[19])
        r.physScale = physScale
        r.update(dt, c != null, physOn && physScale > .02f)
    }

    override fun onDrawFrame(u: GL10?) {
        pending?.let { (m, r, tx) -> pending = null; model = m; rig = r; hands = Hands(r); texProv = tx; if (prog != 0) upload(m, r) }
        G.glClear(G.GL_COLOR_BUFFER_BIT or G.GL_DEPTH_BUFFER_BIT)
        val m = model ?: return; val r = rig ?: return
        if (prog == 0 || !hasUpload) return
        val now = System.nanoTime(); val dt = if (last == 0L) .033f else min((now - last) / 1e9f, .06f); last = now; time += dt
        frame(dt)
        // unggah matriks tulang & morf
        val sbuf = skinBuf!!; sbuf.position(0); sbuf.put(r.skin); sbuf.position(0)
        G.glActiveTexture(G.GL_TEXTURE1); G.glBindTexture(G.GL_TEXTURE_2D, tboneTex)
        G.glTexSubImage2D(G.GL_TEXTURE_2D, 0, 0, 0, 3, r.nb, G.GL_RGBA, G.GL_FLOAT, sbuf)
        if (r.mDirty) {
            val lo = r.mUpLo.coerceIn(0, m.nv - 1); val hi = r.mUpHi.coerceIn(lo, m.nv - 1); val pb = posBuf!!
            pb.position(lo * 3); pb.put(r.mpos, lo * 3, (hi - lo + 1) * 3); pb.position(lo * 3)
            G.glBindBuffer(G.GL_ARRAY_BUFFER, vboP); G.glBufferSubData(G.GL_ARRAY_BUFFER, lo * 12, (hi - lo + 1) * 12, pb)
            r.mDirty = false
        }
        val asp = w.toFloat() / h
        // latar gradien
        G.glDisable(G.GL_DEPTH_TEST); G.glDisable(G.GL_BLEND); G.glDisable(G.GL_CULL_FACE)
        if (progB != 0) { G.glUseProgram(progB); G.glUniform1f(bAsp, asp); G.glDrawArrays(G.GL_TRIANGLES, 0, 3) }
        // kamera
        val top = r.top; val dist = top * 1.05f * zoom; val ty = top * .74f + pan
        Matrix.perspectiveM(P, 0, 28f, asp, 1f, 300f)
        val cp = cos(pitch); val ex = dist * sin(yaw) * cp; val ey = ty + dist * sin(pitch); val ez = dist * cos(yaw) * cp
        Matrix.setLookAtM(V, 0, ex, ey, ez, 0f, ty, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(VP, 0, P, 0, V, 0)
        V3[0] = V[0]; V3[1] = V[1]; V3[2] = V[2]; V3[3] = V[4]; V3[4] = V[5]; V3[5] = V[6]; V3[6] = V[8]; V3[7] = V[9]; V3[8] = V[10]
        G.glEnable(G.GL_DEPTH_TEST); G.glEnable(G.GL_BLEND); G.glBlendFunc(G.GL_SRC_ALPHA, G.GL_ONE_MINUS_SRC_ALPHA)
        G.glBindVertexArray(vao)
        val doEdge = outline && progE != 0
        G.glUseProgram(prog)
        G.glUniformMatrix4fv(uVP, 1, false, VP, 0); G.glUniformMatrix3fv(uV3, 1, false, V3, 0); G.glUniform3f(uCam, ex, ey, ez)
        G.glUniform1i(uTex, 0); G.glUniform1i(uBones, 1); G.glUniform1f(uBlush, blush); G.glUniform1f(uFaux, if (doEdge) 0f else 1f)
        G.glActiveTexture(G.GL_TEXTURE0)
        val isz = if (idxType == G.GL_UNSIGNED_SHORT) 2 else 4
        for ((i, mt) in m.mats.withIndex()) {
            if (!mt.vis || mt.count == 0) continue
            if (mt.dbl) G.glDisable(G.GL_CULL_FACE) else { G.glEnable(G.GL_CULL_FACE); G.glCullFace(G.GL_BACK) }
            G.glUniform4f(uCol, mt.col[0], mt.col[1], mt.col[2], mt.col[3])
            G.glUniform1i(uCls, if (anime) cls[i] else 0)
            val ok = mt.tex >= 0 && mt.tex < texs.size
            G.glUniform1f(uHas, if (ok) 1f else 0f)
            if (ok) G.glBindTexture(G.GL_TEXTURE_2D, texs[mt.tex])
            G.glDrawElements(G.GL_TRIANGLES, mt.count, idxType, mt.first * isz)
        }
        if (doEdge) {
            G.glUseProgram(progE)
            G.glUniformMatrix4fv(eVP, 1, false, VP, 0); G.glUniform1i(eBones, 1); G.glUniform1f(eAsp, asp)
            G.glEnable(G.GL_CULL_FACE); G.glCullFace(G.GL_FRONT)
            for (mt in m.mats) {
                if (!mt.vis || mt.count == 0 || !mt.edge || mt.col[3] < .99f || mt.edgeSize <= 0f) continue
                G.glUniform4f(eCol, mt.edgeCol[0], mt.edgeCol[1], mt.edgeCol[2], 1f)
                G.glUniform1f(eEdge, edgeW * min(mt.edgeSize, 2f))
                G.glDrawElements(G.GL_TRIANGLES, mt.count, idxType, mt.first * isz)
            }
        }
        G.glBindVertexArray(0)
    }
}
