package com.mita.live

import android.graphics.Bitmap
import android.opengl.GLES30 as G
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class Gl : GLSurfaceView.Renderer {
    @Volatile var yaw = 0f; @Volatile var pitch = .05f; @Volatile var zoom = 1f; @Volatile var pan = 0f
    @Volatile var talking = false; @Volatile var wantClip: Clip? = null; @Volatile var wantReset = false; @Volatile var speed = 1f
    @Volatile var outline = true; @Volatile var aiPose: Map<String, FloatArray>? = null; @Volatile var aiDur = 3f; @Volatile var aiNew = false; @Volatile var aiWave = false; @Volatile var emo = -1
    @Volatile var physOn = true; @Volatile var physK = 1f
    @Volatile var tpx = 0f; @Volatile var tpy = 0f; @Volatile var tOn = false; @Volatile var tdx = 0f; @Volatile var tdy = 0f
    @Volatile var pickReq: Triple<Float, Float, String>? = null
    @Volatile var rl = 0f; @Volatile var rt = 0f; @Volatile var rr = 0f; @Volatile var rb = 0f
    var zoneCb: ((String, String) -> Unit)? = null
    @Volatile var gx = 0f; @Volatile var gy = 0f; @Volatile var gOn = false
    class Vis(val ch: CharArray, val end: FloatArray)
    @Volatile var vis: Vis? = null; @Volatile var visT0 = 0L
    @Volatile var env: FloatArray? = null; @Volatile var envT0 = 0L
    fun playVis(v: Vis?) { env = null; vis = v; visT0 = System.nanoTime() }
    fun playEnv(e: FloatArray?) { vis = null; env = e; envT0 = System.nanoTime() }
    @Volatile var snapReq = false; var snapCb: ((Bitmap) -> Unit)? = null
    @Volatile var recOn = false; var frameCb: ((Bitmap) -> Unit)? = null
    private var gsx = 0f; private var gsy = 0f; private var lastRec = 0f
    private var oI = -1; private var iI = -1; private var uI = -1; private var eI = -1
    private var gbuf: ByteBuffer? = null; private var gbm: Bitmap? = null
    var rig: Rig? = null
    private var model: PmxModel? = null
    private var prog = 0; private var posVbo = 0; private var stVbo = 0; private var ibo = 0; private var boneTex = 0
    private var texs = IntArray(0)
    private var posBuf: java.nio.FloatBuffer? = null; private var boneBuf: java.nio.FloatBuffer? = null; private var boneArr = FloatArray(0)
    private var w = 1; private var h = 1
    private var last = 0L; private var time = 0f; private var dtS = 0f
    private var clip: Clip? = null; private var clipT = 0f
    private var down = .9f; private var blinkAt = 2f; private var blinkP = -1f
    private var bI = -1; private var mI = -1; private var sI = -1
    private var aiEnd = 0f; private var emoIdx = IntArray(4) { -1 }
    private var dist = 10f; private var tgy = 10f; private var lastDrag = -9f
    private val P = FloatArray(16); private val V = FloatArray(16); private val MVP = FloatArray(16)
    private val tv = FloatArray(4); private val ov = FloatArray(4); private val po = FloatArray(2)
    private var pending: Triple<PmxModel, Rig, (Int) -> Bitmap?>? = null
    private var texProv: ((Int) -> Bitmap?)? = null

    fun setModel(m: PmxModel, r: Rig, tex: (Int) -> Bitmap?) { pending = Triple(m, r, tex) }
    fun inside(x: Float, y: Float) = x >= rl && x <= rr && y >= rt && y <= rb

    override fun onSurfaceCreated(u: GL10?, c: EGLConfig?) {
        G.glClearColor(0f, 0f, 0f, 0f)
        fun sh(t: Int, s: String): Int { val i = G.glCreateShader(t); G.glShaderSource(i, s); G.glCompileShader(i); return i }
        val vs = "#version 300 es\nuniform mat4 uM;uniform float uOut;uniform highp sampler2D uB;layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec2 aT;layout(location=3) in vec4 aW;layout(location=4) in ivec4 aI;out vec3 vN;out vec2 vT;" +
            "vec3 rq(vec4 q,vec3 v){vec3 t=2.*cross(q.xyz,v);return v+q.w*t+cross(q.xyz,t);}" +
            "void main(){vec3 p=vec3(0.);vec3 n=vec3(0.);float ws=0.;for(int k=0;k<4;k++){float w=aW[k];if(w<=0.)continue;int b=aI[k];if(b<0)continue;vec4 q=texelFetch(uB,ivec2(b*2,0),0);vec3 t=texelFetch(uB,ivec2(b*2+1,0),0).xyz;p+=w*(rq(q,aP)+t);n+=w*rq(q,aN);ws+=w;}" +
            "if(ws<=0.){p=aP;n=aN;}vN=n;vT=aT;gl_Position=uM*vec4(p+normalize(n+vec3(.0001))*uOut,1.);}"
        val fs = "#version 300 es\nprecision mediump float;uniform sampler2D uTex;uniform float uLine;uniform vec4 uCol;uniform float uHas;in vec3 vN;in vec2 vT;out vec4 o;void main(){if(uLine>.5){o=vec4(.1,.06,.08,1.);return;}vec4 t=mix(vec4(1.),texture(uTex,vT),uHas);vec4 c=t*uCol;float h=dot(normalize(vN),normalize(vec3(-.3,.6,.75)))*.5+.5;float l=smoothstep(.34,.54,h);o=vec4(c.rgb*mix(.72,1.05,l),c.a);if(o.a<.03)discard;}"
        prog = G.glCreateProgram(); G.glAttachShader(prog, sh(G.GL_VERTEX_SHADER, vs)); G.glAttachShader(prog, sh(G.GL_FRAGMENT_SHADER, fs)); G.glLinkProgram(prog)
        model?.let { m -> rig?.let { r -> upload(m, r) } }
    }
    override fun onSurfaceChanged(u: GL10?, W: Int, H: Int) { w = W; h = H; G.glViewport(0, 0, W, H) }

    private fun upload(m: PmxModel, r: Rig) {
        G.glActiveTexture(G.GL_TEXTURE0)
        val a = IntArray(3); G.glGenBuffers(3, a, 0); posVbo = a[0]; stVbo = a[1]; ibo = a[2]
        posBuf = ByteBuffer.allocateDirect(m.nv * 12).order(ByteOrder.nativeOrder()).asFloatBuffer(); posBuf!!.put(m.pos); posBuf!!.position(0)
        G.glBindBuffer(G.GL_ARRAY_BUFFER, posVbo); G.glBufferData(G.GL_ARRAY_BUFFER, m.nv * 12, posBuf, G.GL_DYNAMIC_DRAW)
        val bb = ByteBuffer.allocateDirect(m.nv * 52).order(ByteOrder.nativeOrder())
        for (i in 0 until m.nv) {
            bb.putFloat(m.nor[i * 3]); bb.putFloat(m.nor[i * 3 + 1]); bb.putFloat(m.nor[i * 3 + 2]); bb.putFloat(m.uv[i * 2]); bb.putFloat(m.uv[i * 2 + 1])
            for (k in 0..3) bb.putFloat(m.bw[i * 4 + k]); for (k in 0..3) bb.putInt(m.bi[i * 4 + k])
        }
        bb.position(0)
        G.glBindBuffer(G.GL_ARRAY_BUFFER, stVbo); G.glBufferData(G.GL_ARRAY_BUFFER, m.nv * 52, bb, G.GL_STATIC_DRAW)
        val ib = ByteBuffer.allocateDirect(m.idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer(); ib.put(m.idx); ib.position(0)
        G.glBindBuffer(G.GL_ELEMENT_ARRAY_BUFFER, ibo); G.glBufferData(G.GL_ELEMENT_ARRAY_BUFFER, m.idx.size * 4, ib, G.GL_STATIC_DRAW)
        texs = IntArray(m.tex.size); G.glGenTextures(texs.size, texs, 0)
        for (i in texs.indices) {
            val bm = try { texProv?.invoke(i) } catch (e: Throwable) { null } ?: continue
            G.glBindTexture(G.GL_TEXTURE_2D, texs[i]); GLUtils.texImage2D(G.GL_TEXTURE_2D, 0, bm, 0); bm.recycle()
            G.glGenerateMipmap(G.GL_TEXTURE_2D)
            G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MIN_FILTER, G.GL_LINEAR_MIPMAP_LINEAR); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MAG_FILTER, G.GL_LINEAR)
            G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_S, G.GL_REPEAT); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_T, G.GL_REPEAT)
        }
        val bt = IntArray(1); G.glGenTextures(1, bt, 0); boneTex = bt[0]
        G.glActiveTexture(G.GL_TEXTURE1); G.glBindTexture(G.GL_TEXTURE_2D, boneTex)
        G.glTexImage2D(G.GL_TEXTURE_2D, 0, G.GL_RGBA32F, r.nb * 2, 1, 0, G.GL_RGBA, G.GL_FLOAT, null)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MIN_FILTER, G.GL_NEAREST); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MAG_FILTER, G.GL_NEAREST)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_S, G.GL_CLAMP_TO_EDGE); G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_T, G.GL_CLAMP_TO_EDGE)
        G.glActiveTexture(G.GL_TEXTURE0)
        boneArr = FloatArray(r.nb * 8); boneBuf = ByteBuffer.allocateDirect(r.nb * 32).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val find = { l: List<String> -> l.firstNotNullOfOrNull { n -> r.mIdx[n] } ?: -1 }
        bI = find(listOf("まばたき", "Blink")); mI = find(listOf("あ", "A")); sI = find(listOf("にこり", "SmileSmall"))
        oI = find(listOf("お", "O")); iI = find(listOf("い", "I")); uI = find(listOf("う", "U")); eI = find(listOf("え", "E"))
        val sh = r.bonePos("左腕"); val el = r.bonePos("左ひじ")
        down = if (sh != null && el != null) (1.25f - atan2(sh[1] - el[1], el[0] - sh[0])).coerceIn(0f, 1.4f) else .9f
        clip = null; clipT = 0f; last = 0L
        emoIdx = listOf(listOf("笑い", "SmileBig"), listOf("困る", "Sad"), listOf("怒り", "Angry"), listOf("びっくり", "EyesWonder")).map { l -> find(l) }.toIntArray()
    }
    private fun proj(x: Float, y: Float, z: Float) {
        tv[0] = x; tv[1] = y; tv[2] = z; tv[3] = 1f
        Matrix.multiplyMV(ov, 0, MVP, 0, tv, 0)
        val iw = if (abs(ov[3]) < 1e-6f) 1f else 1f / ov[3]
        po[0] = (ov[0] * iw * .5f + .5f) * w; po[1] = (1f - (ov[1] * iw * .5f + .5f)) * h
    }
    private fun computeRect(r: Rig) {
        var x0 = 1e9f; var y0 = 1e9f; var x1 = -1e9f; var y1 = -1e9f
        for (cx in 0..1) for (cy in 0..1) for (cz in 0..1) {
            proj(if (cx == 0) r.minX else r.maxX, if (cy == 0) r.bottom else r.top, if (cz == 0) r.minZ else r.maxZ)
            x0 = min(x0, po[0]); x1 = max(x1, po[0]); y0 = min(y0, po[1]); y1 = max(y1, po[1])
        }
        val sw = (x1 - x0) * .14f; val sh = (y1 - y0) * .04f
        rl = x0 + sw; rr = x1 - sw; rt = y0 + sh; rb = y1 - sh
    }
    private fun nearest(r: Rig, x: Float, y: Float, maxD: Float): Int {
        var best = -1; var bd = maxD
        for (i in 0 until r.nb) {
            val nm = r.m.bones[i].name
            if (nm.contains("ＩＫ") || nm.contains("IK") || nm.contains("親") || nm.contains("センター") || nm.contains("グルーブ")) continue
            proj(r.wt[i * 3], r.wt[i * 3 + 1], r.wt[i * 3 + 2])
            val d = hypot(po[0] - x, po[1] - y); if (d < bd) { bd = d; best = i }
        }
        return best
    }
    private fun pushAt(r: Rig, x: Float, y: Float, rad: Float, vx: Float, vy: Float, vz: Float) {
        for (i in r.phys) {
            proj(r.wt[i * 3], r.wt[i * 3 + 1], r.wt[i * 3 + 2])
            val d = hypot(po[0] - x, po[1] - y)
            if (d < rad) { val f = (1f - d / rad) * 150f; r.impulse(i, vx * f, vy * f, vz * f) }
        }
    }
    private fun touchStep(r: Rig, dt: Float) {
        val rad = min(w, h) * .17f
        val wpp = 2f * dist * .2493f / h
        val rx = cos(yaw); val rz = -sin(yaw)
        val pq = pickReq
        if (pq != null) {
            pickReq = null
            val bi = nearest(r, pq.first, pq.second, rad * 1.5f)
            zoneCb?.invoke(if (bi >= 0) r.m.bones[bi].name else "", pq.third)
            val fx = -sin(yaw); val fz = -cos(yaw); val sp = if (pq.third == "pinch") 3f else 7f
            pushAt(r, pq.first, pq.second, rad, fx * sp, 0f, fz * sp)
        }
        if (tOn) {
            val dx = tdx; val dy = tdy; tdx = 0f; tdy = 0f
            val k = wpp / max(dt, .008f)
            pushAt(r, tpx, tpy, rad, rx * dx * k, -dy * k, rz * dx * k)
            if (hypot(dx, dy) > 1.5f && time - lastDrag > 1.7f) {
                lastDrag = time
                val bi = nearest(r, tpx, tpy, rad * 1.5f)
                zoneCb?.invoke(if (bi >= 0) r.m.bones[bi].name else "", "drag")
            }
        }
    }
    private fun lip(r: Rig, dt: Float, t: Float) {
        var a = 0f; var o = 0f; var i = 0f; var u = 0f; var e = 0f
        if (talking) {
            val now = System.nanoTime()
            val en = env; val vs = vis
            if (en != null) {
                val k = (((now - envT0) / 1e9f) / .05f).toInt()
                val lv = if (k >= 0 && k < en.size) en[k] else 0f
                a = lv * .85f; o = lv * (.15f + .35f * abs(sin(t * 6.5f)))
            } else if (vs != null) {
                val el = (now - visT0) / 1e9f
                var k = 0
                while (k < vs.end.size && el > vs.end[k]) k++
                if (k < vs.end.size) {
                    val st = if (k == 0) 0f else vs.end[k - 1]
                    val ph = ((el - st) / max(.01f, vs.end[k] - st)).coerceIn(0f, 1f)
                    val s = sin(ph * PI.toFloat())
                    when (vs.ch[k]) {
                        'a' -> a = .9f * s
                        'i' -> { i = .8f * s; a = .15f * s }
                        'u' -> u = .8f * s
                        'e' -> e = .8f * s
                        'o' -> o = .9f * s
                        else -> { }
                    }
                }
            } else a = .2f + .4f * abs(sin(t * 13f))
        }
        if (iI < 0) a += i * .35f
        if (eI < 0) a += e * .55f
        if (uI < 0) o += u * .55f
        a = a.coerceIn(0f, 1f); o = o.coerceIn(0f, 1f)
        val k2 = min(1f, dt * 22f)
        if (mI >= 0) r.mw[mI] += (a - r.mw[mI]) * k2
        if (oI >= 0) r.mw[oI] += (o - r.mw[oI]) * k2
        if (iI >= 0) r.mw[iI] += (i - r.mw[iI]) * k2
        if (uI >= 0) r.mw[uI] += (u - r.mw[uI]) * k2
        if (eI >= 0) r.mw[eI] += (e - r.mw[eI]) * k2
    }
    private fun grab(): Bitmap? {
        if (w < 2 || h < 2) return null
        var b = gbuf
        if (b == null || b.capacity() != w * h * 4) { b = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder()); gbuf = b }
        b!!.position(0); G.glReadPixels(0, 0, w, h, G.GL_RGBA, G.GL_UNSIGNED_BYTE, b); b.position(0)
        var bm = gbm
        if (bm == null || bm.width != w || bm.height != h) { bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); gbm = bm }
        bm!!.copyPixelsFromBuffer(b)
        return bm
    }
    private fun frame(dt: Float) {
        val r = rig ?: return
        val wc = wantClip
        if (wantReset) { wantReset = false; clip = null; wantClip = null; r.resetPose() }
        if (wc != null && wc !== clip) { clip = wc; clipT = 0f; r.resetPose() }
        val c = clip; val t = time
        r.useIk = c != null
        if (aiNew) { aiNew = false; aiEnd = t + aiDur }
        if (c != null) { clipT += dt * 30f * speed; if (c.frames > 0 && clipT > c.frames + 15) clipT = 0f; r.applyClip(c, min(clipT, c.frames.toFloat())) }
        else {
            r.drive("上半身", .03f + .012f * sin(1.6f * t), sin(.37f * t) * .05f, sin(.5f * t) * .02f)
            r.drive("上半身2", sin(1.6f * t + .6f) * .018f, 0f, 0f)
            val gg = if (gOn) 1f else 0f; val kg = min(1f, dt * 5f)
            gsx += (gx * gg - gsx) * kg; gsy += (gy * gg - gsy) * kg
            val wa = 1f - .85f * gg
            r.drive("首", gsy * .12f, sin(.37f * t) * .15f * wa + gsx * .2f, 0f)
            r.drive("頭", sin(.23f * t) * .04f * wa + gsy * .18f, sin(.37f * t) * .2f * wa + gsx * .3f, sin(.6f * t) * .03f)
            r.drive("左目", gsy * .25f, gsx * .4f, 0f); r.drive("右目", gsy * .25f, gsx * .4f, 0f)
            r.drive("左腕", 0f, 0f, -down + sin(.9f * t) * .012f); r.drive("右腕", 0f, 0f, down - sin(.9f * t + 1.7f) * .012f)
            r.drive("左ひじ", 0f, -.45f, 0f); r.drive("右ひじ", 0f, .45f, 0f)
            val ap = aiPose
            if (ap != null && t < aiEnd) {
                val wv = if (aiWave) sin(t * 9f) * .35f else 0f
                for ((n, v) in ap) when (n) {
                    "左腕" -> r.drive(n, v[0], v[1], -down + v[2])
                    "右腕" -> r.drive(n, v[0], -v[1], down - v[2])
                    "左ひじ" -> r.drive(n, 0f, -(v[1] + wv), 0f)
                    "右ひじ" -> r.drive(n, 0f, v[1] + wv, 0f)
                    else -> r.drive(n, v[0], v[1], v[2])
                }
            }
            r.smooth(dt)
        }
        if (blinkP < 0f && t > blinkAt) blinkP = 0f
        var bl = 0f
        if (blinkP >= 0f) { blinkP += dt / .17f; bl = sin(min(blinkP, 1f) * PI.toFloat()); if (blinkP >= 1f) { blinkP = -1f; blinkAt = t + 2f + (t * 7f % 3f) } }
        if (bI >= 0) r.mw[bI] = bl
        lip(r, dt, t)
        if (sI >= 0) r.mw[sI] = .4f
        for (k in 0..3) { val xi = emoIdx[k]; if (xi >= 0) r.mw[xi] += ((if (k == emo && t < aiEnd + 2f) .8f else 0f) - r.mw[xi]) * min(1f, dt * 5f) }
        r.physOn = physOn; r.physK = physK
        r.physics(dt)
        r.update()
    }
    override fun onDrawFrame(u: GL10?) {
        pending?.let { (m, r, tx) -> pending = null; model = m; rig = r; texProv = tx; upload(m, r) }
        G.glClear(G.GL_COLOR_BUFFER_BIT or G.GL_DEPTH_BUFFER_BIT)
        val m = model ?: return; val r = rig ?: return
        val now = System.nanoTime(); val raw = if (last == 0L) .016f else min((now - last) / 1e9f, .06f); last = now
        dtS = if (dtS == 0f) raw else dtS + (raw - dtS) * .25f
        val dt = dtS; time += dt
        dist = (r.top - r.bottom) * 1.05f * zoom
        tgy = r.bottom + (r.top - r.bottom) * .74f + pan
        Matrix.perspectiveM(P, 0, 28f, w.toFloat() / h, .5f, 500f)
        val cp = cos(pitch)
        Matrix.setLookAtM(V, 0, dist * sin(yaw) * cp, tgy + dist * sin(pitch), dist * cos(yaw) * cp, 0f, tgy, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(MVP, 0, P, 0, V, 0)
        computeRect(r)
        touchStep(r, dt)
        frame(dt)
        r.morphed()?.let { arr -> val pb = posBuf!!; pb.position(0); pb.put(arr); pb.position(0); G.glBindBuffer(G.GL_ARRAY_BUFFER, posVbo); G.glBufferSubData(G.GL_ARRAY_BUFFER, 0, m.nv * 12, pb) }
        r.boneData(boneArr); val bf = boneBuf!!; bf.position(0); bf.put(boneArr); bf.position(0)
        G.glActiveTexture(G.GL_TEXTURE1); G.glBindTexture(G.GL_TEXTURE_2D, boneTex)
        G.glTexSubImage2D(G.GL_TEXTURE_2D, 0, 0, 0, r.nb * 2, 1, G.GL_RGBA, G.GL_FLOAT, bf)
        G.glActiveTexture(G.GL_TEXTURE0)
        G.glUseProgram(prog)
        G.glUniformMatrix4fv(G.glGetUniformLocation(prog, "uM"), 1, false, MVP, 0)
        G.glUniform1i(G.glGetUniformLocation(prog, "uTex"), 0); G.glUniform1i(G.glGetUniformLocation(prog, "uB"), 1)
        val uL = G.glGetUniformLocation(prog, "uLine"); val uO = G.glGetUniformLocation(prog, "uOut")
        G.glUniform1f(uL, 0f); G.glUniform1f(uO, 0f)
        G.glEnable(G.GL_DEPTH_TEST); G.glEnable(G.GL_BLEND); G.glBlendFunc(G.GL_SRC_ALPHA, G.GL_ONE_MINUS_SRC_ALPHA)
        G.glBindBuffer(G.GL_ARRAY_BUFFER, posVbo); G.glEnableVertexAttribArray(0); G.glVertexAttribPointer(0, 3, G.GL_FLOAT, false, 12, 0)
        G.glBindBuffer(G.GL_ARRAY_BUFFER, stVbo)
        G.glEnableVertexAttribArray(1); G.glVertexAttribPointer(1, 3, G.GL_FLOAT, false, 52, 0)
        G.glEnableVertexAttribArray(2); G.glVertexAttribPointer(2, 2, G.GL_FLOAT, false, 52, 12)
        G.glEnableVertexAttribArray(3); G.glVertexAttribPointer(3, 4, G.GL_FLOAT, false, 52, 20)
        G.glEnableVertexAttribArray(4); G.glVertexAttribIPointer(4, 4, G.GL_INT, 52, 36)
        G.glBindBuffer(G.GL_ELEMENT_ARRAY_BUFFER, ibo)
        val uC = G.glGetUniformLocation(prog, "uCol"); val uH = G.glGetUniformLocation(prog, "uHas")
        for (mt in m.mats) {
            if (!mt.vis || mt.count == 0) continue
            if (mt.dbl) G.glDisable(G.GL_CULL_FACE) else { G.glEnable(G.GL_CULL_FACE); G.glCullFace(G.GL_BACK) }
            G.glUniform4f(uC, mt.col[0], mt.col[1], mt.col[2], mt.col[3])
            val ok = mt.tex >= 0 && mt.tex < texs.size
            G.glUniform1f(uH, if (ok) 1f else 0f)
            if (ok) G.glBindTexture(G.GL_TEXTURE_2D, texs[mt.tex])
            G.glDrawElements(G.GL_TRIANGLES, mt.count, G.GL_UNSIGNED_INT, mt.first * 4)
        }
        if (outline) {
            G.glUniform1f(uL, 1f); G.glUniform1f(uO, dist * .0016f)
            G.glEnable(G.GL_CULL_FACE); G.glCullFace(G.GL_FRONT)
            for (mt in m.mats) { if (!mt.vis || mt.count == 0 || mt.col[3] < .95f || mt.dbl) continue; G.glDrawElements(G.GL_TRIANGLES, mt.count, G.GL_UNSIGNED_INT, mt.first * 4) }
            G.glCullFace(G.GL_BACK); G.glUniform1f(uL, 0f); G.glUniform1f(uO, 0f)
        }
        if (snapReq) { snapReq = false; val bm = grab(); if (bm != null) snapCb?.invoke(bm) }
        if (recOn && time - lastRec >= .066f) { lastRec = time; val bm = grab(); if (bm != null) frameCb?.invoke(bm) }
    }
}
