package com.mita.live

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.*
import kotlin.random.Random

// Suara reaksi anime sintetis (tanpa AI, tanpa internet): sumber glotal + filter formant vokal.
object Vox {
    private const val SR = 22050
    private val F = mapOf(
        'a' to floatArrayOf(850f, 1220f, 2810f), 'i' to floatArrayOf(310f, 2250f, 3050f), 'u' to floatArrayOf(370f, 1500f, 2500f),
        'e' to floatArrayOf(600f, 1900f, 2700f), 'o' to floatArrayOf(500f, 900f, 2600f)
    )
    class Seg(val v: Char, val dur: Float, val f0a: Float, val f0b: Float, val amp: Float = 1f, val br: Float = 0f, val burst: Float = 0f)

    fun preset(n: String): List<Seg> {
        val r = 1f + (Random.nextFloat() - .5f) * .18f
        return when (n) {
            "pat" -> listOf(Seg('u', .10f, 380f * r, 410f * r, .7f, .3f), Seg('a', .30f, 430f * r, 540f * r, 1f, .12f), Seg('u', .14f, 520f * r, 420f * r, .6f, .2f))
            "hya" -> listOf(Seg('a', .12f, 650f * r, 920f * r, .9f, .1f, .03f), Seg('a', .30f, 920f * r, 560f * r))
            "kya" -> listOf(Seg('a', .10f, 700f * r, 1000f * r, .9f, .05f, .02f), Seg('a', .42f, 1050f * r, 760f * r))
            "kyaa" -> listOf(Seg('a', .12f, 800f * r, 1150f * r, .9f, .05f, .02f), Seg('a', .30f, 1200f * r, 1300f * r), Seg('a', .32f, 1250f * r, 700f * r))
            "eh" -> listOf(Seg('e', .11f, 520f * r, 700f * r), Seg('e', .16f, 700f * r, 560f * r, .85f))
            "ii" -> listOf(Seg('i', .10f, 520f * r, 680f * r, .9f), Seg('i', .26f, 700f * r, 520f * r))
            "nn" -> listOf(Seg('o', .12f, 420f * r, 470f * r, .7f, .2f), Seg('u', .26f, 470f * r, 410f * r, .8f))
            else -> listOf(Seg('a', .25f, 500f * r, 520f * r))
        }
    }

    fun render(segs: List<Seg>): ShortArray {
        var total = 0; for (s in segs) total += (s.dur * SR).toInt()
        val out = FloatArray(total + SR / 20)
        var pos = 0; var phase = 0f; var pf = F['a']!!; var tt = 0f
        val s1 = FloatArray(3); val s2 = FloatArray(3)
        val twoPi = 2f * PI.toFloat()
        for (s in segs) {
            val n = (s.dur * SR).toInt(); val tf = F[s.v] ?: F['a']!!
            for (k in 0 until n) {
                val u = k.toFloat() / n
                val env = min(1f, k / (SR * .01f)) * min(1f, (n - k) / (SR * .03f))
                val f0 = (s.f0a + (s.f0b - s.f0a) * u) * (1f + .012f * sin(tt * twoPi * 5.5f))
                tt += 1f / SR
                phase += f0 / SR; if (phase >= 1f) phase -= 1f
                val noise = Random.nextFloat() * 2f - 1f
                var src = (2f * phase - 1f) * (1f - s.br) + noise * s.br * .8f
                if (s.burst > 0f && k < SR * s.burst) src = noise * 1.2f
                val mix = min(1f, k / (SR * .04f))
                var y = 0f
                for (f in 0..2) {
                    val fr = (pf[f] + (tf[f] - pf[f]) * mix) * 1.12f
                    val bw = 80f + f * 60f
                    val rr = exp(-PI.toFloat() * bw / SR)
                    val b1 = 2f * rr * cos(twoPi * fr / SR); val b2 = -rr * rr
                    val yy = (1f - b1 - b2) * src + b1 * s1[f] + b2 * s2[f]
                    s2[f] = s1[f]; s1[f] = yy
                    y += yy * (if (f == 0) 1f else if (f == 1) .55f else .25f)
                }
                if (pos < out.size) out[pos++] = y * env * s.amp
            }
            pf = tf
        }
        var pk = 1e-6f; for (v in out) pk = max(pk, abs(v))
        val g = 0.7f * 32767f / pk
        return ShortArray(out.size) { (out[it] * g).toInt().coerceIn(-32767, 32767).toShort() }
    }

    fun play(segs: List<Seg>, onStart: () -> Unit, onEnd: () -> Unit) {
        Thread {
            try {
                val d = render(segs)
                val t = AudioTrack(AudioManager.STREAM_MUSIC, SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, d.size * 2, AudioTrack.MODE_STATIC)
                t.write(d, 0, d.size); onStart(); t.play()
                Thread.sleep((d.size * 1000L / SR) + 80)
                t.release()
            } catch (e: Throwable) { }
            onEnd()
        }.start()
    }
}
