package com.mita.live

import kotlin.math.*

/** Mesin gerak buatan AI: rencana keyframe (tangan, jari, wajah, kepala) -> IK lengan 2 tulang. Port dari Mita Live v7. */
class HandKf(var anchorH: Boolean, val pv: FloatArray, val dir: FloatArray, val pal: FloatArray, val fin: FloatArray, val pole: FloatArray) {
    fun copy() = HandKf(anchorH, pv.copyOf(), dir.copyOf(), pal.copyOf(), fin.copyOf(), pole.copyOf())
}
class Kf(val t: Float, val l: HandKf, val r: HandKf, val ex: FloatArray)
class CPlan(val t0: Float, val kfs: List<Kf>, val end: Float, val usedL: Boolean, val usedR: Boolean, val text: String)

object PlanData {
    // anchor 'h' = relatif kepala, 's' = relatif titik tengah bahu; satuan = panjang satu lengan
    val LAND: Map<String, FloatArray> = mapOf(
        "wajah" to f(1, .1f, .14f, .6f), "depan_wajah" to f(1, .1f, .14f, .6f), "pipi" to f(1, .17f, .04f, .2f),
        "mulut" to f(1, .04f, -.02f, .27f), "bibir" to f(1, .03f, -.02f, .27f), "dagu" to f(1, .04f, -.1f, .24f),
        "mata" to f(1, .09f, .18f, .3f), "hidung" to f(1, .02f, .1f, .3f), "telinga" to f(1, .22f, .12f, .04f),
        "rambut" to f(1, .25f, .28f, 0f), "kepala" to f(1, .2f, .34f, .08f), "atas_kepala" to f(1, .1f, .62f, .05f),
        "dahi" to f(1, .04f, .3f, .25f), "dada" to f(0, .07f, -.14f, .3f), "perut" to f(0, .05f, -.5f, .3f),
        "pinggang" to f(0, .43f, -.62f, .03f), "paha" to f(0, .36f, -1.0f, .06f), "punggung" to f(0, .1f, -.4f, -.3f),
        "samping" to f(0, .9f, .02f, .04f), "depan" to f(0, .2f, -.1f, .85f), "belakang" to f(0, .3f, -.35f, -.35f),
        "bawah" to f(0, .3f, -.9f, .05f), "atas" to f(0, .15f, 1.3f, .08f), "kamera" to f(0, .2f, .15f, 1.05f),
        "tengah" to f(0, 0f, -.1f, .55f), "bahu" to f(0, .32f, .02f, .1f)
    )
    private fun f(a: Int, x: Float, y: Float, z: Float) = floatArrayOf(a.toFloat(), x, y, z)
    val DIRS: Map<String, FloatArray> = mapOf(
        "atas" to v(0f, 1f, 0f), "bawah" to v(0f, -1f, 0f), "depan" to v(0f, 0f, 1f), "kamera" to v(0f, 0f, 1f), "belakang" to v(0f, 0f, -1f),
        "luar" to v(1f, 0f, 0f), "samping" to v(1f, 0f, 0f), "dalam" to v(-1f, 0f, 0f), "serong_atas" to v(.5f, .85f, .1f),
        "serong_atas_dalam" to v(-.45f, .85f, .2f), "serong_atas_luar" to v(.55f, .8f, .1f), "serong_bawah" to v(.6f, -.8f, .1f),
        "depan_atas" to v(0f, .7f, .7f), "depan_bawah" to v(0f, -.7f, .7f), "depan_dalam" to v(-.6f, .1f, .8f)
    )
    val PALMS: Map<String, FloatArray> = mapOf(
        "kamera" to v(0f, 0f, 1f), "depan" to v(0f, 0f, 1f), "badan" to v(0f, 0f, -1f), "belakang" to v(0f, 0f, -1f),
        "atas" to v(0f, 1f, 0f), "bawah" to v(0f, -1f, 0f), "luar" to v(1f, 0f, 0f), "dalam" to v(-1f, 0f, 0f)
    )
    val POLES: Map<String, FloatArray> = mapOf(
        "turun" to v(.25f, -1f, -.25f), "keluar" to v(1f, -.2f, -.1f), "naik" to v(.6f, .8f, -.1f),
        "depan" to v(.1f, -.3f, 1f), "belakang" to v(.3f, -.3f, -1f), "default" to v(.45f, -1f, -.35f)
    )
    private fun v(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)
    // [jempol_lipat, jempol_buka, telunjuk, tengah, manis, kelingking, renggang]  0=lurus 1=tekuk penuh
    val SHAPES: Map<String, FloatArray> = mapOf(
        "rileks" to s(.2f, .25f, .25f, .3f, .35f, .4f, .05f), "buka" to s(0f, .1f, 0f, 0f, 0f, 0f, .35f), "rapat" to s(0f, 0f, 0f, 0f, 0f, 0f, 0f),
        "kepal" to s(.7f, .2f, 1f, 1f, 1f, 1f, 0f), "tunjuk" to s(.8f, .2f, 0f, 1f, 1f, 1f, 0f), "peace" to s(.8f, .2f, 0f, 0f, 1f, 1f, .8f),
        "jempol" to s(0f, .9f, 1f, 1f, 1f, 1f, 0f), "ok" to s(.5f, .6f, .65f, 0f, 0f, 0f, .35f), "love_jari" to s(.55f, .7f, .6f, 1f, 1f, 1f, 0f),
        "setengah_hati" to s(.35f, .5f, .45f, .25f, .3f, .35f, 0f), "kucing" to s(.5f, .2f, .65f, .65f, .65f, .65f, 0f),
        "cakar" to s(.4f, .4f, .45f, .5f, .5f, .5f, .6f), "rock" to s(.8f, .2f, 0f, 1f, 1f, 0f, .7f), "ily" to s(0f, .9f, 0f, 1f, 1f, 0f, .7f),
        "pegang" to s(.35f, .3f, .5f, .55f, .6f, .65f, 0f)
    )
    private fun s(a: Float, b: Float, c: Float, d: Float, e: Float, f: Float, g: Float) = floatArrayOf(a, b, c, d, e, f, g)
    val ALIAS: Map<String, String> = mapOf(
        "love" to "love_jari", "hati" to "love_jari", "finger_heart" to "love_jari", "v" to "peace", "dua_jari" to "peace", "jari_dua" to "peace",
        "thumbs_up" to "jempol", "jempol_atas" to "jempol", "telunjuk" to "tunjuk", "menunjuk" to "tunjuk", "kepalan" to "kepal", "tinju" to "kepal",
        "genggam" to "kepal", "terbuka" to "buka", "lurus" to "rapat", "datar" to "rapat", "cat" to "kucing", "cakar_kucing" to "kucing",
        "setengah_love" to "setengah_hati", "hati_setengah" to "setengah_hati", "oke" to "ok", "santai" to "rileks", "relax" to "rileks"
    )
}

private fun norm(s: Any?): String = (s?.toString() ?: "").lowercase().trim().replace(Regex("[\\s\\-]+"), "_")
private fun num(v: Any?, d: Float): Float { val x = (v as? Number)?.toFloat() ?: v?.toString()?.toFloatOrNull() ?: return d; return if (x.isFinite()) x else d }
private fun vec3(a: Any?): FloatArray? {
    if (a !is List<*> || a.size < 3) return null
    val r = FloatArray(3) { (a[it] as? Number)?.toFloat() ?: return null }
    return if (r.all { it.isFinite() }) r else null
}
private fun unit(a: FloatArray): FloatArray { val l = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]).let { if (it < 1e-6f) 1f else it }; return floatArrayOf(a[0] / l, a[1] / l, a[2] / l) }
private fun cl(v: Float, a: Float, b: Float) = max(a, min(b, v))

class Hands(val rig: Rig) {
    companion object { const val EXN = 21 }
    val ex = FloatArray(EXN)
    @Volatile var plan: CPlan? = null
    val sides: Array<Side>
    val ok: Boolean
    private val headI = rig.idx["頭"] ?: -1
    private var ox = 0f; private var oy = 0f; private var oz = 0f
    var al = 5f
    private val tmp = FloatArray(4); private val q1 = FloatArray(4); private val q2 = FloatArray(4); private val v3 = FloatArray(3)

    inner class Side(val left: Boolean) {
        val pre = if (left) "左" else "右"
        val arm = rig.idx[pre + "腕"] ?: -1; val elb = rig.idx[pre + "ひじ"] ?: -1; val wri = rig.idx[pre + "手首"] ?: -1
        val mid = rig.idx[pre + "中指１"] ?: -1
        var l1 = 1f; var l2 = 1f; var hl = .5f; var sx = 1f
        val d1 = FloatArray(3); val d2 = FloatArray(3); val f0 = FloatArray(3); val n0 = FloatArray(3)
        val b0 = FloatArray(9)   // kolom f0,n0,z0
        var pathAE = IntArray(0); var pathEW = IntArray(0)
        val st = FloatArray(19); val sv = FloatArray(19); val tgt = FloatArray(19)
        var w = 0f; var wv = 0f; var init = false
        var on = false
        // indeks jari [jari 0..3][sendi 0..2], jempol [0..2]
        val fin = Array(4) { f -> IntArray(3) { j -> rig.idx[pre + arrayOf("人指", "中指", "薬指", "小指")[f] + arrayOf("１", "２", "３")[j]] ?: -1 } }
        val th = IntArray(3) { j -> rig.idx[pre + "親指" + arrayOf("０", "１", "２")[j]] ?: -1 }
        val valid get() = arm >= 0 && elb >= 0 && wri >= 0
        fun setup() {
            if (!valid) return
            val m = rig.m.bones
            fun p(i: Int) = floatArrayOf(m[i].x, m[i].y, m[i].z)
            val a = p(arm); val e = p(elb); val wr = p(wri)
            l1 = dist(a, e); l2 = dist(e, wr)
            for (i in 0..2) { d1[i] = (e[i] - a[i]) / max(l1, 1e-4f); d2[i] = (wr[i] - e[i]) / max(l2, 1e-4f) }
            if (mid >= 0) { val mm = p(mid); hl = dist(mm, wr); for (i in 0..2) f0[i] = (mm[i] - wr[i]) / max(hl, 1e-4f) } else { hl = l2 * .35f; for (i in 0..2) f0[i] = d2[i] }
            val dn = floatArrayOf(0f, -1f, 0f); val dd = dn[0] * f0[0] + dn[1] * f0[1] + dn[2] * f0[2]
            val nn = unit(floatArrayOf(dn[0] - f0[0] * dd, dn[1] - f0[1] * dd, dn[2] - f0[2] * dd))
            for (i in 0..2) n0[i] = nn[i]
            val z = floatArrayOf(f0[1] * n0[2] - f0[2] * n0[1], f0[2] * n0[0] - f0[0] * n0[2], f0[0] * n0[1] - f0[1] * n0[0])
            for (i in 0..2) { b0[i * 3] = f0[i]; b0[i * 3 + 1] = n0[i]; b0[i * 3 + 2] = z[i] }
            pathAE = chain(arm, rig.par[elb]); pathEW = chain(elb, rig.par[wri])
        }
        private fun chain(top: Int, bottom: Int): IntArray {
            val l = ArrayList<Int>(); var p = bottom; var g = 0
            while (p >= 0 && g++ < 64) { l.add(p); if (p == top) break; p = rig.par[p] }
            return if (l.isNotEmpty() && l.last() == top) { l.reverse(); l.toIntArray() } else intArrayOf(top)
        }
    }
    private fun dist(a: FloatArray, b: FloatArray) = sqrt((a[0] - b[0]).pow(2) + (a[1] - b[1]).pow(2) + (a[2] - b[2]).pow(2))

    init {
        val l = Side(true); val r = Side(false)
        sides = arrayOf(l, r)
        ok = l.valid && r.valid && headI >= 0
        if (ok) {
            l.setup(); r.setup()
            val ca = rig.m.bones[l.arm]; val cb = rig.m.bones[r.arm]
            val midx = (ca.x + cb.x) / 2
            l.sx = if (ca.x >= midx) 1f else -1f; r.sx = -l.sx
            al = ((l.l1 + l.l2) + (r.l1 + r.l2)) / 2f
            for (s in sides) { val sh = SHAPES_REST(); for (i in 0..6) s.st[9 + i] = sh[i]; val pl = PlanData.POLES["default"]!!; for (i in 0..2) { s.st[16 + i] = pl[i] } }
        }
    }
    private fun SHAPES_REST() = PlanData.SHAPES["rileks"]!!

    // ---------------------------------------------------------------- penyusunan rencana dari JSON (Map/List)
    private fun captureHand(s: Side): HandKf {
        val gt = rig.gt; val gq = rig.gq
        var fx = gt[s.wri * 3] - gt[s.elb * 3]; var fy = gt[s.wri * 3 + 1] - gt[s.elb * 3 + 1]; var fz = gt[s.wri * 3 + 2] - gt[s.elb * 3 + 2]
        val fl = max(sqrt(fx * fx + fy * fy + fz * fz), 1e-5f); fx /= fl; fy /= fl; fz /= fl
        qrot(gq, s.wri * 4, s.n0[0], s.n0[1], s.n0[2], v3)
        val px = gt[s.wri * 3] + fx * s.hl * .9f; val py = gt[s.wri * 3 + 1] + fy * s.hl * .9f; val pz = gt[s.wri * 3 + 2] + fz * s.hl * .9f
        val pv = floatArrayOf((px - ox) / al * s.sx, (py - oy) / al, (pz - oz) / al)
        val fin = FloatArray(7) { s.st[9 + it] }
        return HandKf(false, pv, floatArrayOf(fx * s.sx, fy, fz), floatArrayOf(v3[0] * s.sx, v3[1], v3[2]), fin, unit(PlanData.POLES["default"]!!))
    }

    private fun parseHand(sp: Map<*, *>, st: HandKf) {
        val p = sp["pos"] ?: sp["posisi"] ?: sp["tangan"]
        if (p is String) { val L = PlanData.LAND[norm(p)]; if (L != null) { st.anchorH = L[0] > .5f; st.pv[0] = L[1]; st.pv[1] = L[2]; st.pv[2] = L[3] } }
        else { val v = vec3(p); if (v != null) { st.anchorH = false; for (i in 0..2) st.pv[i] = cl(v[i], if (i == 1) -2f else -1.6f, if (i == 1) 2f else 1.6f) } }
        val g = vec3(sp["geser"]); if (g != null && p != null) for (i in 0..2) st.pv[i] += cl(g[i], -.6f, .6f)
        else if (g != null) for (i in 0..2) st.pv[i] += cl(g[i], -.6f, .6f)
        val ar = sp["arah"] ?: sp["dir"]
        if (ar is String && PlanData.DIRS.containsKey(norm(ar))) System.arraycopy(unit(PlanData.DIRS[norm(ar)]!!), 0, st.dir, 0, 3)
        else vec3(ar)?.let { System.arraycopy(unit(it), 0, st.dir, 0, 3) }
        val tp = sp["telapak"] ?: sp["palm"]
        if (tp is String && PlanData.PALMS.containsKey(norm(tp))) System.arraycopy(PlanData.PALMS[norm(tp)]!!, 0, st.pal, 0, 3)
        else vec3(tp)?.let { System.arraycopy(unit(it), 0, st.pal, 0, 3) }
        val sk = sp["siku"]
        if (sk is String && PlanData.POLES.containsKey(norm(sk))) System.arraycopy(unit(PlanData.POLES[norm(sk)]!!), 0, st.pole, 0, 3)
        else vec3(sk)?.let { System.arraycopy(unit(it), 0, st.pole, 0, 3) }
        val j = sp["jari"] ?: sp["bentuk"]
        if (j is String) { val n = norm(j); val sh = PlanData.SHAPES[PlanData.ALIAS[n] ?: n]; if (sh != null) System.arraycopy(sh, 0, st.fin, 0, 7) }
        else if (j is List<*>) { for (i in 0 until min(7, j.size)) (j[i] as? Number)?.let { st.fin[i] = cl(it.toFloat(), 0f, 1f) } }
        else if (j is Map<*, *>) { arrayOf("jempol", "jempol_buka", "telunjuk", "tengah", "manis", "kelingking", "renggang").forEachIndexed { i, n -> (j[n] as? Number)?.let { st.fin[i] = cl(it.toFloat(), 0f, 1f) } } }
    }

    // ex: 0-2 kepala(toleh,angguk,miring) 3 bungkuk 4 condong 5 putar 6 lompat 7 senyum 8 mata_tutup 9 wink_kiri 10 wink_kanan 11 mulut_a 12 mulut_o 13 alis 14 pipi 15 lebar 16-17 lihat xy 18 lihat_on 19 lidah 20 sipit
    private fun parseEx(k: Map<*, *>, ex: FloatArray) {
        (k["kepala"] ?: k["head"] as? Map<*, *>).let { hd ->
            if (hd is Map<*, *>) { if (hd["toleh"] != null) ex[0] = cl(num(hd["toleh"], 0f), -1f, 1f); if (hd["angguk"] != null) ex[1] = cl(num(hd["angguk"], 0f), -1f, 1f); if (hd["miring"] != null) ex[2] = cl(num(hd["miring"], 0f), -1f, 1f) }
        }
        (k["badan"] ?: k["body"]).let { bd ->
            if (bd is Map<*, *>) {
                if (bd["bungkuk"] != null) ex[3] = cl(num(bd["bungkuk"], 0f), 0f, 1f); if (bd["condong"] != null) ex[4] = cl(num(bd["condong"], 0f), -1f, 1f)
                if (bd["putar"] != null) ex[5] = cl(num(bd["putar"], 0f), -4f, 4f); if (bd["lompat"] != null) ex[6] = cl(num(bd["lompat"], 0f), 0f, 1f)
            }
        }
        (k["wajah"] ?: k["face"]).let { wj ->
            if (wj is Map<*, *>) {
                if (wj["senyum"] != null) ex[7] = cl(num(wj["senyum"], 0f), 0f, 1f)
                if (wj["mata"] != null) { val m = norm(wj["mata"]); ex[8] = if (m == "tutup") 1f else 0f; ex[9] = if (m == "wink_kiri") 1f else 0f; ex[10] = if (m == "wink_kanan") 1f else 0f; ex[15] = if (m == "lebar") 1f else 0f; ex[20] = if (m == "sipit") 1f else 0f }
                if (wj["mulut"] != null) { val m = norm(wj["mulut"]); ex[11] = if (m == "a") .8f else 0f; ex[12] = if (m == "o") .8f else 0f; ex[19] = if (m == "lidah") 1f else 0f }
                if (wj["alis"] != null) ex[13] = cl(num(wj["alis"], 0f), -1f, 1f); if (wj["pipi"] != null) ex[14] = cl(num(wj["pipi"], 0f), 0f, 1f)
            }
        }
        val lh = k["lihat"] ?: k["mata_lihat"]
        if (lh is String) {
            ex[18] = 1f
            when (norm(lh)) {
                "kamera" -> { ex[16] = 0f; ex[17] = 0f }; "kiri" -> { ex[16] = .8f; ex[17] = 0f }; "kanan" -> { ex[16] = -.8f; ex[17] = 0f }
                "atas" -> { ex[16] = 0f; ex[17] = -.7f }; "bawah" -> { ex[16] = 0f; ex[17] = .7f }
                "tangan_kiri" -> { ex[16] = 2f; ex[17] = 0f }; "tangan_kanan" -> { ex[16] = 3f; ex[17] = 0f }
                else -> ex[18] = 0f
            }
        }
    }

    /** Susun & mainkan rencana dari JSON hasil AI. Harus dipanggil dari thread GL. */
    fun play(p: Map<*, *>, now: Float): Boolean {
        if (!ok) return false
        val arrAny = p["gerak"] ?: p["kf"] ?: p["keyframes"]
        val arr = (arrAny as? List<*>)?.filterIsInstance<Map<*, *>>()?.filter { it["t"] != null && num(it["t"], Float.NaN).isFinite() }
            ?.sortedBy { cl(num(it["t"], 0f), .3f, 11f) }?.take(14) ?: return false
        if (arr.isEmpty()) return false
        sides[0].let { }
        var prevL = captureHand(sides[0]); var prevR = captureHand(sides[1]); var prevEx = FloatArray(EXN)
        val out = ArrayList<Kf>(); var uL = false; var uR = false
        out.add(Kf(0f, prevL, prevR, prevEx))
        for (k in arr) {
            val l = prevL.copy(); val r = prevR.copy(); val e = prevEx.copyOf()
            (k["kiri"] ?: k["left"] as? Map<*, *>).let { if (it is Map<*, *>) { uL = true; parseHand(it, l) } }
            (k["kanan"] ?: k["right"]).let { if (it is Map<*, *>) { uR = true; parseHand(it, r) } }
            (k["dua_tangan"] as? Map<*, *>)?.let { uL = true; uR = true; parseHand(it, l); parseHand(it, r) }
            parseEx(k, e)
            out.add(Kf(cl(num(k["t"], 1f), .3f, 11f), l, r, e)); prevL = l; prevR = r; prevEx = e
        }
        val last = out.last(); val hold = cl(num(p["tahan"], 1f), .3f, 3f)
        out.add(Kf(last.t + hold, last.l, last.r, last.ex))
        plan = CPlan(now, out, last.t + hold, uL, uR, p["rencana"]?.toString() ?: "")
        return true
    }

    // ---------------------------------------------------------------- evaluasi per frame
    private fun resolve(h: HandKf, hf: FloatArray, o: FloatArray) {
        val a0 = if (h.anchorH) hf[0] else 0f; val a1 = if (h.anchorH) hf[1] else 0f; val a2 = if (h.anchorH) hf[2] else 0f
        var x = a0 + h.pv[0]; val y = a1 + h.pv[1]; var z = a2 + h.pv[2]
        if (abs(x) < .2f && y < 1f && y > -1.5f && z < .24f && z > -.3f) z = .24f
        o[0] = x; o[1] = y; o[2] = z
    }
    private val pa = FloatArray(3); private val pb = FloatArray(3)
    private fun lerp(a: Float, b: Float, e: Float) = a + (b - a) * e
    fun needsIk() = ok && (plan != null || sides[0].w > .004f || sides[1].w > .004f)

    private fun stepS(s: Side, k: Float, c: Float, dt: Float) {
        val n = ceil(dt / .016f).toInt().coerceAtLeast(1); val h = dt / n
        for (j in 0 until n) for (i in 0 until 19) { s.sv[i] += ((s.tgt[i] - s.st[i]) * k - s.sv[i] * c) * h; s.st[i] += s.sv[i] * h }
    }

    /** Panggil setelah rig.fkPass() bila needsIk(); aman dipanggil kapan pun (tanpa rencana hanya mengatur jari). */
    fun update(t: Float, dt: Float) {
        if (!ok) return
        val g = rig.gt
        ox = (g[sides[0].arm * 3] + g[sides[1].arm * 3]) / 2; oy = (g[sides[0].arm * 3 + 1] + g[sides[1].arm * 3 + 1]) / 2; oz = (g[sides[0].arm * 3 + 2] + g[sides[1].arm * 3 + 2]) / 2
        val hf = floatArrayOf((g[headI * 3] - ox) / al * sides[0].sx, (g[headI * 3 + 1] - oy) / al, (g[headI * 3 + 2] - oz) / al)
        var active = false
        val p = plan
        val evalPos = Array(2) { FloatArray(19) }
        if (p != null) {
            val lt = t - p.t0
            if (lt > p.end + .6f) plan = null
            else {
                val ks = p.kfs; var i = 0
                while (i < ks.size - 2 && lt >= ks[i + 1].t) i++
                val a = ks[i]; val b = ks[i + 1]
                val u = cl((lt - a.t) / max(.05f, b.t - a.t), 0f, 1f); val e = u * u * (3 - 2 * u)
                for (si in 0..1) {
                    val A = if (si == 0) a.l else a.r; val B = if (si == 0) b.l else b.r; val o = evalPos[si]
                    resolve(A, hf, pa); resolve(B, hf, pb)
                    for (q in 0..2) { o[q] = lerp(pa[q], pb[q], e); o[3 + q] = lerp(A.dir[q], B.dir[q], e); o[6 + q] = lerp(A.pal[q], B.pal[q], e); o[16 + q] = lerp(A.pole[q], B.pole[q], e) }
                    for (q in 0..6) o[9 + q] = lerp(A.fin[q], B.fin[q], e)
                    sides[si].on = (if (si == 0) p.usedL else p.usedR) && lt <= p.end
                }
                val fade = if (lt > p.end) cl(1f - (lt - p.end) / .6f, 0f, 1f) else 1f
                for (j in 0 until EXN) ex[j] = lerp(a.ex[j], b.ex[j], e) * (if (lt > p.end) fade else 1f)
                active = true
            }
        }
        if (!active) { java.util.Arrays.fill(ex, 0f); sides[0].on = false; sides[1].on = false }
        for (si in 0..1) {
            val s = sides[si]; val on = s.on
            if (on) System.arraycopy(evalPos[si], 0, s.tgt, 0, 19)
            else {
                System.arraycopy(s.st, 0, s.tgt, 0, 9); System.arraycopy(s.st, 16, s.tgt, 16, 3)
                val rs = PlanData.SHAPES["rileks"]!!
                for (i in 0..6) s.tgt[9 + i] = rs[i] + (if (i < 6) sin(t * .7f + i + (if (s.left) 0f else 2f)) * .03f else 0f)
            }
            if (!s.init && on) { System.arraycopy(s.tgt, 0, s.st, 0, 19); java.util.Arrays.fill(s.sv, 0f); s.init = true }
            stepS(s, if (on) 110f else 60f, if (on) 19f else 13f, dt)
            val tw = if (on) 1f else 0f
            s.wv += ((tw - s.w) * 38f - s.wv * 10f) * dt; s.w += s.wv * dt
            if (!on && s.w < .004f) s.init = false
            if (s.st[0] != s.st[0] || s.st[9] != s.st[9]) { java.util.Arrays.fill(s.st, 0f); java.util.Arrays.fill(s.sv, 0f); s.w = 0f; s.wv = 0f; plan = null; s.init = false; continue }
            applyFingers(s)
            if (s.w > .004f) armIk(s, cl(s.w, 0f, 1f))
            else { rig.ow[s.arm] = 0f; rig.ow[s.elb] = 0f; rig.ow[s.wri] = 0f }
        }
    }

    private val FK = floatArrayOf(1.15f, 1.45f, 1.0f); private val FSP = floatArrayOf(.14f, 0f, -.12f, -.22f)
    private fun applyFingers(s: Side) {
        val f = s.st; val sg = if (s.left) -1f else 1f
        for (i in 0..3) {
            val c = f[11 + i]; val sc = if (i == 3) .95f else 1f
            for (j in 0..2) { val bi = s.fin[i][j]; if (bi >= 0) rig.setOverride(bi, 0f, if (j == 0) sg * f[15] * FSP[i] else 0f, sg * c * FK[j] * sc) }
        }
        val fl = f[9]; val op = f[10]
        if (s.th[0] >= 0) rig.setOverride(s.th[0], 0f, sg * op * .5f * -1f, sg * fl * .15f)
        if (s.th[1] >= 0) rig.setOverride(s.th[1], 0f, 0f, sg * (fl * .9f + op * .1f))
        if (s.th[2] >= 0) rig.setOverride(s.th[2], 0f, 0f, sg * fl * 1.0f)
    }

    private fun armIk(s: Side, w: Float) {
        val x = s.st
        val sx = s.sx
        // arah/telapak/siku dari bingkai tubuh ke dunia
        var fx = x[3] * sx; var fy = x[4]; var fz = x[5]; var l = sqrt(fx * fx + fy * fy + fz * fz).coerceAtLeast(1e-6f); fx /= l; fy /= l; fz /= l
        var nx = x[6] * sx; var ny = x[7]; var nz = x[8]; l = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-6f); nx /= l; ny /= l; nz /= l
        var qx = x[16] * sx; var qy = x[17]; var qz = x[18]; l = sqrt(qx * qx + qy * qy + qz * qz).coerceAtLeast(1e-6f); qx /= l; qy /= l; qz /= l
        // target pergelangan = pusat telapak dikurangi panjang tangan
        val tx = ox + x[0] * sx * al - fx * s.hl * .9f
        val ty = oy + x[1] * al - fy * s.hl * .9f
        val tz = oz + x[2] * al - fz * s.hl * .9f
        val gt = rig.gt; val gq = rig.gq; val a = s.arm
        val sx0 = gt[a * 3]; val sy0 = gt[a * 3 + 1]; val sz0 = gt[a * 3 + 2]
        var dx = tx - sx0; var dy = ty - sy0; var dz = tz - sz0
        var dist = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1e-5f)
        dx /= dist; dy /= dist; dz /= dist
        dist = dist.coerceIn(abs(s.l1 - s.l2) + .08f, s.l1 + s.l2 - .03f)
        val aa = (s.l1 * s.l1 - s.l2 * s.l2 + dist * dist) / (2 * dist)
        val hh = sqrt(max(0f, s.l1 * s.l1 - aa * aa))
        val pd = qx * dx + qy * dy + qz * dz
        var cx = qx - dx * pd; var cy = qy - dy * pd; var cz = qz - dz * pd
        if (cx * cx + cy * cy + cz * cz < 1e-4f) { cx = -dx * dy; cy = -1f - dy * dy; cz = -dz * dy }
        l = sqrt(cx * cx + cy * cy + cz * cz).coerceAtLeast(1e-6f); cx /= l; cy /= l; cz /= l
        val ex0 = sx0 + dx * aa + cx * hh; val ey0 = sy0 + dy * aa + cy * hh; val ez0 = sz0 + dz * aa + cz * hh
        val tcx = sx0 + dx * dist; val tcy = sy0 + dy * dist; val tcz = sz0 + dz * dist
        // lengan atas
        var ux = ex0 - sx0; var uy = ey0 - sy0; var uz = ez0 - sz0; l = sqrt(ux * ux + uy * uy + uz * uz).coerceAtLeast(1e-6f); ux /= l; uy /= l; uz /= l
        qfromTo(s.d1[0], s.d1[1], s.d1[2], ux, uy, uz, q1, 0)
        parentInvMul(rig.par[a], q1, rig.oq, a * 4); rig.ow[a] = w
        for (p in s.pathAE) rig.recompute(p)
        // lengan bawah
        var vx = tcx - gt[s.elb * 3]; var vy = tcy - gt[s.elb * 3 + 1]; var vz = tcz - gt[s.elb * 3 + 2]
        l = sqrt(vx * vx + vy * vy + vz * vz).coerceAtLeast(1e-6f); vx /= l; vy /= l; vz /= l
        qfromTo(s.d2[0], s.d2[1], s.d2[2], vx, vy, vz, q1, 0)
        parentInvMul(rig.par[s.elb], q1, rig.oq, s.elb * 4); rig.ow[s.elb] = w
        for (p in s.pathEW) rig.recompute(p)
        // orientasi tangan (tekukan pergelangan dibatasi ~66 derajat)
        val ang = acos((fx * vx + fy * vy + fz * vz).coerceIn(-1f, 1f)); val MX = 1.15f
        var ffx = fx; var ffy = fy; var ffz = fz
        if (ang > MX) {
            val fd = fx * vx + fy * vy + fz * vz
            var gx = fx - vx * fd; var gy = fy - vy * fd; var gz = fz - vz * fd
            val gl = sqrt(gx * gx + gy * gy + gz * gz)
            if (gl > 1e-3f) { gx /= gl; gy /= gl; gz /= gl; ffx = vx * cos(MX) + gx * sin(MX); ffy = vy * cos(MX) + gy * sin(MX); ffz = vz * cos(MX) + gz * sin(MX) } else { ffx = vx; ffy = vy; ffz = vz }
        }
        val nd = nx * ffx + ny * ffy + nz * ffz
        var mx = nx - ffx * nd; var my = ny - ffy * nd; var mz = nz - ffz * nd
        if (mx * mx + my * my + mz * mz < 1e-4f) { mx = ffy * 0f - ffz * 1f; my = ffz * 0f - ffx * 0f; mz = ffx * 1f - ffy * 0f }
        l = sqrt(mx * mx + my * my + mz * mz).coerceAtLeast(1e-6f); mx /= l; my /= l; mz /= l
        val zx = ffy * mz - ffz * my; val zy = ffz * mx - ffx * mz; val zz = ffx * my - ffy * mx
        // R = [ff nn z] * B0^T
        val cN = floatArrayOf(ffx, mx, zx, ffy, my, zy, ffz, mz, zz); val b0 = s.b0
        val r = FloatArray(9)
        for (i in 0..2) for (j in 0..2) r[i * 3 + j] = cN[i * 3] * b0[j * 3] + cN[i * 3 + 1] * b0[j * 3 + 1] + cN[i * 3 + 2] * b0[j * 3 + 2]
        matToQuat(r, q1)
        parentInvMul(rig.par[s.wri], q1, rig.oq, s.wri * 4); rig.ow[s.wri] = w
    }
    /** out = conj(globalRot(parent)) * q */
    private fun parentInvMul(p: Int, q: FloatArray, out: FloatArray, oo: Int) {
        if (p < 0) { out[oo] = q[0]; out[oo + 1] = q[1]; out[oo + 2] = q[2]; out[oo + 3] = q[3]; return }
        tmp[0] = -rig.gq[p * 4]; tmp[1] = -rig.gq[p * 4 + 1]; tmp[2] = -rig.gq[p * 4 + 2]; tmp[3] = rig.gq[p * 4 + 3]
        qmul(tmp, 0, q, 0, out, oo); qnorm(out, oo)
    }
    private fun matToQuat(m: FloatArray, q: FloatArray) {
        val tr = m[0] + m[4] + m[8]
        if (tr > 0f) { val s = sqrt(tr + 1f) * 2f; q[3] = .25f * s; q[0] = (m[7] - m[5]) / s; q[1] = (m[2] - m[6]) / s; q[2] = (m[3] - m[1]) / s }
        else if (m[0] > m[4] && m[0] > m[8]) { val s = sqrt(1f + m[0] - m[4] - m[8]) * 2f; q[3] = (m[7] - m[5]) / s; q[0] = .25f * s; q[1] = (m[1] + m[3]) / s; q[2] = (m[2] + m[6]) / s }
        else if (m[4] > m[8]) { val s = sqrt(1f + m[4] - m[0] - m[8]) * 2f; q[3] = (m[2] - m[6]) / s; q[0] = (m[1] + m[3]) / s; q[1] = .25f * s; q[2] = (m[5] + m[7]) / s }
        else { val s = sqrt(1f + m[8] - m[0] - m[4]) * 2f; q[3] = (m[3] - m[1]) / s; q[0] = (m[2] + m[6]) / s; q[1] = (m[5] + m[7]) / s; q[2] = .25f * s }
        qnorm(q, 0)
    }
}
