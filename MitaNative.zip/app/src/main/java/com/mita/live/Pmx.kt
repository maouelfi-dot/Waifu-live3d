package com.mita.live

import java.nio.ByteBuffer
import java.nio.ByteOrder

class MIkLink(val bone: Int, val lim: Boolean, val mn: FloatArray, val mx: FloatArray)
class MIk(val target: Int, val loop: Int, val limit: Float, val links: List<MIkLink>)
class MBone(
    val name: String, val parent: Int, val x: Float, val y: Float, val z: Float,
    val layer: Int = 0, val flags: Int = 0, val appP: Int = -1, val appR: Float = 0f,
    val axis: FloatArray? = null, val ik: MIk? = null
)
class MMat(
    val name: String, val col: FloatArray, val tex: Int, val dbl: Boolean, val first: Int, val count: Int,
    val edge: Boolean = false, val edgeCol: FloatArray = floatArrayOf(0f, 0f, 0f, 1f), val edgeSize: Float = 1f
) { var vis = true }
/** type 1 = morph vertex, type 0 = morph grup (gi/gr); tipe lain diabaikan tetapi indeksnya dijaga. */
class MMorph(
    val name: String, val vi: IntArray, val off: FloatArray, val type: Int = 1,
    val gi: IntArray = IntArray(0), val gr: FloatArray = FloatArray(0)
)
/** Rigid body: pos dalam ruang model (z sudah dibalik). mode 0 = ikut tulang, 1/2 = fisika. */
class MRb(
    val name: String, val bone: Int, val shape: Int, val size: FloatArray, val pos: FloatArray,
    val rot: FloatArray, val mode: Int, val mass: Float, val ld: Float, val ad: Float
)
class PmxModel(
    val nv: Int, val pos: FloatArray, val nor: FloatArray, val uv: FloatArray, val bi: IntArray, val bw: FloatArray,
    val idx: IntArray, val tex: List<String>, val mats: List<MMat>, val bones: List<MBone>, val morphs: List<MMorph>,
    val rbs: List<MRb> = emptyList()
)

object Pmx {
    private val SJ = charset("Shift_JIS")

    fun parse(data: ByteArray): PmxModel {
        if (data.size >= 16 && String(data, 0, 4, Charsets.ISO_8859_1) == "PMX ") return parsePmx(data)
        if (data.size >= 283 && String(data, 0, 3, Charsets.ISO_8859_1) == "Pmd") return parsePmd(data)
        throw IllegalArgumentException("Format model tidak dikenal (harus PMX atau PMD).")
    }

    private fun normalizeW(bw: FloatArray, nv: Int) {
        for (i in 0 until nv) {
            val s = bw[i * 4] + bw[i * 4 + 1] + bw[i * 4 + 2] + bw[i * 4 + 3]
            if (s > 1e-6f && (s < .999f || s > 1.001f)) for (k in 0..3) bw[i * 4 + k] /= s
        }
    }

    // ------------------------------------------------------------------ PMX
    private fun parsePmx(data: ByteArray): PmxModel {
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        b.position(4); b.float
        val gn = b.get().toInt()
        val g = IntArray(gn) { b.get().toInt() }
        val utf8 = g[0] == 1; val addUV = g[1]; val vs = g[2]; val ts = g[3]; val ms = g[4]; val bs = g[5]; val mos = g[6]; val rs = g[7]
        fun txt(): String { val n = b.int; val a = ByteArray(n); b.get(a); return String(a, if (utf8) Charsets.UTF_8 else Charsets.UTF_16LE) }
        fun sidx(s: Int): Int = when (s) { 1 -> b.get().toInt(); 2 -> b.short.toInt(); else -> b.int }
        fun uidx(s: Int): Int = when (s) { 1 -> b.get().toInt() and 255; 2 -> b.short.toInt() and 65535; else -> b.int }
        repeat(4) { txt() }
        val nv = b.int
        val pos = FloatArray(nv * 3); val nor = FloatArray(nv * 3); val uv = FloatArray(nv * 2)
        val bi = IntArray(nv * 4) { -1 }; val bw = FloatArray(nv * 4)
        for (i in 0 until nv) {
            pos[i * 3] = b.float; pos[i * 3 + 1] = b.float; pos[i * 3 + 2] = -b.float
            nor[i * 3] = b.float; nor[i * 3 + 1] = b.float; nor[i * 3 + 2] = -b.float
            uv[i * 2] = b.float; uv[i * 2 + 1] = b.float
            repeat(addUV * 4) { b.float }
            val wt = b.get().toInt()
            when (wt) {
                0 -> { bi[i * 4] = sidx(bs); bw[i * 4] = 1f }
                1, 3 -> {
                    bi[i * 4] = sidx(bs); bi[i * 4 + 1] = sidx(bs)
                    val w = b.float; bw[i * 4] = w; bw[i * 4 + 1] = 1f - w
                    if (wt == 3) repeat(9) { b.float }
                }
                else -> { for (k in 0..3) bi[i * 4 + k] = sidx(bs); for (k in 0..3) bw[i * 4 + k] = b.float }
            }
            b.float
        }
        normalizeW(bw, nv)
        val nf = b.int
        val idx = IntArray(nf) { uidx(vs) }
        var t = 0
        while (t + 2 < nf) { val x = idx[t + 1]; idx[t + 1] = idx[t + 2]; idx[t + 2] = x; t += 3 }
        val tex = List(b.int) { txt() }
        val nm = b.int
        var off = 0
        val mats = ArrayList<MMat>()
        for (i in 0 until nm) {
            val name = txt(); txt()
            val d = FloatArray(4) { b.float }
            repeat(3) { b.float }; b.float; repeat(3) { b.float }
            val fl = b.get().toInt()
            val ec = FloatArray(4) { b.float }; val es = b.float
            val ti = sidx(ts); sidx(ts); b.get()
            val tf = b.get().toInt()
            if (tf == 0) sidx(ts) else b.get()
            txt()
            val cnt = b.int
            mats.add(MMat(name, d, ti, (fl and 1) != 0, off, cnt, (fl and 0x10) != 0, ec, es)); off += cnt
        }
        val nb = b.int
        val bones = ArrayList<MBone>()
        for (i in 0 until nb) {
            val name = txt(); txt()
            val x = b.float; val y = b.float; val z = -b.float
            val par = sidx(bs); val layer = b.int
            val fl = b.short.toInt() and 65535
            if ((fl and 1) != 0) sidx(bs) else repeat(3) { b.float }
            var appP = -1; var appR = 0f
            if ((fl and 0x300) != 0) { appP = sidx(bs); appR = b.float; if ((fl and 0x100) == 0) appP = -1 }
            var axis: FloatArray? = null
            if ((fl and 0x400) != 0) {
                val ax = b.float; val ay = b.float; val az = -b.float
                val l = Math.sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
                if (l > 1e-6f) axis = floatArrayOf(ax / l, ay / l, az / l)
            }
            if ((fl and 0x800) != 0) repeat(6) { b.float }
            if ((fl and 0x2000) != 0) b.int
            var ik: MIk? = null
            if ((fl and 0x20) != 0) {
                val tg = sidx(bs); val loop = b.int; val lim = b.float; val lc = b.int
                val links = ArrayList<MIkLink>()
                repeat(lc) {
                    val lb = sidx(bs); val has = b.get().toInt() != 0
                    val mn = FloatArray(3); val mx = FloatArray(3)
                    if (has) {
                        val a0 = b.float; val a1 = b.float; val a2 = b.float; val c0 = b.float; val c1 = b.float; val c2 = b.float
                        // sumbu z dibalik: rotasi x,y berganti tanda
                        mn[0] = -c0; mx[0] = -a0; mn[1] = -c1; mx[1] = -a1; mn[2] = a2; mx[2] = c2
                    }
                    links.add(MIkLink(lb, has, mn, mx))
                }
                ik = MIk(tg, loop, lim, links)
            }
            bones.add(MBone(name, par, x, y, z, layer, fl, appP, appR, axis, ik))
        }
        val morphs = ArrayList<MMorph>()
        try {
            val nmo = b.int
            for (i in 0 until nmo) {
                val name = txt(); txt(); b.get()
                val type = b.get().toInt(); val n = b.int
                when (type) {
                    0 -> {
                        val gi = IntArray(n); val gr = FloatArray(n)
                        for (k in 0 until n) { gi[k] = sidx(mos); gr[k] = b.float }
                        morphs.add(MMorph(name, IntArray(0), FloatArray(0), 0, gi, gr))
                    }
                    1 -> {
                        val vi = IntArray(n); val o = FloatArray(n * 3)
                        for (k in 0 until n) { vi[k] = uidx(vs); o[k * 3] = b.float; o[k * 3 + 1] = b.float; o[k * 3 + 2] = -b.float }
                        morphs.add(MMorph(name, vi, o, 1))
                    }
                    else -> {
                        when (type) {
                            2 -> repeat(n) { sidx(bs); repeat(7) { b.float } }
                            3, 4, 5, 6, 7 -> repeat(n) { uidx(vs); repeat(4) { b.float } }
                            8 -> repeat(n) { sidx(ms); b.get(); repeat(28) { b.float } }
                            9 -> repeat(n) { sidx(mos); b.float }
                            10 -> repeat(n) { sidx(rs); b.get(); repeat(6) { b.float } }
                            else -> throw IllegalStateException("morph?")
                        }
                        morphs.add(MMorph(name, IntArray(0), FloatArray(0), type))
                    }
                }
            }
        } catch (e: Exception) { }
        // frame tampilan lalu rigid body (dipakai fisika rambut/rok)
        val rbs = ArrayList<MRb>()
        try {
            val nfr = b.int
            repeat(nfr) { txt(); txt(); b.get(); val c = b.int; repeat(c) { val ty = b.get().toInt(); sidx(if (ty == 0) bs else mos) } }
            val nr = b.int
            repeat(nr) {
                val n = txt(); txt(); val bone = sidx(bs); b.get(); b.short
                val shape = b.get().toInt()
                val size = FloatArray(3) { b.float }
                val p = FloatArray(3) { b.float }; p[2] = -p[2]
                val r = FloatArray(3) { b.float }
                val mass = b.float; val ld = b.float; val ad = b.float; b.float; b.float
                val mode = b.get().toInt()
                rbs.add(MRb(n, bone, shape, size, p, r, mode, mass, ld, ad))
            }
        } catch (e: Exception) { }
        return PmxModel(nv, pos, nor, uv, bi, bw, idx, tex, mats, bones, morphs, rbs)
    }

    // ------------------------------------------------------------------ PMD
    private fun parsePmd(d: ByteArray): PmxModel {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        b.position(3 + 4 + 20 + 256)
        fun sj(n: Int): String { val a = ByteArray(n); b.get(a); var l = 0; while (l < n && a[l].toInt() != 0) l++; return String(a, 0, l, SJ) }
        fun us(): Int = b.short.toInt() and 65535
        val nv = b.int
        val pos = FloatArray(nv * 3); val nor = FloatArray(nv * 3); val uv = FloatArray(nv * 2)
        val bi = IntArray(nv * 4) { -1 }; val bw = FloatArray(nv * 4)
        for (i in 0 until nv) {
            pos[i * 3] = b.float; pos[i * 3 + 1] = b.float; pos[i * 3 + 2] = -b.float
            nor[i * 3] = b.float; nor[i * 3 + 1] = b.float; nor[i * 3 + 2] = -b.float
            uv[i * 2] = b.float; uv[i * 2 + 1] = b.float
            val b0 = us(); val b1 = us(); val w = (b.get().toInt() and 255) / 100f; b.get()
            bi[i * 4] = b0; bi[i * 4 + 1] = b1; bw[i * 4] = w; bw[i * 4 + 1] = 1f - w
        }
        val nf = b.int
        val idx = IntArray(nf) { us() }
        var t = 0
        while (t + 2 < nf) { val x = idx[t + 1]; idx[t + 1] = idx[t + 2]; idx[t + 2] = x; t += 3 }
        val nm = b.int
        val texList = ArrayList<String>(); val mats = ArrayList<MMat>(); var off = 0
        for (i in 0 until nm) {
            val dc = FloatArray(4) { b.float }
            b.float; repeat(3) { b.float }; repeat(3) { b.float }
            b.get(); val edge = b.get().toInt() != 0
            val cnt = b.int
            val tn = sj(20).substringBefore('*').trim()
            var ti = -1
            if (tn.isNotEmpty()) { ti = texList.indexOf(tn); if (ti < 0) { texList.add(tn); ti = texList.size - 1 } }
            mats.add(MMat("mat$i", dc, ti, dc[3] < .999f, off, cnt, edge, floatArrayOf(0f, 0f, 0f, 1f), 1f)); off += cnt
        }
        val nb = us()
        class PB(val n: String, val p: Int, val x: Float, val y: Float, val z: Float)
        val pbs = ArrayList<PB>()
        for (i in 0 until nb) {
            val n = sj(20); var p = us(); us(); b.get(); us()
            val x = b.float; val y = b.float; val z = -b.float
            if (p == 65535 || p >= nb) p = -1
            pbs.add(PB(n, p, x, y, z))
        }
        val iksOf = HashMap<Int, MIk>()
        val nik = us()
        repeat(nik) {
            val ib = us(); val tg = us(); val cl = b.get().toInt() and 255; val it = us(); val cw = b.float
            val links = ArrayList<MIkLink>()
            repeat(cl) {
                val lb = us()
                val knee = lb < nb && pbs[lb].n.contains("ひざ")
                links.add(MIkLink(lb, knee, floatArrayOf(if (knee) .0035f else 0f, 0f, 0f), floatArrayOf(if (knee) 3.14159f else 0f, 0f, 0f)))
            }
            if (ib < nb) iksOf[ib] = MIk(tg, it, cw * 4f, links)
        }
        val bones = pbs.mapIndexed { i, p -> MBone(p.n, p.p, p.x, p.y, p.z, 0, if (iksOf.containsKey(i)) 0x20 else 0, -1, 0f, null, iksOf[i]) }
        val morphs = ArrayList<MMorph>()
        try {
            val ns = us()
            var baseIdx: IntArray? = null
            repeat(ns) {
                val name = sj(20); val c = b.int; val ty = b.get().toInt()
                val vi = IntArray(c); val o = FloatArray(c * 3)
                for (k in 0 until c) { vi[k] = b.int; o[k * 3] = b.float; o[k * 3 + 1] = b.float; o[k * 3 + 2] = -b.float }
                if (ty == 0) { baseIdx = vi; morphs.add(MMorph(name, IntArray(0), FloatArray(0), 9)) }
                else {
                    val bidx = baseIdx
                    val mapped = IntArray(c) { k -> if (bidx != null && vi[k] in bidx.indices) bidx[vi[k]] else 0 }
                    morphs.add(MMorph(name, mapped, o, 1))
                }
            }
        } catch (e: Exception) { }
        val rbs = ArrayList<MRb>()
        try {
            val sd = b.get().toInt() and 255; b.position(b.position() + sd * 2)
            val bdn = b.get().toInt() and 255; b.position(b.position() + bdn * 50)
            val bdl = b.int; b.position(b.position() + bdl * 3)
            val eng = b.get().toInt()
            if (eng == 1) b.position(b.position() + 20 + 256 + nb * 20 + maxOf(0, morphs.size - 1) * 20 + bdn * 50)
            b.position(b.position() + 1000)
            val nr = b.int
            repeat(nr) {
                val n = sj(20); var bn = us(); if (bn == 65535 || bn >= nb) bn = -1
                b.get(); b.short; val shape = b.get().toInt()
                val size = FloatArray(3) { b.float }
                val rel = FloatArray(3) { b.float }
                val r = FloatArray(3) { b.float }
                val mass = b.float; val ld = b.float; val ad = b.float; b.float; b.float
                val mode = b.get().toInt()
                val bp = if (bn >= 0) pbs[bn] else null
                val p = floatArrayOf((bp?.x ?: 0f) + rel[0], (bp?.y ?: 0f) + rel[1], (bp?.z ?: 0f) - rel[2])
                rbs.add(MRb(n, bn, shape, size, p, r, mode, mass, ld, ad))
            }
        } catch (e: Exception) { rbs.clear() }
        normalizeW(bw, nv)
        return PmxModel(nv, pos, nor, uv, bi, bw, idx, texList, mats, bones, morphs, rbs)
    }
}
