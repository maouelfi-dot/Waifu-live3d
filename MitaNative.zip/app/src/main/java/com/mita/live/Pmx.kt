package com.mita.live

import java.nio.ByteBuffer
import java.nio.ByteOrder

class MBone(val name: String, val parent: Int, val x: Float, val y: Float, val z: Float)
class MMat(val name: String, val col: FloatArray, val tex: Int, val dbl: Boolean, val first: Int, val count: Int) { var vis = true }
class MIk(val ik: Int, val target: Int, val loop: Int, val limit: Float, val links: IntArray)
class MMorph(val name: String, val vi: IntArray, val off: FloatArray)
class PmxModel(
    val nv: Int, val pos: FloatArray, val nor: FloatArray, val uv: FloatArray, val bi: IntArray, val bw: FloatArray,
    val idx: IntArray, val tex: List<String>, val mats: List<MMat>, val bones: List<MBone>, val morphs: List<MMorph>, val iks: List<MIk>
)

object Pmx {
    fun parse(data: ByteArray): PmxModel {
        if (data.size < 16 || String(data, 0, 4) != "PMX ") throw IllegalArgumentException("Hanya format PMX yang didukung (PMD belum).")
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        b.position(4); b.float
        val gn = b.get().toInt()
        val g = IntArray(gn) { b.get().toInt() }
        val utf8 = g[0] == 1; val addUV = g[1]; val vs = g[2]; val ts = g[3]; val ms = g[4]; val bs = g[5]; val mos = g[6]; val rs = g[7]
        fun txt(): String { val n = b.int; val a = ByteArray(n); b.get(a); return String(a, if (utf8) Charsets.UTF_8 else Charsets.UTF_16LE) }
        fun sidx(s: Int): Int = when (s) { 1 -> b.get().toInt(); 2 -> b.short.toInt(); else -> b.int }
        fun uidx(s: Int): Int = when (s) { 1 -> b.get().toInt() and 255; 2 -> b.short.toInt() and 65535; else -> b.int }
        repeat(4) { txt() }
        val nv = b.int
        val pos = FloatArray(nv * 3); val nor = FloatArray(nv * 3); val uv = FloatArray(nv * 2)
        val bi = IntArray(nv * 4) { -1 }; val bw = FloatArray(nv * 4)
        for (i in 0 until nv) {
            pos[i * 3] = b.float; pos[i * 3 + 1] = b.float; pos[i * 3 + 2] = -b.float
            nor[i * 3] = b.float; nor[i * 3 + 1] = b.float; nor[i * 3 + 2] = -b.float
            uv[i * 2] = b.float; uv[i * 2 + 1] = b.float
            repeat(addUV * 4) { b.float }
            val wt = b.get().toInt()
            when (wt) {
                0 -> { bi[i * 4] = sidx(bs); bw[i * 4] = 1f }
                1, 3 -> {
                    bi[i * 4] = sidx(bs); bi[i * 4 + 1] = sidx(bs)
                    val w = b.float; bw[i * 4] = w; bw[i * 4 + 1] = 1f - w
                    if (wt == 3) repeat(9) { b.float }
                }
                else -> { for (k in 0..3) bi[i * 4 + k] = sidx(bs); for (k in 0..3) bw[i * 4 + k] = b.float }
            }
            b.float
        }
        val nf = b.int
        val idx = IntArray(nf) { uidx(vs) }
        var t = 0
        while (t + 2 < nf) { val x = idx[t + 1]; idx[t + 1] = idx[t + 2]; idx[t + 2] = x; t += 3 }
        val tex = List(b.int) { txt() }
        val nm = b.int
        var off = 0
        val mats = ArrayList<MMat>()
        for (i in 0 until nm) {
            val name = txt(); txt()
            val d = FloatArray(4) { b.float }
            repeat(3) { b.float }; b.float; repeat(3) { b.float }
            val fl = b.get().toInt()
            repeat(4) { b.float }; b.float
            val ti = sidx(ts); sidx(ts); b.get()
            val tf = b.get().toInt()
            if (tf == 0) sidx(ts) else b.get()
            txt()
            val cnt = b.int
            mats.add(MMat(name, d, ti, (fl and 1) != 0, off, cnt)); off += cnt
        }
        val nb = b.int
        val bones = ArrayList<MBone>()
        val iks = ArrayList<MIk>()
        for (i in 0 until nb) {
            val name = txt(); txt()
            val x = b.float; val y = b.float; val z = -b.float
            val par = sidx(bs); b.int
            val fl = b.short.toInt() and 65535
            if ((fl and 1) != 0) sidx(bs) else repeat(3) { b.float }
            if ((fl and 0x300) != 0) { sidx(bs); b.float }
            if ((fl and 0x400) != 0) repeat(3) { b.float }
            if ((fl and 0x800) != 0) repeat(6) { b.float }
            if ((fl and 0x2000) != 0) b.int
            if ((fl and 0x20) != 0) { val tg = sidx(bs); val lp = b.int; val lim = b.float; val lc = b.int; val ls = IntArray(lc); for (q in 0 until lc) { ls[q] = sidx(bs); if (b.get().toInt() != 0) repeat(6) { b.float } }; iks.add(MIk(i, tg, lp, lim, ls)) }
            bones.add(MBone(name, par, x, y, z))
        }
        val morphs = ArrayList<MMorph>()
        try {
            val nmo = b.int
            for (i in 0 until nmo) {
                val name = txt(); txt(); b.get()
                val type = b.get().toInt(); val n = b.int
                when (type) {
                    0, 9 -> repeat(n) { sidx(mos); b.float }
                    1 -> {
                        val vi = IntArray(n); val o = FloatArray(n * 3)
                        for (k in 0 until n) { vi[k] = uidx(vs); o[k * 3] = b.float; o[k * 3 + 1] = b.float; o[k * 3 + 2] = -b.float }
                        morphs.add(MMorph(name, vi, o))
                    }
                    2 -> repeat(n) { sidx(bs); repeat(7) { b.float } }
                    3, 4, 5, 6, 7 -> repeat(n) { uidx(vs); repeat(4) { b.float } }
                    8 -> repeat(n) { sidx(ms); b.get(); repeat(28) { b.float } }
                    10 -> repeat(n) { sidx(rs); b.get(); repeat(6) { b.float } }
                    else -> break
                }
            }
        } catch (e: Exception) { }
        return PmxModel(nv, pos, nor, uv, bi, bw, idx, tex, mats, bones, morphs, iks)
    }
}
